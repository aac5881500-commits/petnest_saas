// 🔐 AuthService
// 負責：
// - Firebase 註冊
// - Firebase 登入
// - 建立 Firestore 使用者資料
// - 登出
//
// 這是整個 SaaS 的帳號系統核心。
// 未來會擴充：店家、權限、角色。

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  /// 單例：整個 App 共用同一個 AuthService
  AuthService._();

  static final AuthService instance = AuthService._();

  /// Firebase Auth
  final FirebaseAuth _auth = FirebaseAuth.instance;

  /// Firestore
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// 取得目前登入中的使用者
  User? get currentUser => _auth.currentUser;

  /// 監聽登入狀態變化
  Stream<User?> authStateChanges() => _auth.authStateChanges();

  /// 🟢 註冊帳號
  ///
  /// 註冊成功後，會同步在 Firestore 建立 `users/{uid}` 文件。
  Future<UserCredential> register({
    required String email,
    required String password,
    String? displayName,
  }) async {
    // 建立 Firebase Auth 帳號
    final UserCredential credential =
        await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    final User? user = credential.user;
    if (user == null) {
      throw Exception('註冊成功，但抓不到使用者資料');
    }

    final String safeDisplayName = displayName?.trim() ?? '';

    // 如果有輸入名稱，就同步更新 Firebase Auth 的 displayName
    if (safeDisplayName.isNotEmpty) {
      await user.updateDisplayName(safeDisplayName);
    }

    // 建立 Firestore 使用者主檔
    await _firestore.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'email': user.email ?? email.trim(),
      'displayName': safeDisplayName,
      'role': 'user', // 未來可擴充：user / owner / admin / staff
      'status': 'active',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return credential;
  }

  /// 🔵 登入
  Future<UserCredential> login({
    required String email,
    required String password,
  }) {
    return _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password.trim(),
    );
  }

  /// 🔴 登出
  Future<void> logout() {
    return _auth.signOut();
  }
}