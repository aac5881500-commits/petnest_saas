import 'package:cloud_firestore/cloud_firestore.dart';

class ActionLogService {
  ActionLogService._();
  static final instance = ActionLogService._();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _actionLogs =>
      _firestore.collection('action_logs');

  Future<void> logAction({
    required String shopId,
    required String targetType,
    required String targetId,
    required String action,
    required String operatorUid,
    required String operatorRole,
    Map<String, dynamic>? payload,
  }) async {
    await _actionLogs.add({
      'shopId': shopId,
      'targetType': targetType,
      'targetId': targetId,
      'action': action,
      'operatorUid': operatorUid,
      'operatorRole': operatorRole,
      'payload': payload ?? <String, dynamic>{},
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}