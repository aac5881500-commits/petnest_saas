// 檔案名稱：lib/core/services/booking_service.dart
// 說明：預約服務層（區間預約版）
//
// 功能：
// - 建立預約
// - 讀取單筆預約
// - 監聽店家預約列表
// - 更新預約狀態
//
// 本次升級：
// - 區間可預約檢查
// - 剩餘房數計算
// - 日期是否可選
// - 區間價格計算
// - 納入房況欄位：清潔中 / 修整中
//
// 規則：
// - startDate = 入住日
// - endDate = 退房日
// - nights = 晚數
// - 實際佔房日期為：startDate ~ endDate 前一天
//   例如：3/10 入住，3/12 退房 => 佔房日期為 3/10、3/11，共 2 晚
//
// 房數計算：
// - 基礎可用房數 = totalRooms - cleaningRooms - maintenanceRooms
// - 實際剩餘房數 = 基礎可用房數 - 已佔用房數
//
// 注意：
// - cancelled 不佔房
// - pending / confirmed / completed 先都視為佔房
// - 目前每筆 booking 預設佔用 1 間房
// - 後面若要支援自動配房 / 指定房號，可再擴充 roomId / rooms

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:petnest_saas/core/services/shop_service.dart';

class BookingService {
  BookingService._();
  static final instance = BookingService._();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? get _currentUser => _auth.currentUser;

  CollectionReference<Map<String, dynamic>> get _bookings =>
      _firestore.collection('bookings');

  /// 建立預約（區間版）
  Future<String> createBooking({
    required String shopId,
    required String customerName,
    required String customerPhone,
    required String petName,
    required String petType,
    required String serviceType,
    required DateTime startDate,
    required DateTime endDate,
    required int nights,
    String note = '',
  }) async {
    final user = _currentUser;
    final doc = _bookings.doc();

    final normalizedStart = _dateOnly(startDate);
    final normalizedEnd = _dateOnly(endDate);

    await doc.set({
      'shopId': shopId,
      'customerUid': user?.uid,

      'customerName': customerName.trim(),
      'customerPhone': customerPhone.trim(),
      'petName': petName.trim(),
      'petType': petType.trim(),
      'serviceType': serviceType,

      /// 區間日期
      'startDate': Timestamp.fromDate(normalizedStart),
      'endDate': Timestamp.fromDate(normalizedEnd),
      'nights': nights,

      /// 目前每筆先固定佔 1 間
      'rooms': 1,

      /// 狀態
      'status': 'pending', // pending / confirmed / completed / cancelled

      /// 備註
      'note': note.trim(),

      /// 價格欄位
      'pricePerNight': null,
      'totalPrice': null,

      /// 未來預留
      'roomId': null,
      'roomName': null,
      'checkedInAt': null,
      'checkedOutAt': null,
      'cameraAccessEnabled': false,
      'cameraUrl': null,

      /// 系統欄位
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return doc.id;
  }

  /// 取得單筆預約
  Future<Map<String, dynamic>?> getBooking(String bookingId) async {
    final doc = await _bookings.doc(bookingId).get();

    if (!doc.exists) return null;

    return {
      'bookingId': doc.id,
      ...doc.data()!,
    };
  }

  /// 監聽單筆預約
  Stream<Map<String, dynamic>?> streamBooking(String bookingId) {
    return _bookings.doc(bookingId).snapshots().map((doc) {
      if (!doc.exists) return null;

      return {
        'bookingId': doc.id,
        ...doc.data()!,
      };
    });
  }

  /// 監聽某店家的全部預約（最新建立排前面）
  Stream<List<Map<String, dynamic>>> streamShopBookings(String shopId) {
    return _bookings
        .where('shopId', isEqualTo: shopId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return {
          'bookingId': doc.id,
          ...doc.data(),
        };
      }).toList();
    });
  }

  /// 依狀態監聽某店家預約
  Stream<List<Map<String, dynamic>>> streamShopBookingsByStatus({
    required String shopId,
    required String status,
  }) {
    return _bookings
        .where('shopId', isEqualTo: shopId)
        .where('status', isEqualTo: status)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return {
          'bookingId': doc.id,
          ...doc.data(),
        };
      }).toList();
    });
  }

  /// 取得某店家全部預約（一次性）
  Future<List<Map<String, dynamic>>> getShopBookings(String shopId) async {
    final snapshot = await _bookings
        .where('shopId', isEqualTo: shopId)
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs.map((doc) {
      return {
        'bookingId': doc.id,
        ...doc.data(),
      };
    }).toList();
  }

  /// 更新預約狀態
  Future<void> updateBookingStatus({
    required String bookingId,
    required String status,
  }) async {
    await _bookings.doc(bookingId).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 更新預約資料
  Future<void> updateBooking({
    required String bookingId,
    String? customerName,
    String? customerPhone,
    String? petName,
    String? petType,
    String? serviceType,
    DateTime? startDate,
    DateTime? endDate,
    int? nights,
    String? note,
    int? totalPrice,
    int? pricePerNight,
    String? roomId,
    String? roomName,
    bool? cameraAccessEnabled,
    String? cameraUrl,
  }) async {
    final Map<String, dynamic> data = {
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (customerName != null) data['customerName'] = customerName.trim();
    if (customerPhone != null) data['customerPhone'] = customerPhone.trim();
    if (petName != null) data['petName'] = petName.trim();
    if (petType != null) data['petType'] = petType.trim();
    if (serviceType != null) data['serviceType'] = serviceType;
    if (startDate != null) {
      data['startDate'] = Timestamp.fromDate(_dateOnly(startDate));
    }
    if (endDate != null) {
      data['endDate'] = Timestamp.fromDate(_dateOnly(endDate));
    }
    if (nights != null) data['nights'] = nights;
    if (note != null) data['note'] = note.trim();
    if (totalPrice != null) data['totalPrice'] = totalPrice;
    if (pricePerNight != null) data['pricePerNight'] = pricePerNight;
    if (roomId != null) data['roomId'] = roomId;
    if (roomName != null) data['roomName'] = roomName;
    if (cameraAccessEnabled != null) {
      data['cameraAccessEnabled'] = cameraAccessEnabled;
    }
    if (cameraUrl != null) data['cameraUrl'] = cameraUrl;

    await _bookings.doc(bookingId).update(data);
  }

  /// 單日基礎可用房數（未扣掉 booking）
  ///
  /// totalRooms - cleaningRooms - maintenanceRooms
  int getBaseAvailableRooms(Map<String, dynamic> shop) {
    return ShopService.instance.getBaseAvailableRooms(shop);
  }

  /// 單日已佔用房數
  Future<int> getOccupiedRoomsForDate({
    required String shopId,
    required DateTime date,
  }) async {
    final target = _dateOnly(date);
    final bookings = await getShopBookings(shopId);

    int occupiedRooms = 0;

    for (final booking in bookings) {
      if (!_isOccupyingBooking(booking)) continue;

      final startDate = _timestampToDate(booking['startDate']);
      final endDate = _timestampToDate(booking['endDate']);

      if (startDate == null || endDate == null) continue;

      if (_containsStayDate(
        targetDate: target,
        startDate: startDate,
        endDate: endDate,
      )) {
        occupiedRooms += _toInt(booking['rooms'], fallback: 1);
      }
    }

    return occupiedRooms;
  }

  /// 單日剩餘房數
  ///
  /// 剩餘 = 基礎可用房數 - 已佔用
  Future<int> getRemainingRoomsForDate({
    required Map<String, dynamic> shop,
    required DateTime date,
  }) async {
    final baseAvailableRooms = getBaseAvailableRooms(shop);

    final occupiedRooms = await getOccupiedRoomsForDate(
      shopId: shop['shopId'],
      date: date,
    );

    final remain = baseAvailableRooms - occupiedRooms;
    return remain < 0 ? 0 : remain;
  }

  /// 某一天是否可預約
  Future<bool> isDateBookable({
    required Map<String, dynamic> shop,
    required DateTime date,
  }) async {
    final target = _dateOnly(date);
    final today = _dateOnly(DateTime.now());

    final bookingEnabled = shop['bookingEnabled'] ?? true;
    if (!bookingEnabled) return false;

    if (target.isBefore(today)) return false;

    final maxAdvanceBookingDays = _toInt(
      shop['maxAdvanceBookingDays'],
      fallback: 30,
    );
    final lastBookableDate = today.add(Duration(days: maxAdvanceBookingDays));

    if (target.isAfter(lastBookableDate)) return false;

    if (ShopService.instance.isBlockedDate(shop, target)) return false;

    final remaining = await getRemainingRoomsForDate(
      shop: shop,
      date: target,
    );

    return remaining > 0;
  }

  /// 區間是否可預約
  Future<bool> isRangeBookable({
    required Map<String, dynamic> shop,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    final start = _dateOnly(startDate);
    final end = _dateOnly(endDate);

    if (!end.isAfter(start)) return false;

    final stayDates = getStayDates(
      startDate: start,
      endDate: end,
    );

    if (stayDates.isEmpty) return false;

    for (final date in stayDates) {
      final canBook = await isDateBookable(
        shop: shop,
        date: date,
      );

      if (!canBook) return false;
    }

    return true;
  }

  /// 取得區間中的所有佔房日期
  ///
  /// 例：
  /// startDate = 3/10
  /// endDate   = 3/13
  /// 回傳：3/10, 3/11, 3/12
  List<DateTime> getStayDates({
    required DateTime startDate,
    required DateTime endDate,
  }) {
    final start = _dateOnly(startDate);
    final end = _dateOnly(endDate);

    final List<DateTime> result = [];

    DateTime cursor = start;
    while (cursor.isBefore(end)) {
      result.add(cursor);
      cursor = cursor.add(const Duration(days: 1));
    }

    return result;
  }

  /// 計算晚數
  int calculateNights({
    required DateTime startDate,
    required DateTime endDate,
  }) {
    final start = _dateOnly(startDate);
    final end = _dateOnly(endDate);
    return end.difference(start).inDays;
  }

  /// 計算區間總價
  int calculateTotalPrice({
    required Map<String, dynamic> shop,
    required DateTime startDate,
    required DateTime endDate,
  }) {
    final stayDates = getStayDates(
      startDate: startDate,
      endDate: endDate,
    );

    int total = 0;

    for (final date in stayDates) {
      total += ShopService.instance.getPriceForDate(shop, date);
    }

    return total;
  }

  /// 區間中的不可預約日期
  Future<List<DateTime>> getUnbookableDatesInRange({
    required Map<String, dynamic> shop,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    final stayDates = getStayDates(
      startDate: startDate,
      endDate: endDate,
    );

    final List<DateTime> result = [];

    for (final date in stayDates) {
      final canBook = await isDateBookable(
        shop: shop,
        date: date,
      );

      if (!canBook) {
        result.add(date);
      }
    }

    return result;
  }

  /// 建立預約前的完整檢查
  Future<Map<String, dynamic>> validateBookingRange({
    required Map<String, dynamic> shop,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    final start = _dateOnly(startDate);
    final end = _dateOnly(endDate);

    if (!end.isAfter(start)) {
      return {
        'ok': false,
        'message': '退房日必須晚於入住日',
      };
    }

    final bookingEnabled = shop['bookingEnabled'] ?? true;
    if (!bookingEnabled) {
      return {
        'ok': false,
        'message': '此店家目前未開放預約',
      };
    }

    final nights = calculateNights(
      startDate: start,
      endDate: end,
    );

    if (nights <= 0) {
      return {
        'ok': false,
        'message': '至少要選 1 晚',
      };
    }

    final today = _dateOnly(DateTime.now());
    if (start.isBefore(today)) {
      return {
        'ok': false,
        'message': '入住日不能早於今天',
      };
    }

    final maxAdvanceBookingDays = _toInt(
      shop['maxAdvanceBookingDays'],
      fallback: 30,
    );
    final lastBookableDate = today.add(Duration(days: maxAdvanceBookingDays));

    if (start.isAfter(lastBookableDate)) {
      return {
        'ok': false,
        'message': '已超出最遠可預約範圍',
      };
    }

    final blockedDates = await getUnbookableDatesInRange(
      shop: shop,
      startDate: start,
      endDate: end,
    );

    if (blockedDates.isNotEmpty) {
      final firstDate = blockedDates.first;
      return {
        'ok': false,
        'message': '所選日期區間包含不可預約日期：${_formatDate(firstDate)}',
      };
    }

    return {
      'ok': true,
      'message': '可預約',
    };
  }

  bool _isOccupyingBooking(Map<String, dynamic> booking) {
    final status = booking['status']?.toString() ?? '';
    return status != 'cancelled';
  }

  bool _containsStayDate({
    required DateTime targetDate,
    required DateTime startDate,
    required DateTime endDate,
  }) {
    final target = _dateOnly(targetDate);
    final start = _dateOnly(startDate);
    final end = _dateOnly(endDate);

    return (target.isAtSameMomentAs(start) || target.isAfter(start)) &&
        target.isBefore(end);
  }

  DateTime? _timestampToDate(dynamic value) {
    if (value is Timestamp) return _dateOnly(value.toDate());
    if (value is DateTime) return _dateOnly(value);
    return null;
  }

  DateTime _dateOnly(DateTime date) {
    return DateTime(date.year, date.month, date.day);
  }

  int _toInt(dynamic value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value) ?? fallback;
    return fallback;
  }

  String _formatDate(DateTime date) {
    final y = date.year.toString().padLeft(4, '0');
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }
}