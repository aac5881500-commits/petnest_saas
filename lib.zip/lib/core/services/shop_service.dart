// 檔案名稱：lib/core/services/shop_service.dart
// 說明：店家服務層（含營業資訊 / Logo / 封面 / 預約設定）
//
// 目前功能：
// - 建立店家
// - 取得我的店家
// - 讀取單一店家
// - 更新基本資料
// - 更新營業資訊
// - 上傳 Logo / Cover
//
// 本次新增：
// - 預約設定欄位初始化
// - 更新預約設定
// - 更新關閉日期（單天關閉 / 休假日）
// - 更新特定日期價格
// - 預留房況欄位：清潔中 / 修整中
//
// 預約相關欄位（存於 shops/{shopId}）：
// - bookingEnabled: 是否開放預約
// - totalRooms: 總房數
// - cleaningRooms: 清潔中房數
// - maintenanceRooms: 修整中房數
// - maxAdvanceBookingDays: 最遠可預約天數
// - defaultPricePerNight: 每晚預設價格
// - blockedDates: 關閉日期清單（yyyy-MM-dd）
// - specialPrices: 特定日期價格（map，key = yyyy-MM-dd, value = int）
//
// 權限預留：
// - shop_members.role: owner / manager / staff
//
// 未來動作紀錄預留：
// - 後續可新增 action_logs collection

import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:petnest_saas/core/constants/shop_roles.dart';

class ShopService {
  ShopService._();
  static final instance = ShopService._();

  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? get _currentUser => _auth.currentUser;

  CollectionReference<Map<String, dynamic>> get _shops =>
      _firestore.collection('shops');

  CollectionReference<Map<String, dynamic>> get _shopMembers =>
      _firestore.collection('shop_members');

  /// 建立店家
  Future<String> createShop({
    required String name,
  }) async {
    final user = _currentUser;

    if (user == null) throw Exception('未登入');

    final existing = await _shopMembers
        .where('uid', isEqualTo: user.uid)
        .limit(1)
        .get();

    if (existing.docs.isNotEmpty) {
      throw Exception('你已經建立過店家了');
    }

    final shopRef = _shops.doc();
    final memberRef = _shopMembers.doc('${shopRef.id}_${user.uid}');

    final batch = _firestore.batch();

    batch.set(shopRef, {
      'name': name.trim(),
      'ownerUid': user.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),

      // 基本資料
      'businessType': 'cat',
      'phone': '',
      'address': '',
      'description': '',
      'city': '',
      'district': '',
      'lineUrl': '',

      // 營業資訊
      'isOpen': true,
      'businessHours': '',
      'closedDays': <String>[],
      'serviceTypes': <String>['overnight'],
      'isPublic': false,

      // 圖片
      'logoUrl': '',
      'coverUrl': '',

      // ========= 預約設定 =========
      'bookingEnabled': true,
      'totalRooms': 1,

      // 本次新增：房況欄位
      'cleaningRooms': 0,
      'maintenanceRooms': 0,

      'maxAdvanceBookingDays': 30,
      'defaultPricePerNight': 0,
      'blockedDates': <String>[],
      'specialPrices': <String, dynamic>{},
    });

    batch.set(memberRef, {
      'shopId': shopRef.id,
      'uid': user.uid,

      // 權限預留：owner / manager / staff
      'role': 'owner',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();

    return shopRef.id;
  }

  /// 取得我的店家
  Future<List<Map<String, dynamic>>> getMyShops() async {
    final user = _currentUser;
    if (user == null) throw Exception('未登入');

    final memberSnapshot =
        await _shopMembers.where('uid', isEqualTo: user.uid).get();

    final List<Map<String, dynamic>> result = [];

    for (final doc in memberSnapshot.docs) {
      final data = doc.data();
      final shopId = data['shopId'];

      final shopDoc = await _shops.doc(shopId).get();
      if (!shopDoc.exists) continue;

      result.add({
        'shopId': shopId,
        'name': shopDoc.data()?['name'] ?? '',
        'role': data['role'] ?? '',
      });
    }

    return result;
  }

  /// 取得單一店家
  Future<Map<String, dynamic>?> getShop(String shopId) async {
    final doc = await _shops.doc(shopId).get();
    if (!doc.exists) return null;

    final data = doc.data() ?? {};

    return {
      'shopId': doc.id,
      ...data,
    };
  }

  /// 監聽單一店家
  Stream<Map<String, dynamic>?> streamShop(String shopId) {
    return _shops.doc(shopId).snapshots().map((doc) {
      if (!doc.exists) return null;

      return {
        'shopId': doc.id,
        ...doc.data()!,
      };
    });
  }

  /// 取得某使用者在該店的角色
  Future<String?> getUserRoleInShop({
    required String shopId,
    required String uid,
  }) async {
    final snapshot = await _shopMembers
        .where('shopId', isEqualTo: shopId)
        .where('uid', isEqualTo: uid)
        .limit(1)
        .get();

    if (snapshot.docs.isEmpty) return null;

    final data = snapshot.docs.first.data();
    return data['role']?.toString();
  }

  /// 是否有管理店家權限
  bool canManageShop(String? role) {
    return role == ShopRoles.owner || role == ShopRoles.manager;
  }

  /// 更新店家基本資料
  Future<void> updateShopBasicInfo({
    required String shopId,
    required String name,
    String businessType = 'cat',
    String phone = '',
    String address = '',
    String description = '',
    String city = '',
    String district = '',
    String lineUrl = '',
  }) async {
    await _shops.doc(shopId).update({
      'name': name.trim(),
      'businessType': businessType,
      'phone': phone.trim(),
      'address': address.trim(),
      'description': description.trim(),
      'city': city.trim(),
      'district': district.trim(),
      'lineUrl': lineUrl.trim(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 更新營業資訊
  Future<void> updateBusinessInfo({
    required String shopId,
    required bool isOpen,
    String businessHours = '',
    List<String> closedDays = const [],
    List<String> serviceTypes = const [],
    bool isPublic = false,
  }) async {
    await _shops.doc(shopId).update({
      'isOpen': isOpen,
      'businessHours': businessHours,
      'closedDays': closedDays,
      'serviceTypes': serviceTypes,
      'isPublic': isPublic,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 更新預約基本設定
  Future<void> updateBookingSettings({
    required String shopId,
    bool? bookingEnabled,
    int? totalRooms,
    int? cleaningRooms,
    int? maintenanceRooms,
    int? maxAdvanceBookingDays,
    int? defaultPricePerNight,
  }) async {
    final Map<String, dynamic> data = {
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (bookingEnabled != null) data['bookingEnabled'] = bookingEnabled;
    if (totalRooms != null) data['totalRooms'] = totalRooms;
    if (cleaningRooms != null) data['cleaningRooms'] = cleaningRooms;
    if (maintenanceRooms != null) {
      data['maintenanceRooms'] = maintenanceRooms;
    }
    if (maxAdvanceBookingDays != null) {
      data['maxAdvanceBookingDays'] = maxAdvanceBookingDays;
    }
    if (defaultPricePerNight != null) {
      data['defaultPricePerNight'] = defaultPricePerNight;
    }

    await _shops.doc(shopId).update(data);
  }

  /// 覆蓋整份 blockedDates
  Future<void> updateBlockedDates({
    required String shopId,
    required List<String> blockedDates,
  }) async {
    final normalized = blockedDates
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList()
      ..sort();

    await _shops.doc(shopId).update({
      'blockedDates': normalized,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 新增單一天關閉日期
  Future<void> addBlockedDate({
    required String shopId,
    required String dateKey,
  }) async {
    await _shops.doc(shopId).update({
      'blockedDates': FieldValue.arrayUnion([dateKey]),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 移除單一天關閉日期
  Future<void> removeBlockedDate({
    required String shopId,
    required String dateKey,
  }) async {
    await _shops.doc(shopId).update({
      'blockedDates': FieldValue.arrayRemove([dateKey]),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 設定某一天特別價格
  Future<void> setSpecialPrice({
    required String shopId,
    required String dateKey,
    required int price,
  }) async {
    await _shops.doc(shopId).update({
      'specialPrices.$dateKey': price,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 移除某一天特別價格
  Future<void> removeSpecialPrice({
    required String shopId,
    required String dateKey,
  }) async {
    await _shops.doc(shopId).update({
      'specialPrices.$dateKey': FieldValue.delete(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  /// 取得某天實際價格
  int getPriceForDate(Map<String, dynamic> shop, DateTime date) {
    final String dateKey = formatDateKey(date);

    final Map<String, dynamic> specialPrices =
        Map<String, dynamic>.from(shop['specialPrices'] ?? {});

    if (specialPrices.containsKey(dateKey)) {
      return _toInt(specialPrices[dateKey]);
    }

    return _toInt(shop['defaultPricePerNight']);
  }

  /// 判斷某天是否被關閉
  bool isBlockedDate(Map<String, dynamic> shop, DateTime date) {
    final String dateKey = formatDateKey(date);

    final List<dynamic> rawBlockedDates = shop['blockedDates'] ?? [];
    final blockedDates = rawBlockedDates.map((e) => e.toString()).toSet();

    return blockedDates.contains(dateKey);
  }

  /// 計算基礎可用房數（還沒扣 booking 佔用）
  ///
  /// totalRooms - cleaningRooms - maintenanceRooms
  int getBaseAvailableRooms(Map<String, dynamic> shop) {
    final totalRooms = _toInt(shop['totalRooms'], fallback: 0);
    final cleaningRooms = _toInt(shop['cleaningRooms'], fallback: 0);
    final maintenanceRooms = _toInt(shop['maintenanceRooms'], fallback: 0);

    final result = totalRooms - cleaningRooms - maintenanceRooms;
    return result < 0 ? 0 : result;
  }

  /// 日期轉成 yyyy-MM-dd
  String formatDateKey(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    final y = d.year.toString().padLeft(4, '0');
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '$y-$m-$day';
  }

  /// 上傳店家 Logo
  Future<String> uploadShopLogo({
    required String shopId,
    required Uint8List bytes,
  }) async {
    final ref = _storage.ref().child('shops/$shopId/logo.jpg');
    await ref.putData(bytes);
    final url = await ref.getDownloadURL();

    await _shops.doc(shopId).update({
      'logoUrl': url,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return url;
  }

  /// 上傳店家 Cover
  Future<String> uploadShopCover({
    required String shopId,
    required Uint8List bytes,
  }) async {
    final ref = _storage.ref().child('shops/$shopId/cover.jpg');
    await ref.putData(bytes);
    final url = await ref.getDownloadURL();

    await _shops.doc(shopId).update({
      'coverUrl': url,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return url;
  }

  int _toInt(dynamic value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value) ?? fallback;
    return fallback;
  }
}