// lib/core/services/shop_room_service.dart
// 🏠 房型 / 房間 / 房務日曆 Service
// 功能：集中管理房型、房間、房務日曆相關 Firestore 讀取

import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ShopRoomService {
  ShopRoomService._();

  static final instance = ShopRoomService._();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? get _currentUser => _auth.currentUser;

  CollectionReference<Map<String, dynamic>> get _shops =>
      _firestore.collection('shops');

  // ===============================
  // 🐱 房型（RoomType）
  // ===============================

  CollectionReference<Map<String, dynamic>> roomTypesRef(String shopId) {
    return _shops.doc(shopId).collection('room_types');
  }

  Stream<List<Map<String, dynamic>>> streamRoomTypes(String shopId) {
    return roomTypesRef(shopId).snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return {...doc.data(), 'id': doc.id};
      }).toList();
    });
  }

  Future<List<Map<String, dynamic>>> getRoomTypes(String shopId) async {
    final snapshot = await roomTypesRef(shopId).get();

    return snapshot.docs.map((doc) {
      return {'id': doc.id, ...doc.data()};
    }).toList();
  }

  Future<void> createRoomType({
    required String shopId,
    required String name,
    required int capacity,
    required int price,
    required int totalRooms,
    required String description,
    required int extraPrice,
    required int width,
    required int depth,
    required int height,
    Map<String, dynamic>? extraData,
  }) async {
    final doc = roomTypesRef(shopId).doc();

    await doc.set({
      'name': name,
      'capacity': capacity,
      'price': price,
      'totalRooms': totalRooms,
      'description': description,
      'extraPrice': extraPrice,
      'width': width,
      'depth': depth,
      'height': height,
      'images': [],
      'isSingle': false,
      ...?extraData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateRoomType({
    required String shopId,
    required String roomTypeId,
    required String name,
    required int capacity,
    required int price,
    required bool isSingle,
  }) async {
    await roomTypesRef(shopId).doc(roomTypeId).update({
      'name': name,
      'capacity': capacity,
      'price': price,
      'isSingle': isSingle,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteRoomType({
    required String shopId,
    required String roomTypeId,
  }) async {
    await roomTypesRef(shopId).doc(roomTypeId).delete();
  }

  Future<String> uploadRoomTypeImage({
    required String shopId,
    required String roomTypeId,
    required Uint8List bytes,
    String contentType = 'image/jpeg',
  }) async {
    final ext = contentType == 'image/png'
        ? 'png'
        : contentType == 'image/webp'
        ? 'webp'
        : 'jpg';

    final fileName = 'room_${DateTime.now().millisecondsSinceEpoch}.$ext';

    final ref = FirebaseStorage.instance.ref().child(
      'shops/$shopId/room_types/$roomTypeId/$fileName',
    );

    await ref.putData(bytes, SettableMetadata(contentType: contentType));

    final url = await ref.getDownloadURL();

    await roomTypesRef(shopId).doc(roomTypeId).update({
      'images': FieldValue.arrayUnion([url]),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return url;
  }

  Future<void> deleteRoomTypeImage({
    required String shopId,
    required String roomTypeId,
    required String imageUrl,
  }) async {
    try {
      final ref = FirebaseStorage.instance.refFromURL(imageUrl);
      await ref.delete();

      await roomTypesRef(shopId).doc(roomTypeId).update({
        'images': FieldValue.arrayRemove([imageUrl]),
      });
    } catch (e) {
      print('刪除圖片錯誤: $e');
    }
  }
  // ===============================
  // 🏠 房間（Room）
  // ===============================

  CollectionReference<Map<String, dynamic>> roomsRef(String shopId) {
    return _shops.doc(shopId).collection('rooms');
  }

  Stream<List<Map<String, dynamic>>> streamRooms(String shopId) {
    return roomsRef(shopId).snapshots().asyncMap((snapshot) async {
      final roomTypesSnapshot = await roomTypesRef(shopId).get();

      final roomTypeMap = {
        for (final doc in roomTypesSnapshot.docs) doc.id: doc.data(),
      };

      return snapshot.docs.map((doc) {
        final data = doc.data();
        final roomTypeId = data['roomTypeId']?.toString() ?? '';
        final roomTypeData = roomTypeMap[roomTypeId];

        return {
          'id': doc.id,
          ...data,
          'roomTypeName': roomTypeData?['name'] ?? '未分類',
        };
      }).toList();
    });
  }

  Future<List<Map<String, dynamic>>> getRooms(String shopId) async {
    final snapshot = await roomsRef(shopId).get();

    return snapshot.docs.map((doc) {
      return {'id': doc.id, ...doc.data()};
    }).toList();
  }

  Future<void> createRoom({
    required String shopId,
    required String name,
    required String roomTypeId,
  }) async {
    await roomsRef(shopId).add({
      'name': name,
      'roomTypeId': roomTypeId,
      'enabled': true,
      'cameraIds': [],
      'blockedDates': [],
      'priceRules': [],
      'discountRules': [],
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateRoomStatus({
    required String shopId,
    required String roomId,
    required bool enabled,
  }) async {
    await roomsRef(shopId).doc(roomId).update({
      'enabled': enabled,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteRoom({
    required String shopId,
    required String roomId,
  }) async {
    await roomsRef(shopId).doc(roomId).delete();
  }

  Future<void> updateRoomBlockedDates({
    required String shopId,
    required String roomId,
    required List<String> blockedDates,
  }) async {
    await roomsRef(shopId).doc(roomId).update({
      'blockedDates': blockedDates,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateRoomPriceRules({
    required String shopId,
    required String roomId,
    required List<Map<String, dynamic>> rules,
  }) async {
    await roomsRef(shopId).doc(roomId).update({
      'priceRules': rules,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateRoomDiscountRules({
    required String shopId,
    required String roomId,
    required List<Map<String, dynamic>> rules,
  }) async {
    await roomsRef(shopId).doc(roomId).update({
      'discountRules': rules,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ===============================
  // 📅 房間日曆（Room Calendar）
  // ===============================

  CollectionReference<Map<String, dynamic>> roomCalendarRef(String shopId) {
    return _shops.doc(shopId).collection('room_calendar');
  }

  Stream<List<Map<String, dynamic>>> streamRoomCalendarByDate(
    String shopId,
    String date,
  ) {
    return roomCalendarRef(
      shopId,
    ).where('date', isEqualTo: date).snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return {'id': doc.id, ...doc.data()};
      }).toList();
    });
  }

  Future<void> setRoomStatus({
    required String shopId,
    required String roomId,
    required String date,
    required String status,
    String roomName = '',
  }) async {
    final docId = '${roomId}_$date';

    final oldDoc = await roomCalendarRef(shopId).doc(docId).get();
    final oldStatus = oldDoc.data()?['status'] ?? 'available';

    await roomCalendarRef(shopId).doc(docId).set({
      'roomId': roomId,
      'date': date,
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    await _firestore.collection('action_logs').add({
      'type': 'room_calendar_status_update',
      'shopId': shopId,
      'roomId': roomId,
      'roomName': roomName,
      'date': date,
      'fromStatus': oldStatus,
      'toStatus': status,
      'operatorUid': _currentUser?.uid,
      'operatorEmail': _currentUser?.email,
      'operatorRole': 'staff',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  String formatDateKey(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    final y = d.year.toString().padLeft(4, '0');
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '$y-$m-$day';
  }

  Future<List<Map<String, dynamic>>> getAvailableRoomTypes({
    required String shopId,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    final roomTypesSnapshot = await roomTypesRef(shopId).get();
    final roomTypes = roomTypesSnapshot.docs;

    final roomsSnapshot = await roomsRef(shopId).get();
    final rooms = roomsSnapshot.docs;

    final Map<String, List<QueryDocumentSnapshot<Map<String, dynamic>>>>
    roomMap = {};

    for (final room in rooms) {
      final data = room.data();

      if (data['enabled'] != true) continue;

      final typeId = data['roomTypeId'];
      if (typeId == null) continue;

      roomMap.putIfAbsent(typeId, () => []);
      roomMap[typeId]!.add(room);
    }

    final stayDates = <String>[];
    DateTime cursor = DateTime(startDate.year, startDate.month, startDate.day);

    while (cursor.isBefore(endDate)) {
      stayDates.add(formatDateKey(cursor));
      cursor = cursor.add(const Duration(days: 1));
    }
    final bookingsSnapshot = await _firestore
        .collection('bookings')
        .where('shopId', isEqualTo: shopId)
        .where(
          'status',
          whereIn: ['pending', 'confirmed', 'occupied', 'checked_in'],
        )
        .get();

    final bookings = bookingsSnapshot.docs.map((e) => e.data()).toList();

    final result = <Map<String, dynamic>>[];

    for (final typeDoc in roomTypes) {
      final type = typeDoc.data();
      final typeId = typeDoc.id;

      final typeRooms = roomMap[typeId] ?? [];
      if (typeRooms.isEmpty) continue;

      int minAvailableRooms = 999999;

      for (final date in stayDates) {
        int availableCount = 0;

        int bookedCount = 0;

        for (final booking in bookings) {
          final bookingRoomTypeId = (booking['roomTypeId'] ?? '').toString();

          if (bookingRoomTypeId != typeId) continue;

          final start = (booking['startDate'] as Timestamp).toDate();
          final end = (booking['endDate'] as Timestamp).toDate();

          DateTime temp = DateTime(start.year, start.month, start.day);

          while (temp.isBefore(end)) {
            final bookingDateKey = formatDateKey(temp);

            if (bookingDateKey == date) {
              bookedCount++;
              break;
            }

            temp = temp.add(const Duration(days: 1));
          }
        }

        final calendarSnapshot = await roomCalendarRef(
          shopId,
        ).where('date', isEqualTo: date).get();

        final calendarMap = {
          for (var doc in calendarSnapshot.docs) doc['roomId']: doc.data(),
        };

        for (final room in typeRooms) {
          final roomId = room.id;
          final cal = calendarMap[roomId];
          final status = cal?['status'] ?? 'available';

          // 🔥 前台庫存已經用 bookings 扣掉訂單
          // 這裡只扣後台手動關閉 / 維修的房間
          if (status == 'blocked') {
            continue;
          }

          final roomData = room.data();
          final List blocked = roomData['blockedDates'] ?? [];

          if (blocked.contains(date)) {
            continue;
          }

          availableCount++;
        }

        final realAvailableCount = availableCount - bookedCount;

        if (realAvailableCount < minAvailableRooms) {
          minAvailableRooms = realAvailableCount;
        }
      }

      result.add({
        'roomTypeId': typeId,
        'name': type['name'],
        'price': type['price'],
        'capacity': type['capacity'],
        'availableRooms': minAvailableRooms,
        'images': type['images'] ?? [],
        'description': type['description'] ?? '',
        'features': type['features'] ?? [],
        'extraPrice': type['extraPrice'] ?? 0,
        'width': type['width'] ?? 0,
        'depth': type['depth'] ?? 0,
        'height': type['height'] ?? 0,
      });
    }

    return result;
  }

  int calculateRoomPrice({
    required Map<String, dynamic> room,
    required int basePrice,
    required DateTime startDate,
    required DateTime endDate,
  }) {
    int total = 0;

    final List priceRules = room['priceRules'] ?? [];
    final List discountRules = room['discountRules'] ?? [];

    DateTime cursor = startDate;
    int days = 0;

    while (cursor.isBefore(endDate)) {
      int price = basePrice;
      final dateKey = formatDateKey(cursor);

      for (final rule in priceRules) {
        if (dateKey.compareTo(rule['start']) >= 0 &&
            dateKey.compareTo(rule['end']) <= 0) {
          final extra = rule['extra'];

          if (extra is num) {
            price += extra.toInt();
          }
        }
      }

      total += price;
      days++;
      cursor = cursor.add(const Duration(days: 1));
    }

    double discount = 1.0;

    for (final rule in discountRules) {
      if (days >= (rule['minDays'] ?? 0)) {
        discount = rule['discount'] ?? 1.0;
      }
    }

    return (total * discount).toInt();
  }
}
