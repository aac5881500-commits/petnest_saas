// lib/features/shop/pages/shop_booking_page.dart
//
// 前台預約頁（共用月曆版）
//
// 功能：
// - 第一眼先顯示月曆
// - 顯示每日價格 / 剩餘房數 / 不可預約狀態
// - 先選入住與退房
// - 再填預約資料
// - 送出前再次驗證區間
//
// 規則：
// - 第一次點：入住日
// - 第二次點：退房日
// - 若第二次點的日期 <= 入住日，則重新選入住日
// - 顯示區間晚數 / 總價 / 最少剩餘房數

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/services/booking_service.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/shared/widgets/booking_calendar.dart';

class ShopBookingPage extends StatefulWidget {
  const ShopBookingPage({
    super.key,
    required this.shopId,
  });

  final String shopId;

  @override
  State<ShopBookingPage> createState() => _ShopBookingPageState();
}

class _ShopBookingPageState extends State<ShopBookingPage> {
  final _formKey = GlobalKey<FormState>();

  final _customerNameController = TextEditingController();
  final _customerPhoneController = TextEditingController();
  final _petNameController = TextEditingController();
  final _petTypeController = TextEditingController();
  final _noteController = TextEditingController();

  bool _submitting = false;
  bool _checkingRange = false;

  DateTime? _startDate;
  DateTime? _endDate;
  String? _selectedServiceType;

  bool _rangeChecked = false;
  bool _rangeBookable = false;
  String _rangeMessage = '請先在月曆選擇入住與退房日期';

  int _rangeTotalPrice = 0;
  int _rangeMinRemainingRooms = 0;

  @override
  void dispose() {
    _customerNameController.dispose();
    _customerPhoneController.dispose();
    _petNameController.dispose();
    _petTypeController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  int get _nights {
    if (_startDate == null || _endDate == null) return 0;
    return BookingService.instance.calculateNights(
      startDate: _startDate!,
      endDate: _endDate!,
    );
  }

  bool get _canShowFormFields {
    return _startDate != null && _endDate != null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('我要預約'),
      ),
      body: StreamBuilder<Map<String, dynamic>?>(
        stream: ShopService.instance.streamShop(widget.shopId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text('讀取店家資料失敗：${snapshot.error}'),
            );
          }

          final shop = snapshot.data;
          if (shop == null) {
            return const Center(
              child: Text('找不到店家資料'),
            );
          }

          final List<dynamic> rawServiceTypes = shop['serviceTypes'] ?? [];
          final List<String> serviceTypes =
              rawServiceTypes.map((e) => e.toString()).toList();

          if (_selectedServiceType == null && serviceTypes.isNotEmpty) {
            _selectedServiceType = serviceTypes.first;
          }

          final today = _dateOnly(DateTime.now());
          final bookingEnabled = shop['bookingEnabled'] ?? true;
          final totalRooms = _toInt(shop['totalRooms'], fallback: 1);
          final maxAdvanceBookingDays =
              _toInt(shop['maxAdvanceBookingDays'], fallback: 30);
          final defaultPricePerNight =
              _toInt(shop['defaultPricePerNight'], fallback: 0);
          final lastDate = today.add(Duration(days: maxAdvanceBookingDays));

          return FutureBuilder<_FrontCalendarPayload>(
            future: _buildFrontCalendarPayload(
              shop: shop,
              firstDate: today,
              lastDate: lastDate,
            ),
            builder: (context, calendarSnapshot) {
              final payload = calendarSnapshot.data;

              return SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 760),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          shop['name'] ?? '未命名店家',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),

                        Text(
                          bookingEnabled ? '請先從月曆選擇日期區間' : '目前店家暫停開放預約',
                          style: TextStyle(
                            color: bookingEnabled ? null : Colors.red,
                          ),
                        ),

                        const SizedBox(height: 16),

                        _buildBookingIntroCard(
                          bookingEnabled: bookingEnabled,
                          totalRooms: totalRooms,
                          maxAdvanceBookingDays: maxAdvanceBookingDays,
                          defaultPricePerNight: defaultPricePerNight,
                        ),

                        const SizedBox(height: 16),

                        _buildCalendarCard(
                          bookingEnabled: bookingEnabled,
                          firstDate: today,
                          lastDate: lastDate,
                          payload: payload,
                          onDayTap: (date) => _handleCalendarTap(
                            shop: shop,
                            date: date,
                          ),
                        ),

                        const SizedBox(height: 16),

                        _buildRangeResultCard(),

                        if (_canShowFormFields) ...[
                          const SizedBox(height: 20),
                          const Divider(),
                          const SizedBox(height: 20),
                          const Text(
                            '預約資料',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 16),

                          Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                TextFormField(
                                  controller: _customerNameController,
                                  decoration: const InputDecoration(
                                    labelText: '聯絡人姓名',
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (value) {
                                    if (!_canSubmit(serviceTypes)) return null;
                                    if (value == null || value.trim().isEmpty) {
                                      return '請輸入聯絡人姓名';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 16),

                                TextFormField(
                                  controller: _customerPhoneController,
                                  keyboardType: TextInputType.phone,
                                  decoration: const InputDecoration(
                                    labelText: '聯絡電話',
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (value) {
                                    if (!_canSubmit(serviceTypes)) return null;
                                    if (value == null || value.trim().isEmpty) {
                                      return '請輸入聯絡電話';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 16),

                                TextFormField(
                                  controller: _petNameController,
                                  decoration: const InputDecoration(
                                    labelText: '寵物名字',
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (value) {
                                    if (!_canSubmit(serviceTypes)) return null;
                                    if (value == null || value.trim().isEmpty) {
                                      return '請輸入寵物名字';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 16),

                                TextFormField(
                                  controller: _petTypeController,
                                  decoration: const InputDecoration(
                                    labelText: '寵物類型（例如：貓 / 狗）',
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (value) {
                                    if (!_canSubmit(serviceTypes)) return null;
                                    if (value == null || value.trim().isEmpty) {
                                      return '請輸入寵物類型';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 16),

                                DropdownButtonFormField<String>(
                                  value: _selectedServiceType,
                                  items: serviceTypes.map((service) {
                                    return DropdownMenuItem<String>(
                                      value: service,
                                      child: Text(_serviceTypeText(service)),
                                    );
                                  }).toList(),
                                  onChanged: serviceTypes.isEmpty
                                      ? null
                                      : (value) {
                                          setState(() {
                                            _selectedServiceType = value;
                                          });
                                        },
                                  decoration: const InputDecoration(
                                    labelText: '服務類型',
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (value) {
                                    if (!_canSubmit(serviceTypes)) return null;
                                    if (serviceTypes.isNotEmpty &&
                                        (value == null || value.isEmpty)) {
                                      return '請選擇服務類型';
                                    }
                                    return null;
                                  },
                                ),

                                if (serviceTypes.isEmpty) ...[
                                  const SizedBox(height: 8),
                                  const Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      '此店家尚未設定服務項目，暫時無法預約。',
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],

                                const SizedBox(height: 16),

                                TextFormField(
                                  controller: _noteController,
                                  maxLines: 4,
                                  decoration: const InputDecoration(
                                    labelText: '備註',
                                    border: OutlineInputBorder(),
                                    alignLabelWithHint: true,
                                  ),
                                ),

                                const SizedBox(height: 24),

                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: _canSubmit(serviceTypes)
                                        ? () => _submitBooking(shop)
                                        : null,
                                    child: _submitting
                                        ? const SizedBox(
                                            height: 20,
                                            width: 20,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                            ),
                                          )
                                        : const Text('送出預約'),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildBookingIntroCard({
    required bool bookingEnabled,
    required int totalRooms,
    required int maxAdvanceBookingDays,
    required int defaultPricePerNight,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _infoRow('預約狀態', bookingEnabled ? '開放中' : '未開放'),
            const SizedBox(height: 8),
            _infoRow('總房數', '$totalRooms'),
            const SizedBox(height: 8),
            _infoRow('最遠可預約', '$maxAdvanceBookingDays 天內'),
            const SizedBox(height: 8),
            _infoRow('每晚預設價格', 'NT\$ $defaultPricePerNight'),
          ],
        ),
      ),
    );
  }

  Widget _buildCalendarCard({
    required bool bookingEnabled,
    required DateTime firstDate,
    required DateTime lastDate,
    required _FrontCalendarPayload? payload,
    required ValueChanged<DateTime> onDayTap,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '第一步：選擇日期區間',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              '先點入住日，再點退房日。若重選較早日期，會重新設定入住日。',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 12),

            if (payload == null)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              )
            else
              BookingCalendar(
                initialMonth: _startDate ?? firstDate,
                firstDate: firstDate,
                lastDate: lastDate,
                rangeStart: _startDate,
                rangeEnd: _endDate,
                blockedDateKeys: payload.blockedDateKeys,
                unbookableDateKeys: payload.unbookableDateKeys,
                priceMap: payload.priceMap,
                remainingRoomsMap: payload.remainingRoomsMap,
                onDayTap: bookingEnabled ? onDayTap : (_) {},
              ),

            const SizedBox(height: 12),

            if (_checkingRange)
              const Row(
                children: [
                  SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  SizedBox(width: 8),
                  Text('正在檢查日期區間...'),
                ],
              )
            else
              Text(
                (_startDate == null && _endDate == null)
                    ? '尚未選擇日期'
                    : (_endDate == null
                        ? '已選入住日：${_formatDate(_startDate!)}，請再點退房日'
                        : '已選區間：${_formatDate(_startDate!)} ～ ${_formatDate(_endDate!)}'),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRangeResultCard() {
    final Color color;
    if (!_rangeChecked) {
      color = Colors.grey;
    } else if (_rangeBookable) {
      color = Colors.green;
    } else {
      color = Colors.red;
    }

    return Card(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '第二步：確認可預約狀態',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Icon(
                  _rangeChecked
                      ? (_rangeBookable ? Icons.check_circle : Icons.cancel)
                      : Icons.info,
                  color: color,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _rangeMessage,
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),

            if (_rangeChecked && _rangeBookable) ...[
              const SizedBox(height: 12),
              _infoRow('入住日', _formatDate(_startDate!)),
              const SizedBox(height: 8),
              _infoRow('退房日', _formatDate(_endDate!)),
              const SizedBox(height: 8),
              _infoRow('晚數', '$_nights 晚'),
              const SizedBox(height: 8),
              _infoRow('區間總價', 'NT\$ $_rangeTotalPrice'),
              const SizedBox(height: 8),
              _infoRow('區間內最少剩餘房數', '$_rangeMinRemainingRooms'),
            ],
          ],
        ),
      ),
    );
  }

  Future<_FrontCalendarPayload> _buildFrontCalendarPayload({
    required Map<String, dynamic> shop,
    required DateTime firstDate,
    required DateTime lastDate,
  }) async {
    final blockedDateKeys =
        List<String>.from(shop['blockedDates'] ?? []).map((e) => e.toString()).toSet();

    final Map<String, int> priceMap = {};
    final Map<String, int> remainingRoomsMap = {};
    final Set<String> unbookableDateKeys = {};

    DateTime cursor = _dateOnly(firstDate);
    final last = _dateOnly(lastDate);

    while (!cursor.isAfter(last)) {
      final key = ShopService.instance.formatDateKey(cursor);

      priceMap[key] = ShopService.instance.getPriceForDate(shop, cursor);

      final remaining = await BookingService.instance.getRemainingRoomsForDate(
        shop: shop,
        date: cursor,
      );
      remainingRoomsMap[key] = remaining;

      final canBook = await BookingService.instance.isDateBookable(
        shop: shop,
        date: cursor,
      );

      if (!canBook) {
        unbookableDateKeys.add(key);
      }

      cursor = cursor.add(const Duration(days: 1));
    }

    return _FrontCalendarPayload(
      blockedDateKeys: blockedDateKeys,
      unbookableDateKeys: unbookableDateKeys,
      priceMap: priceMap,
      remainingRoomsMap: remainingRoomsMap,
    );
  }

  Future<void> _handleCalendarTap({
    required Map<String, dynamic> shop,
    required DateTime date,
  }) async {
    final tapped = _dateOnly(date);

    if (_checkingRange || _submitting) return;

    if (_startDate == null || (_startDate != null && _endDate != null)) {
      setState(() {
        _startDate = tapped;
        _endDate = null;
        _rangeChecked = false;
        _rangeBookable = false;
        _rangeMessage = '已選入住日，請再點退房日';
        _rangeTotalPrice = 0;
        _rangeMinRemainingRooms = 0;
      });
      return;
    }

    if (!tapped.isAfter(_startDate!)) {
      setState(() {
        _startDate = tapped;
        _endDate = null;
        _rangeChecked = false;
        _rangeBookable = false;
        _rangeMessage = '已重新設定入住日，請再點退房日';
        _rangeTotalPrice = 0;
        _rangeMinRemainingRooms = 0;
      });
      return;
    }

    setState(() {
      _endDate = tapped;
      _rangeChecked = false;
      _rangeBookable = false;
      _rangeMessage = '正在檢查日期區間...';
      _rangeTotalPrice = 0;
      _rangeMinRemainingRooms = 0;
      _checkingRange = true;
    });

    try {
      final result = await BookingService.instance.validateBookingRange(
        shop: shop,
        startDate: _startDate!,
        endDate: tapped,
      );

      final ok = result['ok'] == true;
      String message = (result['message'] ?? '').toString();

      int totalPrice = 0;
      int minRemainingRooms = 0;

      if (ok) {
        totalPrice = BookingService.instance.calculateTotalPrice(
          shop: shop,
          startDate: _startDate!,
          endDate: tapped,
        );

        minRemainingRooms = await _calculateMinRemainingRooms(
          shop: shop,
          startDate: _startDate!,
          endDate: tapped,
        );

        message = '此日期區間可預約';
      }

      if (!mounted) return;

      setState(() {
        _rangeChecked = true;
        _rangeBookable = ok;
        _rangeMessage = message;
        _rangeTotalPrice = totalPrice;
        _rangeMinRemainingRooms = minRemainingRooms;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _rangeChecked = true;
        _rangeBookable = false;
        _rangeMessage = '檢查失敗：$e';
        _rangeTotalPrice = 0;
        _rangeMinRemainingRooms = 0;
      });
    } finally {
      if (mounted) {
        setState(() {
          _checkingRange = false;
        });
      }
    }
  }

  Future<int> _calculateMinRemainingRooms({
    required Map<String, dynamic> shop,
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    final stayDates = BookingService.instance.getStayDates(
      startDate: startDate,
      endDate: endDate,
    );

    if (stayDates.isEmpty) return 0;

    int? minValue;

    for (final date in stayDates) {
      final remaining = await BookingService.instance.getRemainingRoomsForDate(
        shop: shop,
        date: date,
      );

      if (minValue == null || remaining < minValue) {
        minValue = remaining;
      }
    }

    return minValue ?? 0;
  }

  bool _canSubmit(List<String> serviceTypes) {
    return !_submitting &&
        !_checkingRange &&
        _rangeChecked &&
        _rangeBookable &&
        _startDate != null &&
        _endDate != null &&
        serviceTypes.isNotEmpty;
  }

  Future<void> _submitBooking(Map<String, dynamic> shop) async {
    if (!_formKey.currentState!.validate()) return;

    if (_startDate == null || _endDate == null) {
      _showSnackBar('請先選擇入住與退房日期');
      return;
    }

    if (_nights <= 0) {
      _showSnackBar('退房日必須晚於入住日');
      return;
    }

    if (_selectedServiceType == null || _selectedServiceType!.isEmpty) {
      _showSnackBar('請選擇服務類型');
      return;
    }

    setState(() {
      _submitting = true;
    });

    try {
      final validateResult = await BookingService.instance.validateBookingRange(
        shop: shop,
        startDate: _startDate!,
        endDate: _endDate!,
      );

      if (validateResult['ok'] != true) {
        if (!mounted) return;
        _showSnackBar((validateResult['message'] ?? '此日期不可預約').toString());
        return;
      }

      final totalPrice = BookingService.instance.calculateTotalPrice(
        shop: shop,
        startDate: _startDate!,
        endDate: _endDate!,
      );

      final pricePerNight = _nights > 0 ? (totalPrice ~/ _nights) : 0;

      final bookingId = await BookingService.instance.createBooking(
        shopId: widget.shopId,
        customerName: _customerNameController.text,
        customerPhone: _customerPhoneController.text,
        petName: _petNameController.text,
        petType: _petTypeController.text,
        serviceType: _selectedServiceType!,
        startDate: _startDate!,
        endDate: _endDate!,
        nights: _nights,
        note: _noteController.text,
      );

      await BookingService.instance.updateBooking(
        bookingId: bookingId,
        totalPrice: totalPrice,
        pricePerNight: pricePerNight,
      );

      if (!mounted) return;

      _showSnackBar('預約已送出');
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('送出失敗：$e');
    } finally {
      if (mounted) {
        setState(() {
          _submitting = false;
        });
      }
    }
  }

  Widget _infoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(child: Text(value)),
      ],
    );
  }

  void _showSnackBar(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  DateTime _dateOnly(DateTime date) {
    return DateTime(date.year, date.month, date.day);
  }

  int _toInt(dynamic value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value) ?? fallback;
    return fallback;
  }

  String _formatDate(DateTime date) {
    final y = date.year.toString().padLeft(4, '0');
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  String _serviceTypeText(String value) {
    switch (value) {
      case 'overnight':
        return '住宿';
      case 'daycare':
        return '日托';
      case 'grooming':
        return '美容';
      case 'training':
        return '訓練';
      default:
        return value;
    }
  }
}

class _FrontCalendarPayload {
  const _FrontCalendarPayload({
    required this.blockedDateKeys,
    required this.unbookableDateKeys,
    required this.priceMap,
    required this.remainingRoomsMap,
  });

  final Set<String> blockedDateKeys;
  final Set<String> unbookableDateKeys;
  final Map<String, int> priceMap;
  final Map<String, int> remainingRoomsMap;
}