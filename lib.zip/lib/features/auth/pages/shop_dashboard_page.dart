// 檔案名稱：lib/features/auth/pages/shop_dashboard_page.dart
// 說明：店家後台首頁

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/features/auth/pages/shop_basic_info_page.dart';
import 'package:petnest_saas/features/auth/pages/shop_business_info_page.dart';
import 'package:petnest_saas/features/shop/pages/shop_public_page.dart';
import 'package:petnest_saas/features/auth/pages/shop_media_page.dart';
import 'package:petnest_saas/features/auth/pages/shop_booking_manage_page.dart';

class ShopDashboardPage extends StatelessWidget {
  const ShopDashboardPage({
    super.key,
    required this.shopId,
  });

  final String shopId;

  /// 判斷基本資料是否完成
  bool _isProfileComplete(Map<String, dynamic> shop) {
    return (shop['businessType'] ?? '') != '' &&
        (shop['city'] ?? '') != '' &&
        (shop['address'] ?? '') != '' &&
        (shop['phone'] ?? '') != '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('店家後台'),
      ),
      body: StreamBuilder<Map<String, dynamic>?>(
        stream: ShopService.instance.streamShop(shopId),
        builder: (context, snapshot) {
          /// loading
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          /// error
          if (snapshot.hasError) {
            return Center(child: Text('讀取失敗：${snapshot.error}'));
          }

          final shop = snapshot.data;

          /// no data
          if (shop == null) {
            return const Center(child: Text('找不到店家資料'));
          }

          final isComplete = _isProfileComplete(shop);

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              /// 店名
              Text(
                shop['name'] ?? '未命名店家',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              /// 未完成提示
              if (!isComplete)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    '⚠️ 請先完成店家基本資料，才能使用完整功能',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),

              const SizedBox(height: 20),

              /// ===== 基本資料 =====
              _MenuTile(
                title: '店家基本資料',
                subtitle: '設定店名、類型、地址、電話與介紹',
                icon: Icons.store,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ShopBasicInfoPage(shopId: shopId),
                    ),
                  );
                },
              ),

              /// ===== 營業資訊 =====
              _MenuTile(
                title: '營業資訊',
                subtitle: '設定營業時間與服務項目',
                icon: Icons.schedule,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ShopBusinessInfoPage(shopId: shopId),
                    ),
                  );
                },
              ),

              /// ===== 前台預覽 =====
              _MenuTile(
                title: '前台預覽',
                subtitle: '查看客戶看到的頁面',
                icon: Icons.visibility,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ShopPublicPage(shopId: shopId),
                    ),
                  );
                },
              ),

              /// ===== 店家封面 / Logo =====
              _MenuTile(
                title: '店家封面 / Logo',
                subtitle: '上傳 Logo 與封面圖片',
                icon: Icons.image,
                enabled: true,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ShopMediaPage(shopId: shopId),
                    ),
                  );
                },
              ),

              /// ===== 預約管理 =====
              _MenuTile(
                title: '預約管理',
                subtitle: isComplete ? '查看與管理店家預約' : '請先完成基本資料',
                icon: Icons.calendar_month,
                enabled: isComplete,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ShopBookingManagePage(shopId: shopId),
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}

/// 共用 Menu 元件
class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    this.enabled = true,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.4,
      child: Card(
        child: ListTile(
          leading: Icon(icon),
          title: Text(title),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: enabled ? onTap : null,
        ),
      ),
    );
  }
}