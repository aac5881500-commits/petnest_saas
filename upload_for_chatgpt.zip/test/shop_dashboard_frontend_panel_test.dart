// 檔案名稱：test/shop_dashboard_frontend_panel_test.dart
// 功能說明：驗證店家 Dashboard 左側前台預覽固定 360×780，以及窄畫面改用 Dialog。

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:petnest_saas/features/shop/widgets/shop_frontend_test_panel.dart';

void main() {
  const Size previewSize = ShopFrontendTestPanel.dashboardFrontendPreviewSize;

  Widget previewPanel({required VoidCallback onClose}) {
    return ShopFrontendTestPanel(
      shopId: 'shop-test',
      shopCode: 'demo',
      onClose: onClose,
      previewBodyOverride: const _ViewportProbe(),
    );
  }

  testWidgets('寬畫面可以顯示內嵌 ShopFrontendTestPanel', (WidgetTester tester) async {
    await tester.pumpWidget(const _EmbedApp(pageWidth: 1920, openPref: true));
    await tester.pump();

    expect(find.byType(ShopFrontendTestPanel), findsOneWidget);
    expect(
      find.byKey(ShopDashboardFrontendEmbedHost.embeddedPreviewKey),
      findsOneWidget,
    );
    expect(find.text('dashboard-main'), findsOneWidget);
  });

  testWidgets('窄畫面不顯示內嵌 ShopFrontendTestPanel', (WidgetTester tester) async {
    await tester.pumpWidget(const _EmbedApp(pageWidth: 1279, openPref: false));
    await tester.pump();

    expect(find.byType(ShopFrontendTestPanel), findsNothing);
    expect(
      find.byKey(ShopDashboardFrontendEmbedHost.embeddedPreviewKey),
      findsNothing,
    );
    expect(find.text('dashboard-main'), findsOneWidget);
  });

  testWidgets('窄畫面按預覽後顯示 Dialog 內的 ShopFrontendTestPanel，關閉後消失', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (BuildContext context) {
            return Scaffold(
              appBar: AppBar(
                actions: <Widget>[
                  TextButton(
                    onPressed: () {
                      showShopFrontendPreviewDialog(
                        context: context,
                        shopId: 'shop-test',
                        shopCode: 'demo',
                        previewBodyOverride: const _ViewportProbe(),
                      );
                    },
                    child: const Text('前台'),
                  ),
                ],
              ),
              body: const Text('dashboard-main'),
            );
          },
        ),
      ),
    );

    expect(find.byType(ShopFrontendTestPanel), findsNothing);
    await tester.tap(find.text('前台'));
    await tester.pumpAndSettle();
    expect(find.byType(Dialog), findsOneWidget);
    expect(find.byType(ShopFrontendTestPanel), findsOneWidget);

    await tester.tap(find.byTooltip('關閉'));
    await tester.pumpAndSettle();
    expect(find.byType(ShopFrontendTestPanel), findsNothing);
    expect(find.text('dashboard-main'), findsOneWidget);
  });

  testWidgets('三種手機尺寸選項不存在，viewport 固定 360×780', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 400,
            height: 860,
            child: previewPanel(onClose: () {}),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(find.textContaining('小手機'), findsNothing);
    expect(find.textContaining('標準手機'), findsNothing);
    expect(find.textContaining('大手機'), findsNothing);
    expect(find.textContaining('393×852'), findsNothing);
    expect(find.textContaining('430×932'), findsNothing);
    expect(
      find.text(
        'viewport=${previewSize.width.toInt()}x${previewSize.height.toInt()}',
      ),
      findsOneWidget,
    );
  });

  testWidgets('窄畫面沒有 RenderFlex overflow', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(500, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const _EmbedApp(pageWidth: 500, openPref: false));
    await tester.pump();

    expect(tester.takeException(), isNull);
    expect(find.text('dashboard-main'), findsOneWidget);
    expect(find.byType(ShopFrontendTestPanel), findsNothing);
  });

  testWidgets('從寬畫面縮到窄畫面後，重新放寬不會自動跳出內嵌預覽', (WidgetTester tester) async {
    await tester.pumpWidget(const _AutoCloseApp(initialWidth: 1920));
    await tester.pump();
    expect(find.byType(ShopFrontendTestPanel), findsOneWidget);

    final _AutoCloseAppState state = tester.state(find.byType(_AutoCloseApp));
    state.setWidth(500);
    await tester.pump();
    await tester.pump();
    expect(find.byType(ShopFrontendTestPanel), findsNothing);
    expect(state.openPref, isFalse);

    state.setWidth(1920);
    await tester.pump();
    expect(find.byType(ShopFrontendTestPanel), findsNothing);
    expect(state.openPref, isFalse);
  });

  test('斷點：1920 與 1366 可內嵌，1279、768、500 不可內嵌', () {
    expect(ShopDashboardFrontendEmbedHost.canEmbed(1920), isTrue);
    expect(ShopDashboardFrontendEmbedHost.canEmbed(1366), isTrue);
    expect(ShopDashboardFrontendEmbedHost.canEmbed(1280), isTrue);
    expect(ShopDashboardFrontendEmbedHost.canEmbed(1279), isFalse);
    expect(ShopDashboardFrontendEmbedHost.canEmbed(768), isFalse);
    expect(ShopDashboardFrontendEmbedHost.canEmbed(500), isFalse);
  });
}

class _ViewportProbe extends StatelessWidget {
  const _ViewportProbe();

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.sizeOf(context);
    return Text('viewport=${size.width.toInt()}x${size.height.toInt()}');
  }
}

class _EmbedApp extends StatelessWidget {
  const _EmbedApp({required this.pageWidth, required this.openPref});

  final double pageWidth;
  final bool openPref;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MediaQuery(
        data: MediaQueryData(size: Size(pageWidth, 900)),
        child: Scaffold(
          body: SizedBox(
            width: pageWidth,
            height: 900,
            child: ShopDashboardFrontendEmbedHost(
              pageWidth: pageWidth,
              openPref: openPref,
              preview: ShopFrontendTestPanel(
                shopId: 'shop-test',
                shopCode: 'demo',
                onClose: () {},
                previewBodyOverride: const _ViewportProbe(),
              ),
              main: const Center(child: Text('dashboard-main')),
              onAutoClose: () {},
            ),
          ),
        ),
      ),
    );
  }
}

class _AutoCloseApp extends StatefulWidget {
  const _AutoCloseApp({required this.initialWidth});

  final double initialWidth;

  @override
  State<_AutoCloseApp> createState() => _AutoCloseAppState();
}

class _AutoCloseAppState extends State<_AutoCloseApp> {
  late double width = widget.initialWidth;
  bool openPref = true;

  void setWidth(double next) {
    setState(() {
      width = next;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MediaQuery(
        data: MediaQueryData(size: Size(width, 900)),
        child: Scaffold(
          body: SizedBox(
            width: width,
            height: 900,
            child: ShopDashboardFrontendEmbedHost(
              pageWidth: width,
              openPref: openPref,
              preview: ShopFrontendTestPanel(
                shopId: 'shop-test',
                shopCode: 'demo',
                onClose: () {},
                previewBodyOverride: const _ViewportProbe(),
              ),
              main: const Center(child: Text('dashboard-main')),
              onAutoClose: () {
                setState(() {
                  openPref = false;
                });
              },
            ),
          ),
        ),
      ),
    );
  }
}
