// 檔案名稱：test/home_banner_complete_poster_test.dart
// 功能說明：首頁完整海報的模式、16:9、舊圖相容、共用編輯欄位與點擊跳轉。

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:petnest_saas/core/models/home_banner_display.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/core/models/modern_banner_frame_setting.dart';
import 'package:petnest_saas/core/models/store_banner_model.dart';
import 'package:petnest_saas/features/shop/widgets/media/home_banner_editor_panel.dart';
import 'package:petnest_saas/features/shop/widgets/store/store_banner_view.dart';

void main() {
  test('新建首頁海報預設為完整海報模式', () {
    final StoreBannerModel banner = StoreBannerModel(
      id: 'home_new',
      enabled: true,
      contentMode: StoreBannerContentModes.imageOnly,
      actionType: HomeBannerActionTypes.none,
    );
    expect(banner.contentMode, StoreBannerContentModes.imageOnly);
    expect(banner.isCompletePoster, isTrue);
    expect(banner.title, isEmpty);
    expect(banner.subtitle, isEmpty);
    expect(banner.ctaText, isEmpty);
    expect(banner.overlayMode, StoreBannerOverlayModes.none);
    expect(banner.toMap().containsKey('contentMode'), isTrue);
  });

  test('完整海報前台用原圖，舊套版仍讀 renderedImageUrl', () {
    final StoreBannerModel complete = StoreBannerModel(
      id: 'new',
      contentMode: StoreBannerContentModes.imageOnly,
      imageUrl: 'https://example.com/full.jpg',
      renderedImageUrl: 'https://example.com/old-render.jpg',
      title: '舊標題',
    );
    expect(complete.isCompletePoster, isTrue);
    expect(complete.frontImageUrl, 'https://example.com/full.jpg');

    final StoreBannerModel legacy =
        StoreBannerModel.fromMap(const <String, dynamic>{
          'id': 'old',
          'contentMode': 'template_overlay',
          'imageUrl': 'https://example.com/raw.jpg',
          'renderedImageUrl': 'https://example.com/baked.jpg',
          'title': '舊標題',
          'ctaText': '立即預約',
          'ctaEnabled': true,
        });
    expect(legacy.isCompletePoster, isFalse);
    expect(legacy.frontImageUrl, 'https://example.com/baked.jpg');
    expect(legacy.title, '舊標題');
  });

  test('完整海報固定 16:9，舊海報輪播沿用原本比例', () {
    expect(HomeBannerDisplay.isSixteenByNine(1600, 900), isTrue);
    expect(HomeBannerDisplay.isSixteenByNine(800, 800), isFalse);
    expect(HomeBannerDisplay.aspectRatio, closeTo(16 / 9, 0.0001));

    final StoreBannerModel complete = StoreBannerModel(
      id: 'full',
      contentMode: StoreBannerContentModes.imageOnly,
      sizePreset: StoreBannerSizePresets.large,
    );
    final StoreBannerModel legacy = StoreBannerModel(
      id: 'old',
      contentMode: StoreBannerContentModes.templateOverlay,
      sizePreset: StoreBannerSizePresets.small,
    );
    expect(
      HomeBannerDisplay.frameAspect(
        banners: <StoreBannerModel>[complete],
        legacyAspect: 2.4,
      ),
      HomeBannerDisplay.aspectRatio,
    );
    expect(
      HomeBannerDisplay.frameAspect(
        banners: <StoreBannerModel>[legacy],
        legacyAspect: 2.4,
      ),
      2.4,
    );
    expect(
      HomeBannerDisplay.outerPadding(HomeBannerDisplaySize.small).left,
      16,
    );
    expect(
      HomeBannerDisplay.outerPadding(HomeBannerDisplaySize.large),
      EdgeInsets.zero,
    );
  });

  test('點擊跳轉仍依動作類型判斷', () {
    final StoreBannerModel booking = StoreBannerModel(
      id: 'go',
      contentMode: StoreBannerContentModes.imageOnly,
      actionType: HomeBannerActionTypes.booking,
    );
    expect(booking.hasNavigableAction, isTrue);
    expect(HomeBannerDisplay.validateAction(booking), isNull);

    final StoreBannerModel url = booking.copyWith(
      actionType: HomeBannerActionTypes.url,
      actionTargetId: 'https://example.com/promo',
    );
    expect(url.hasNavigableAction, isTrue);
    expect(HomeBannerDisplay.validateAction(url), isNull);

    final StoreBannerModel badUrl = url.copyWith(actionTargetId: 'notaurl');
    expect(badUrl.hasNavigableAction, isFalse);
    expect(
      HomeBannerDisplay.validateAction(badUrl),
      '請輸入 http 或 https 開頭的外部網址',
    );

    final StoreBannerModel product = booking.copyWith(
      actionType: HomeBannerActionTypes.product,
    );
    expect(HomeBannerDisplay.validateAction(product), '請選擇商品');
    expect(
      HomeBannerDisplay.validateAction(product.copyWith(actionTargetId: 'p1')),
      isNull,
    );
  });

  test('桌機與手機共用同一份編輯欄位與儲存入口', () {
    final String source = File(
      'lib/features/shop/pages/shop_media_page.dart',
    ).readAsStringSync();
    expect('HomeBannerEditorPanel('.allMatches(source).length, 1);
    expect('_editorColumn()'.allMatches(source).length, 3);
    expect(source.contains('_desktopStudio'), isTrue);
    expect(source.contains('_narrowStudio'), isTrue);
    expect(source.contains('PetNestBannerEditorPage'), isFalse);
    expect(source.contains('內容來源模式'), isFalse);
    expect(source.contains('captureJpeg'), isFalse);
    expect(HomeBannerEditorPanel.sectionTitles, <String>[
      '海報圖片',
      '海報狀態',
      '點擊後動作',
    ]);
  });

  testWidgets('完整海報不畫文字、按鈕、漸層，而且固定 16:9', (WidgetTester tester) async {
    var taps = 0;
    final StoreBannerModel banner = StoreBannerModel(
      id: 'poster',
      contentMode: StoreBannerContentModes.imageOnly,
      sizePreset: StoreBannerSizePresets.large,
      title: '不該出現',
      subtitle: '也不該出現',
      ctaText: '按鈕',
      ctaEnabled: true,
      overlayMode: StoreBannerOverlayModes.left,
      actionType: HomeBannerActionTypes.rooms,
    );

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Align(
            alignment: Alignment.topCenter,
            child: SizedBox(
              width: 360,
              child: StoreBannerView(
                banner: banner,
                theme: HomeThemeModel.modernDefault,
                scope: PetNestBannerScope.home,
                onTap: () => taps += 1,
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    final Size size = tester.getSize(find.byType(StoreBannerView));
    expect(size.width / size.height, closeTo(16 / 9, 0.02));
    expect(find.text('不該出現'), findsNothing);
    expect(find.text('也不該出現'), findsNothing);
    expect(find.text('按鈕'), findsNothing);
    expect(
      find.byWidgetPredicate(
        (Widget widget) =>
            widget is DecoratedBox &&
            widget.decoration is BoxDecoration &&
            (widget.decoration as BoxDecoration).gradient != null,
      ),
      findsNothing,
    );

    await tester.tap(find.byType(StoreBannerView));
    expect(taps, 1);
  });

  testWidgets('編輯面板只提供完整海報欄位，舊套版會提示更換', (WidgetTester tester) async {
    final StoreBannerModel legacy = StoreBannerModel(
      id: 'legacy',
      contentMode: StoreBannerContentModes.templateOverlay,
      title: '舊標題',
    );
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: HomeBannerEditorPanel(
              shopId: 'shop',
              draft: legacy,
              busy: false,
              uploading: false,
              onChanged: (_) {},
              onPickImage: () {},
              onRemoveImage: () {},
              onDelete: () {},
            ),
          ),
        ),
      ),
    );
    expect(find.text('海報圖片'), findsOneWidget);
    expect(find.text('海報狀態'), findsOneWidget);
    expect(find.text('點擊後動作'), findsOneWidget);
    expect(find.text('更換為完整海報'), findsOneWidget);
    expect(find.textContaining('此為舊版套版海報'), findsOneWidget);
    expect(find.text('快速版型'), findsNothing);
    expect(find.text('內容來源模式'), findsNothing);
    expect(find.text('標題'), findsNothing);
  });
}
