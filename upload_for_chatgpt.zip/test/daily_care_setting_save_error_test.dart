// 檔案名稱：test/daily_care_setting_save_error_test.dart
// 功能說明：儲存錯誤轉成店主可讀中文，不露出 converted Future

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:petnest_saas/core/services/daily_care_setting_service.dart';

void main() {
  test('permission-denied 顯示權限文案', () {
    final DailyCareSettingSaveException parsed =
        DailyCareSettingSaveException.fromError(
          FirebaseException(
            plugin: 'cloud_firestore',
            code: 'permission-denied',
            message: 'Missing or insufficient permissions.',
          ),
        );
    expect(parsed.message, '沒有儲存每日照護設定的權限');
  });

  test('revision 衝突顯示重新載入', () {
    const DailyCareSettingSaveException parsed =
        DailyCareSettingSaveException(
          '設定已被其他人更新，請重新載入後再儲存',
          code: 'revision-conflict',
        );
    expect(
      DailyCareSettingSaveException.fromError(parsed).message,
      '設定已被其他人更新，請重新載入後再儲存',
    );
  });

  test('converted Future 不直接顯示給店主', () {
    final DailyCareSettingSaveException parsed =
        DailyCareSettingSaveException.fromError(
          Exception(
            'Error: Dart exception thrown from converted Future. Use the dart:js_util exception helper to extract it.',
          ),
        );
    expect(parsed.message.contains('converted Future'), isFalse);
    expect(parsed.message, '儲存失敗，請稍後再試');
  });
}
