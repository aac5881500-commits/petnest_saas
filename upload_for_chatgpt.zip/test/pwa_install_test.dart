import 'package:flutter_test/flutter_test.dart';
import 'package:petnest_saas/core/services/pwa_install_status.dart';

void main() {
  test('已在獨立視窗時視為已安裝', () {
    const PwaInstallStatus status = PwaInstallStatus(
      standalone: true,
      canPrompt: false,
      rememberedInstalled: false,
      secureContext: true,
      browser: 'chrome',
    );
    expect(status.installed, isTrue);
    expect(pwaInstallGuide(status), contains('已安裝'));
  });

  test('瀏覽器再次提供安裝提示時，不把舊紀錄當成已安裝', () {
    const PwaInstallStatus status = PwaInstallStatus(
      standalone: false,
      canPrompt: true,
      rememberedInstalled: true,
      secureContext: true,
      browser: 'edge',
    );
    expect(status.installed, isFalse);
  });

  test('各瀏覽器說明不宣稱都能一鍵安裝', () {
    const List<String> browsers = <String>[
      'chrome',
      'edge',
      'safari',
      'firefox',
      'other',
    ];
    for (final String browser in browsers) {
      final String guide = pwaInstallGuide(
        PwaInstallStatus(
          standalone: false,
          canPrompt: false,
          rememberedInstalled: false,
          secureContext: true,
          browser: browser,
        ),
      );
      expect(guide.contains('所有瀏覽器'), isFalse);
      expect(guide, isNotEmpty);
    }
    expect(
      pwaInstallGuide(
        const PwaInstallStatus(
          standalone: false,
          canPrompt: false,
          rememberedInstalled: false,
          secureContext: true,
          browser: 'safari',
        ),
      ),
      contains('加入 Dock'),
    );
    expect(
      pwaInstallGuide(
        const PwaInstallStatus(
          standalone: false,
          canPrompt: false,
          rememberedInstalled: false,
          secureContext: false,
          browser: 'chrome',
        ),
      ),
      contains('https'),
    );
  });
}
