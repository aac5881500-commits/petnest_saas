// 檔案名稱：test/point_shop_notice_dialog_test.dart
// 功能說明：驗證本店點數提醒的確認判斷，以及手機與桌機 Dialog 不溢出。

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:petnest_saas/core/models/point_notice_acceptance.dart';
import 'package:petnest_saas/features/member/widgets/point_shop_notice_dialog.dart';

void main() {
  test('每位會員、每間店、規則更新後才需要再次確認', () {
    expect(
      PointNoticeAcceptance.needsPrompt(
        pointsEnabled: false,
        hasAcceptance: false,
      ),
      isFalse,
    );
    expect(
      PointNoticeAcceptance.needsPrompt(
        pointsEnabled: true,
        hasAcceptance: false,
      ),
      isTrue,
    );
    expect(
      PointNoticeAcceptance.needsPrompt(
        pointsEnabled: true,
        hasAcceptance: true,
      ),
      isFalse,
    );

    final DateTime acceptedAt = DateTime.utc(2026, 1, 1);
    final DateTime sameRules = DateTime.utc(2026, 1, 1);
    final DateTime newerRules = DateTime.utc(2026, 2, 1);
    expect(
      PointNoticeAcceptance.needsPrompt(
        pointsEnabled: true,
        hasAcceptance: true,
        acceptedRulesUpdatedAt: acceptedAt,
        currentRulesUpdatedAt: sameRules,
      ),
      isFalse,
    );
    expect(
      PointNoticeAcceptance.needsPrompt(
        pointsEnabled: true,
        hasAcceptance: true,
        acceptedRulesUpdatedAt: acceptedAt,
        currentRulesUpdatedAt: newerRules,
      ),
      isTrue,
    );
    expect(
      PointNoticeAcceptance.needsPrompt(
        pointsEnabled: true,
        hasAcceptance: true,
        currentRulesUpdatedAt: newerRules,
      ),
      isTrue,
    );
  });

  testWidgets('手機 390 與桌機 Dialog 不溢出，確認鈕不是滿版', (WidgetTester tester) async {
    await _pumpNotice(tester, const Size(390, 844), requireAcceptance: true);
    expect(tester.takeException(), isNull);
    expect(find.text('「毛孩子旅店」專屬點數提醒'), findsOneWidget);
    expect(find.textContaining('測試店家'), findsNothing);
    expect(find.byTooltip('關閉'), findsNothing);
    final Size button = tester.getSize(
      find.widgetWithText(FilledButton, '我了解本店點數規則'),
    );
    expect(button.width, inInclusiveRange(180, 220));
    expect(button.height, inInclusiveRange(42, 44));
    final Rect buttonRect = tester.getRect(
      find.widgetWithText(FilledButton, '我了解本店點數規則'),
    );
    expect(buttonRect.bottom, lessThanOrEqualTo(844));
    expect(buttonRect.left, greaterThanOrEqualTo(20));
    expect(buttonRect.right, lessThanOrEqualTo(370));

    await _pumpNotice(tester, const Size(1440, 900), requireAcceptance: false);
    expect(tester.takeException(), isNull);
    expect(find.text('關閉'), findsOneWidget);
    expect(find.byTooltip('關閉'), findsOneWidget);
    final Rect card = tester.getRect(
      find.byKey(const Key('point-shop-notice-card')),
    );
    expect(card.width, 460);
    expect(card.height, lessThan(760));
  });
}

Future<void> _pumpNotice(
  WidgetTester tester,
  Size size, {
  required bool requireAcceptance,
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(
        body: PointShopNoticeDialog(
          shopName: '毛孩子旅店',
          requireAcceptance: requireAcceptance,
          saving: false,
          maxHeight: size.height - 48,
          onPrimary: () {},
          onDismiss: () {},
        ),
      ),
    ),
  );
  await tester.pump();
}
