import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_block.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_editor_overlay.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_settings_card.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_style.dart';

void main() {
  const HomeThemeModel theme = HomeThemeModel(
    backgroundColorValue: 0xFFFFFBF7,
    cardColorValue: 0xFFFFFFFF,
    cardBorderColorValue: 0xFFFFD9B3,
    primaryColorValue: 0xFFFF8A00,
    textColorValue: 0xFF3A2A20,
  );

  test('old appearance without brand fields keeps the centered header defaults', () {
    final StoreBrandStyle missing = StoreBrandStyle.fromMap(<String, dynamic>{
      'headerSubtitle': '溫暖的家',
    });
    expect(missing.x, 0.5);
    expect(missing.y, 0);
    expect(missing.widthRatio, StoreBrandStyle.defaultWidthRatio);
    expect(missing.nameColorValue, isNull);
    expect(missing.subtitleColorValue, isNull);
    expect(missing.nameFontSize, 18);
    expect(missing.subtitleFontSize, 12);
    expect(missing.textAlign, 'center');
    expect(missing.logoPlacement, 'leading');
    expect(missing.textShadowEnabled, isFalse);

    final StoreBrandStyle trailing = StoreBrandStyle.fromMap(<String, dynamic>{
      'showLeftHeaderIcon': false,
      'showRightHeaderIcon': true,
      'rightHeaderIcon': 'star',
    });
    expect(trailing.logoPlacement, 'trailing');
    expect(trailing.fallbackIcon, 'star');

    final StoreBrandStyle hidden = StoreBrandStyle.fromMap(<String, dynamic>{
      'showLeftHeaderIcon': false,
      'showRightHeaderIcon': false,
    });
    expect(hidden.logoPlacement, 'none');

    final StoreBrandStyle saved = StoreBrandStyle.fromMap(<String, dynamic>{
      'homepageBrandX': 0.2,
      'homepageBrandY': 0.4,
      'homepageBrandWidthRatio': 2,
      'homepageBrandLogoPlacement': 'none',
      'homepageBrandNameColor': 0xFF111111,
      'homepageBrandNameFontSize': 80,
      'homepageBrandSubtitleFontSize': 4,
    });
    expect(saved.x, 0.2);
    expect(saved.y, 0.4);
    expect(saved.widthRatio, 1);
    expect(saved.logoPlacement, 'none');
    expect(saved.nameColorValue, 0xFF111111);
    expect(saved.nameFontSize, 48);
    expect(saved.subtitleFontSize, 10);
    expect(saved.toMap()['showLeftHeaderIcon'], isFalse);
  });

  test('normalized position round-trips inside the safe area', () {
    const Size parent = Size(390, 700);
    const double width = 280;
    const double height = 64;
    final Rect travel = StoreBrandGeometry.travel(
      parent: parent,
      blockWidth: width,
      blockHeight: height,
      bottomObstacle: 80,
    );
    final Offset back = StoreBrandGeometry.denormalize(
      x: 0.35,
      y: 0.2,
      travel: travel,
    );
    final Offset again = StoreBrandGeometry.normalize(
      topLeft: back,
      travel: travel,
    );
    expect(again.dx, closeTo(0.35, 0.0001));
    expect(again.dy, closeTo(0.2, 0.0001));
    expect(back.dx, inInclusiveRange(travel.left, travel.right));
    expect(back.dy, inInclusiveRange(travel.top, travel.bottom));
    expect(
      StoreBrandGeometry.widthFor(390, 0.1),
      StoreBrandGeometry.widthFor(390, 0.3),
    );
  });

  testWidgets('dragging keeps the press point and does not jump on release', (
    WidgetTester tester,
  ) async {
    StoreBrandStyle style = const StoreBrandStyle();
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SizedBox(
                width: 390,
                height: 700,
                child: StoreBrandEditorOverlay(
                  style: style,
                  shopName: '毛小孩旅店',
                  subtitle: '溫暖的家',
                  logoUrl: '',
                  theme: theme,
                  bottomObstacle: 80,
                  onChanged: (StoreBrandStyle next) {
                    setState(() => style = next);
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
    await tester.pump();

    final Finder name = find.text('毛小孩旅店');
    final Offset start = tester.getTopLeft(name);
    final TestGesture gesture = await tester.startGesture(start + const Offset(12, 8));
    await gesture.moveBy(const Offset(48, 36));
    await tester.pump();
    final Offset moved = tester.getTopLeft(name);
    expect(moved.dx, closeTo(start.dx + 48, 1.5));
    expect(moved.dy, closeTo(start.dy + 36, 1.5));

    await gesture.up();
    await tester.pump();
    final Offset released = tester.getTopLeft(name);
    expect(released.dx, closeTo(moved.dx, 0.5));
    expect(released.dy, closeTo(moved.dy, 0.5));
    expect(style.x, inInclusiveRange(0, 1));
    expect(style.y, inInclusiveRange(0, 1));
  });

  testWidgets('width handle wraps the name without a second home title', (
    WidgetTester tester,
  ) async {
    StoreBrandStyle style = const StoreBrandStyle(widthRatio: 1);
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SizedBox(
                width: 390,
                height: 700,
                child: Stack(
                  children: <Widget>[
                    StoreBrandEditorOverlay(
                      style: style,
                      shopName: '很長的店家名稱需要換行才放得下',
                      subtitle: '副標也要跟著同一種對齊換行',
                      logoUrl: '',
                      theme: theme,
                      bottomObstacle: 62,
                      onChanged: (StoreBrandStyle next) {
                        setState(() => style = next);
                      },
                    ),
                    const Align(
                      alignment: Alignment.bottomCenter,
                      child: SizedBox(
                        width: 220,
                        child: StoreBrandBlock(
                          contextKind: StoreBrandDisplayContext.drawer,
                          style: StoreBrandStyle(textAlign: 'left'),
                          shopName: '抽屜店名',
                          subtitle: '',
                          logoUrl: '',
                          theme: theme,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
    await tester.pump();
    expect(
      find.byWidgetPredicate(
        (Widget widget) =>
            widget is StoreBrandBlock &&
            widget.contextKind == StoreBrandDisplayContext.home,
      ),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (Widget widget) =>
            widget is StoreBrandBlock &&
            widget.contextKind == StoreBrandDisplayContext.drawer,
      ),
      findsOneWidget,
    );

    await tester.tap(find.text('很長的店家名稱需要換行才放得下'));
    await tester.pump();
    final Finder handle = find.byKey(const ValueKey<String>('store-brand-handle-left'));
    expect(handle, findsOneWidget);
    final Offset handleStart = tester.getCenter(handle);
    final TestGesture gesture = await tester.startGesture(handleStart);
    await gesture.moveBy(const Offset(120, 0));
    await tester.pump();
    await gesture.up();
    await tester.pump();
    expect(style.widthRatio, lessThan(1));
    expect(style.widthRatio, greaterThanOrEqualTo(0.3));
    expect(tester.takeException(), isNull);
  });

  testWidgets('brand settings card fits a narrow phone width', (WidgetTester tester) async {
    final TextEditingController subtitle = TextEditingController(text: '副標');
    addTearDown(subtitle.dispose);
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 390,
            child: ListView(
              children: <Widget>[
                StoreBrandSettingsCard(
                  style: const StoreBrandStyle(),
                  theme: theme,
                  subtitleController: subtitle,
                  logoSection: const Text('Logo'),
                  onChanged: (_) {},
                ),
              ],
            ),
          ),
        ),
      ),
    );
    await tester.pump();
    expect(find.text('重設位置與寬度'), findsOneWidget);
    expect(find.text('顯示左側圖示'), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
