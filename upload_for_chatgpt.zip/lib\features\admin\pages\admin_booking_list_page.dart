// 檔案名稱：lib/features/admin/pages/admin_booking_list_page.dart
// 功能說明：店家訂單列表頁（住宿／安親分頁）

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:petnest_saas/core/models/booking_kind.dart';
import 'package:petnest_saas/core/navigation/admin_booking_route.dart';
import 'package:petnest_saas/features/admin/widgets/booking_search_bar.dart';
import 'package:petnest_saas/features/admin/widgets/booking_status_filter.dart';
import 'package:petnest_saas/features/admin/widgets/booking_sort_bar.dart';
import 'package:petnest_saas/features/admin/widgets/booking_order_card.dart';
import 'package:petnest_saas/features/admin/widgets/booking_advanced_filter_button.dart';
import 'package:petnest_saas/features/admin/pages/admin_create_booking_page.dart';
import 'package:petnest_saas/features/admin/pages/admin_create_daycare_booking_page.dart';
import 'package:petnest_saas/features/admin/widgets/admin_daycare_order_list.dart';
import 'package:petnest_saas/core/services/daycare_settings_service.dart';
import 'package:petnest_saas/core/services/daycare_status_labels.dart';
import 'package:petnest_saas/core/services/shop_permission_service.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/core/widgets/shop_task_center_button.dart';
import 'package:petnest_saas/features/shop/widgets/booking/booking_entry_service_card.dart';

class AdminBookingListPage extends StatefulWidget {
  const AdminBookingListPage({
    super.key,
    required this.shopId,
    this.filterType,
    this.initialKind,
  });

  final String shopId;
  final String? filterType;
  final String? initialKind;

  @override
  State<AdminBookingListPage> createState() => _AdminBookingListPageState();
}

class _AdminBookingListPageState extends State<AdminBookingListPage>
    with SingleTickerProviderStateMixin {
  StreamSubscription<Map<String, dynamic>?>? _shopSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _openDaycareSub;
  TabController? _tabController;
  Map<String, dynamic> _shop = <String, dynamic>{};
  bool _shopLoaded = false;
  bool _daycareOn = false;
  bool _hasOpenDaycare = false;

  @override
  void initState() {
    super.initState();
    _shopSub = ShopService.instance.streamShop(widget.shopId).listen((
      Map<String, dynamic>? shop,
    ) {
      if (!mounted) {
        return;
      }
      final Map<String, dynamic> next = shop ?? <String, dynamic>{};
      final bool daycareOn = DaycareSettingsService.instance.isEnabledForShop(
        shop: next,
      );
      setState(() {
        _shop = next;
        _shopLoaded = true;
        if (daycareOn != _daycareOn) {
          _daycareOn = daycareOn;
          _syncTabs();
        } else if ((_daycareOn || _hasOpenDaycare) && _tabController == null) {
          _syncTabs();
        }
      });
    });
    _openDaycareSub = FirebaseFirestore.instance
        .collection('bookings')
        .where('shopId', isEqualTo: widget.shopId)
        .where('bookingKind', isEqualTo: BookingKind.daycare)
        .orderBy('createdAt', descending: true)
        .limit(40)
        .snapshots()
        .listen((QuerySnapshot<Map<String, dynamic>> snap) {
          if (!mounted) {
            return;
          }
          final bool hasOpen = snap.docs.any((
            QueryDocumentSnapshot<Map<String, dynamic>> doc,
          ) {
            return !DaycareStatusLabels.isHistory(doc.data());
          });
          if (hasOpen == _hasOpenDaycare) {
            return;
          }
          setState(() {
            _hasOpenDaycare = hasOpen;
            _syncTabs();
          });
        });
  }

  void _syncTabs() {
    _tabController?.dispose();
    _tabController = null;
    if (_daycareOn || _hasOpenDaycare) {
      final int initial = widget.initialKind == BookingKind.daycare ? 1 : 0;
      _tabController = TabController(
        length: 2,
        vsync: this,
        initialIndex: initial,
      );
    }
  }

  @override
  void dispose() {
    _shopSub?.cancel();
    _openDaycareSub?.cancel();
    _tabController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_shopLoaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final bool showDaycareTab =
        (_daycareOn || _hasOpenDaycare) && _tabController != null;
    return Scaffold(
      appBar: AppBar(
        title: const Text('訂單管理'),
        bottom: showDaycareTab
            ? TabBar(
                controller: _tabController,
                tabs: <Widget>[
                  const Tab(text: '住宿訂單'),
                  Tab(text: _daycareOn ? '安親訂單' : '待處理安親'),
                ],
              )
            : null,
        actions: <Widget>[
          ShopTaskCenterButton(shopId: widget.shopId),
          _CreateOrderButton(shopId: widget.shopId, shop: _shop),
        ],
      ),
      body: showDaycareTab
          ? TabBarView(
              controller: _tabController,
              children: <Widget>[
                _AdminStayOrderList(
                  shopId: widget.shopId,
                  filterType: widget.filterType,
                ),
                AdminDaycareOrderList(shopId: widget.shopId),
              ],
            )
          : _AdminStayOrderList(
              shopId: widget.shopId,
              filterType: widget.filterType,
            ),
    );
  }
}

class _CreateOrderButton extends StatelessWidget {
  const _CreateOrderButton({required this.shopId, required this.shop});

  final String shopId;
  final Map<String, dynamic> shop;

  @override
  Widget build(BuildContext context) {
    final bool canCreateOrder = ShopPermissionService.canCreateOrder(shop);
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: TextButton.icon(
        onPressed: canCreateOrder
            ? () async {
                final bool daycareOn = DaycareSettingsService.instance
                    .isEnabledForShop(shop: shop);
                if (!context.mounted) {
                  return;
                }
                if (!daycareOn) {
                  Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => AdminCreateBookingPage(shopId: shopId),
                    ),
                  );
                  return;
                }
                final String? choice = await showDialog<String>(
                  context: context,
                  builder: (BuildContext context) => Dialog(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          const Text(
                            '新增訂單',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 12),
                          BookingEntryServiceCard(
                            title: '新增住宿訂單',
                            subtitle: '代客建立入住與退房訂單',
                            imageUrl: '',
                            fallbackIcon: Icons.nights_stay,
                            onTap: () => Navigator.pop(context, 'stay'),
                          ),
                          const SizedBox(height: 12),
                          BookingEntryServiceCard(
                            title: '新增安親訂單',
                            subtitle: '代客建立單日送達與接回訂單',
                            imageUrl: '',
                            fallbackIcon: Icons.wb_sunny_outlined,
                            onTap: () => Navigator.pop(context, 'daycare'),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
                if (!context.mounted || choice == null) {
                  return;
                }
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => choice == 'daycare'
                        ? AdminCreateDaycareBookingPage(shopId: shopId)
                        : AdminCreateBookingPage(shopId: shopId),
                  ),
                );
              }
            : () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(ShopPermissionService.restrictedMessage()),
                  ),
                );
              },
        icon: Icon(canCreateOrder ? Icons.add : Icons.lock_outline),
        label: const Text('手動新增訂單'),
      ),
    );
  }
}

class _AdminStayOrderList extends StatefulWidget {
  const _AdminStayOrderList({required this.shopId, this.filterType});

  final String shopId;
  final String? filterType;

  @override
  State<_AdminStayOrderList> createState() => _AdminStayOrderListState();
}

class _AdminStayOrderListState extends State<_AdminStayOrderList>
    with AutomaticKeepAliveClientMixin {
  late String _filterType;
  final TextEditingController _searchController = TextEditingController();
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream;
  String _keyword = '';
  String _sortType = 'startDesc';
  final int _pageSize = 5;
  int _currentPage = 0;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _filterType = widget.filterType ?? 'all';
    _stream = FirebaseFirestore.instance
        .collection('bookings')
        .where('shopId', isEqualTo: widget.shopId)
        .snapshots();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        BookingSearchBar(
          controller: _searchController,
          onChanged: (value) {
            setState(() {
              _keyword = value.trim();
              _currentPage = 0;
            });
          },
        ),
        BookingAdvancedFilterButton(
          onTap: () {
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(const SnackBar(content: Text('此功能將於後續版本提供')));
          },
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _stream,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('載入失敗：${snapshot.error}'));
              }
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              final docs = snapshot.data!.docs
                  .where(
                    (QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
                        BookingKind.isAccommodation(doc.data()),
                  )
                  .toList();

              final statusCounts = _buildStatusCounts(docs);

              final now = DateTime.now();
              final todayStart = DateTime(now.year, now.month, now.day);
              final todayEnd = todayStart.add(const Duration(days: 1));

              final filteredDocs =
                  docs.where((doc) {
                    final data = doc.data();

                    final startRaw = data['startDate'];
                    final endRaw = data['endDate'];
                    final start = startRaw is Timestamp
                        ? startRaw.toDate()
                        : DateTime.fromMillisecondsSinceEpoch(0);
                    final end = endRaw is Timestamp
                        ? endRaw.toDate()
                        : DateTime.fromMillisecondsSinceEpoch(0);
                    final status = data['status'] ?? '';

                    final bookingId = doc.id.toLowerCase();

                    final customerName = (data['customerName'] ?? '')
                        .toString()
                        .toLowerCase();

                    final customerPhone = (data['customerPhone'] ?? '')
                        .toString()
                        .toLowerCase();

                    final roomName = (data['roomName'] ?? '')
                        .toString()
                        .toLowerCase();

                    final pets = (data['pets'] as List?) ?? [];

                    final petNames = pets
                        .map((e) {
                          if (e is Map<String, dynamic>) {
                            return (e['name'] ?? '').toString().toLowerCase();
                          }
                          return '';
                        })
                        .join(',');

                    final keyword = _keyword.toLowerCase();

                    final matchKeyword =
                        keyword.isEmpty ||
                        bookingId.contains(keyword) ||
                        customerName.contains(keyword) ||
                        customerPhone.contains(keyword) ||
                        roomName.contains(keyword) ||
                        petNames.contains(keyword);

                    if (!matchKeyword) {
                      return false;
                    }

                    switch (_filterType) {
                      case 'pending':
                        return status == 'pending' ||
                            status == 'unpaid' ||
                            status == 'pending_confirmation';

                      case 'depositReview':
                        final depositStatus = (data['depositStatus'] ?? '')
                            .toString();
                        return depositStatus == 'pending_review' &&
                            status != 'completed' &&
                            status != 'cancelled';

                      case 'confirmed':
                        return status == 'confirmed';

                      case 'awaitingRoom':
                        if (status == 'completed' || status == 'cancelled') {
                          return false;
                        }
                        final String assign = (data['assignStatus'] ?? '')
                            .toString();
                        if (assign == 'assigned') {
                          return false;
                        }
                        if (assign == 'unassigned') {
                          return status == 'confirmed';
                        }
                        return status == 'confirmed' &&
                            (data['roomId'] ?? '').toString().trim().isEmpty;

                      case 'todayCheckIn':
                        return status != 'cancelled' &&
                            status != 'completed' &&
                            !start.isBefore(todayStart) &&
                            start.isBefore(todayEnd);

                      case 'todayCheckOut':
                        return status != 'cancelled' &&
                            status != 'completed' &&
                            !end.isBefore(todayStart) &&
                            end.isBefore(todayEnd);

                      case 'futureCheckIn':
                        return status != 'cancelled' &&
                            status != 'completed' &&
                            !start.isBefore(todayEnd);

                      case 'history':
                        return status == 'completed' || status == 'cancelled';

                      case 'all':
                      default:
                        return true;
                    }
                  }).toList()..sort((a, b) {
                    final aData = a.data();
                    final bData = b.data();

                    DateTime getDate(Map<String, dynamic> data, String key) {
                      final value = data[key];
                      if (value is Timestamp) return value.toDate();
                      return DateTime.fromMillisecondsSinceEpoch(0);
                    }

                    switch (_sortType) {
                      case 'startAsc':
                        return getDate(
                          aData,
                          'startDate',
                        ).compareTo(getDate(bData, 'startDate'));

                      case 'createdDesc':
                        return getDate(
                          bData,
                          'createdAt',
                        ).compareTo(getDate(aData, 'createdAt'));

                      case 'createdAsc':
                        return getDate(
                          aData,
                          'createdAt',
                        ).compareTo(getDate(bData, 'createdAt'));

                      case 'startDesc':
                      default:
                        return getDate(
                          bData,
                          'startDate',
                        ).compareTo(getDate(aData, 'startDate'));
                    }
                  });

              final totalPages = (filteredDocs.length / _pageSize).ceil();

              if (_currentPage >= totalPages && totalPages > 0) {
                _currentPage = totalPages - 1;
              }

              final visibleDocs = filteredDocs
                  .skip(_currentPage * _pageSize)
                  .take(_pageSize)
                  .toList();

              Widget filterBar() {
                return BookingStatusFilter(
                  selectedType: _filterType,
                  counts: statusCounts,
                  items: BookingStatusFilter.stayItems,
                  onChanged: (type) {
                    setState(() {
                      _filterType = type;
                      _currentPage = 0;
                    });
                  },
                );
              }

              Widget sortBar() {
                return BookingSortBar(
                  totalCount: filteredDocs.length,
                  sortType: _sortType,
                  isGridMode: false,
                  onSortChanged: (value) {
                    setState(() {
                      _sortType = value;
                    });
                  },
                  onToggleViewMode: () {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(const SnackBar(content: Text('格子檢視之後再開放')));
                  },
                );
              }

              if (filteredDocs.isEmpty) {
                return ListView(
                  children: [
                    filterBar(),
                    sortBar(),
                    const SizedBox(height: 80),
                    Center(
                      child: Text(
                        _filterType == 'history' ? '尚無歷史訂單' : '尚無符合條件的訂單',
                        style: const TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                );
              }

              return ListView(
                children: [
                  filterBar(),
                  sortBar(),
                  ...visibleDocs.map((doc) {
                    final data = doc.data();
                    return BookingOrderCard(
                      bookingId: doc.id,
                      data: data,
                      onTap: () {
                        AdminBookingRoute.open(
                          context,
                          bookingId: doc.id,
                          data: data,
                          canEdit: true,
                        );
                      },
                    );
                  }),
                  const SizedBox(height: 8),
                  if (totalPages > 1)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      child: Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _currentPage <= 0
                                  ? null
                                  : () {
                                      setState(() {
                                        _currentPage--;
                                      });
                                    },
                              icon: const Icon(Icons.chevron_left),
                              label: const Text('上一頁'),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Text(
                              '${_currentPage + 1} / $totalPages',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _currentPage >= totalPages - 1
                                  ? null
                                  : () {
                                      setState(() {
                                        _currentPage++;
                                      });
                                    },
                              icon: const Icon(Icons.chevron_right),
                              label: const Text('下一頁'),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Map<String, int> _buildStatusCounts(
    List<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
  ) {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    final todayEnd = todayStart.add(const Duration(days: 1));

    final counts = <String, int>{
      'all': docs.length,
      'pending': 0,
      'depositReview': 0,
      'confirmed': 0,
      'awaitingRoom': 0,
      'todayCheckIn': 0,
      'todayCheckOut': 0,
      'futureCheckIn': 0,
      'history': 0,
    };

    for (final doc in docs) {
      final data = doc.data();
      final status = (data['status'] ?? 'pending').toString();
      final depositStatus = (data['depositStatus'] ?? '').toString();
      final String assign = (data['assignStatus'] ?? '').toString();

      if (status == 'pending' ||
          status == 'unpaid' ||
          status == 'pending_confirmation') {
        counts['pending'] = (counts['pending'] ?? 0) + 1;
      }

      if (depositStatus == 'pending_review' &&
          status != 'completed' &&
          status != 'cancelled') {
        counts['depositReview'] = (counts['depositReview'] ?? 0) + 1;
      }

      if (status == 'confirmed') {
        counts['confirmed'] = (counts['confirmed'] ?? 0) + 1;
      }

      final bool history = status == 'completed' || status == 'cancelled';
      if (history) {
        counts['history'] = (counts['history'] ?? 0) + 1;
      } else if (status == 'confirmed') {
        if (assign == 'unassigned' ||
            (assign != 'assigned' &&
                (data['roomId'] ?? '').toString().trim().isEmpty)) {
          counts['awaitingRoom'] = (counts['awaitingRoom'] ?? 0) + 1;
        }
      }

      final startRaw = data['startDate'];
      final endRaw = data['endDate'];

      if (startRaw is Timestamp) {
        final start = startRaw.toDate();
        if (!history &&
            !start.isBefore(todayStart) &&
            start.isBefore(todayEnd)) {
          counts['todayCheckIn'] = (counts['todayCheckIn'] ?? 0) + 1;
        }
        if (!history && !start.isBefore(todayEnd)) {
          counts['futureCheckIn'] = (counts['futureCheckIn'] ?? 0) + 1;
        }
      }

      if (endRaw is Timestamp) {
        final end = endRaw.toDate();
        if (!history && !end.isBefore(todayStart) && end.isBefore(todayEnd)) {
          counts['todayCheckOut'] = (counts['todayCheckOut'] ?? 0) + 1;
        }
      }
    }

    return counts;
  }
}
