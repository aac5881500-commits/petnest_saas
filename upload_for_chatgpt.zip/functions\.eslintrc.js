// 檔案名稱：functions/.eslintrc.js
// 功能說明：Cloud Functions 的 ESLint 規則設定

module.exports = {
  env: {
    es6: true,
    node: true,
  },
  parserOptions: {
    "ecmaVersion": 2018,
  },
  extends: [
    "eslint:recommended",
    "google",
  ],
  rules: {
    "no-restricted-globals": ["error", "name", "length"],
    "prefer-arrow-callback": "error",
    "quotes": ["error", "double", {"allowTemplateLiterals": true}],
  },
  overrides: [
    {
      files: ["**/*.spec.*", "**/*.test.js"],
      env: {
        mocha: true,
        es2020: true,
      },
      parserOptions: {
        "ecmaVersion": 2020,
      },
      rules: {
        "max-len": "off",
      },
    },
  ],
  globals: {},
};
