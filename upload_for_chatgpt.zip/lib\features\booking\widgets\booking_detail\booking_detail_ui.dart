// lib/features/booking/widgets/booking_detail/booking_detail_ui.dart
// 客戶端訂單詳細頁共用暖色系樣式，對齊 PetNest 現代首頁。

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';

class BookingDetailUi {
  BookingDetailUi._();

  static const HomeThemeModel theme = HomeThemeModel.modernDefault;

  static Color get background => theme.backgroundColor;
  static Color get card => theme.cardColor;
  static Color get border => const Color(0xFFEDE4DC);
  static Color get primary => theme.primaryColor;
  static Color get text => theme.textColor;
  static Color get muted => const Color(0xFF8A7468);
  static Color get success => const Color(0xFF5A9A6A);
  static Color get successSoft => const Color(0xFFEAF6EC);
  static Color get warning => const Color(0xFFE08A3A);
  static Color get warningSoft => const Color(0xFFFFF3E6);
  static Color get danger => const Color(0xFFC45C5C);
  static Color get dangerSoft => const Color(0xFFFBECEC);
  static Color get iconSoft => const Color(0xFFFFF1E4);

  static const double radius = 16;
  static const double pagePadding = 16;
  static const double cardGap = 12;
  static const double cardPadding = 16;
  static const double maxContentWidth = 720;

  static const double bodySize = 14.5;
  static const double captionSize = 12.5;
  static const double sectionTitleSize = 16.5;
  static const double statusSize = 23;
  static const double moneySize = 26;

  static BoxDecoration cardDecoration({Color? color, Color? borderColor}) {
    return BoxDecoration(
      color: color ?? card,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: borderColor ?? border),
      boxShadow: const <BoxShadow>[
        BoxShadow(
          color: Color(0x0A3A2A20),
          blurRadius: 10,
          offset: Offset(0, 3),
        ),
      ],
    );
  }

  static Widget constrain(Widget child) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: maxContentWidth),
        child: child,
      ),
    );
  }
}

class BookingDetailCard extends StatelessWidget {
  const BookingDetailCard({
    super.key,
    required this.child,
    this.padding,
    this.onTap,
    this.margin,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    final Widget content = Container(
      width: double.infinity,
      margin: margin ?? const EdgeInsets.only(bottom: BookingDetailUi.cardGap),
      padding: padding ?? const EdgeInsets.all(BookingDetailUi.cardPadding),
      decoration: BookingDetailUi.cardDecoration(),
      child: child,
    );

    if (onTap == null) {
      return content;
    }

    return Padding(
      padding: margin ?? const EdgeInsets.only(bottom: BookingDetailUi.cardGap),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(BookingDetailUi.radius),
          child: Ink(
            width: double.infinity,
            padding:
                padding ?? const EdgeInsets.all(BookingDetailUi.cardPadding),
            decoration: BookingDetailUi.cardDecoration(),
            child: child,
          ),
        ),
      ),
    );
  }
}

class BookingDetailSectionTitle extends StatelessWidget {
  const BookingDetailSectionTitle(this.text, {super.key, this.trailing});

  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: BookingDetailUi.sectionTitleSize,
              fontWeight: FontWeight.w700,
              color: BookingDetailUi.text,
            ),
          ),
        ),
        ?trailing,
      ],
    );
  }
}

class BookingDetailEntryRow extends StatelessWidget {
  const BookingDetailEntryRow({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.badge,
    this.done = false,
    this.showChevron = true,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String? badge;
  final bool done;
  final bool showChevron;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return BookingDetailCard(
      onTap: onTap,
      child: Row(
        children: <Widget>[
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: done
                  ? BookingDetailUi.successSoft
                  : BookingDetailUi.iconSoft,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: done ? BookingDetailUi.success : BookingDetailUi.primary,
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: BookingDetailUi.bodySize,
                    fontWeight: FontWeight.w600,
                    color: BookingDetailUi.text,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: BookingDetailUi.captionSize,
                    color: BookingDetailUi.muted,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          if (done)
            Icon(Icons.check_circle, color: BookingDetailUi.success, size: 20)
          else if (badge != null && badge!.isNotEmpty)
            Container(
              margin: const EdgeInsets.only(left: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: BookingDetailUi.warningSoft,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                badge!,
                style: TextStyle(
                  fontSize: 11,
                  color: BookingDetailUi.warning,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          if (showChevron && onTap != null) ...<Widget>[
            const SizedBox(width: 4),
            Icon(Icons.chevron_right, color: BookingDetailUi.muted),
          ],
        ],
      ),
    );
  }
}

class BookingDetailSoftNetworkImage extends StatelessWidget {
  const BookingDetailSoftNetworkImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius,
    this.fallbackIcon = Icons.pets_outlined,
  });

  final String url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius? borderRadius;
  final IconData fallbackIcon;

  @override
  Widget build(BuildContext context) {
    final Widget fallback = ColoredBox(
      color: BookingDetailUi.iconSoft,
      child: Icon(fallbackIcon, color: BookingDetailUi.primary),
    );

    final Widget image = url.trim().isEmpty
        ? fallback
        : Image.network(
            url,
            fit: fit,
            width: width,
            height: height,
            errorBuilder:
                (BuildContext context, Object error, StackTrace? stackTrace) {
                  return fallback;
                },
          );

    return ClipRRect(
      borderRadius: borderRadius ?? BorderRadius.circular(12),
      child: SizedBox(width: width, height: height, child: image),
    );
  }
}
