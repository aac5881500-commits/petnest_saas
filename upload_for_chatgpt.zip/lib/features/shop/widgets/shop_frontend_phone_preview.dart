// 檔案名稱：lib/features/shop/widgets/shop_frontend_phone_preview.dart
// 功能說明：後台左側真實 logical 手機 viewport，內容在框內獨立捲動。

import 'dart:math' as math;

import 'package:flutter/material.dart';

class ShopFrontendPhoneSize {
  const ShopFrontendPhoneSize({
    required this.id,
    required this.label,
    required this.size,
  });

  final String id;
  final String label;
  final Size size;

  static const ShopFrontendPhoneSize small = ShopFrontendPhoneSize(
    id: 'small',
    label: '小手機',
    size: Size(360, 780),
  );
  static const ShopFrontendPhoneSize standard = ShopFrontendPhoneSize(
    id: 'standard',
    label: '標準手機',
    size: Size(393, 852),
  );
  static const ShopFrontendPhoneSize large = ShopFrontendPhoneSize(
    id: 'large',
    label: '大手機',
    size: Size(430, 932),
  );

  static const List<ShopFrontendPhoneSize> all = <ShopFrontendPhoneSize>[
    small,
    standard,
    large,
  ];

  static ShopFrontendPhoneSize byId(String? id) {
    return all.firstWhere(
      (ShopFrontendPhoneSize item) => item.id == id,
      orElse: () => small,
    );
  }
}

class ShopFrontendScrollStats extends ChangeNotifier {
  double viewportHeight = 1;
  double contentHeight = 1;
  double pixels = 0;

  double get screenCount {
    if (viewportHeight <= 0) {
      return 1;
    }
    return contentHeight / viewportHeight;
  }

  double get progress {
    final double max = math.max(0, contentHeight - viewportHeight);
    if (max <= 0) {
      return 1;
    }
    return (pixels / max).clamp(0, 1);
  }

  bool get fitsInView => contentHeight <= viewportHeight + 1;

  bool get atBottom => !fitsInView && progress >= 0.98;

  String get label {
    if (fitsInView) {
      return '內容已完整顯示';
    }
    if (atBottom) {
      return '已到頁面底部';
    }
    final String screens = screenCount.toStringAsFixed(1);
    final String percent = (progress * 100).round().toString();
    return '約 $screens 個螢幕高度 · 已瀏覽 $percent%';
  }

  void update({
    required double viewport,
    required double maxExtent,
    required double offset,
  }) {
    final double nextContent = viewport + math.max(0, maxExtent);
    if ((viewportHeight - viewport).abs() < 0.5 &&
        (contentHeight - nextContent).abs() < 0.5 &&
        (pixels - offset).abs() < 0.5) {
      return;
    }
    viewportHeight = viewport;
    contentHeight = nextContent;
    pixels = offset;
    notifyListeners();
  }
}

class ShopFrontendPhoneFrame extends StatelessWidget {
  const ShopFrontendPhoneFrame({
    super.key,
    required this.logicalSize,
    required this.child,
    this.onScrollMetrics,
  });

  final Size logicalSize;
  final Widget child;
  final ValueChanged<ScrollMetrics>? onScrollMetrics;

  static const EdgeInsets safePadding = EdgeInsets.only(top: 44, bottom: 24);

  @override
  Widget build(BuildContext context) {
    final Size logical = logicalSize;
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        const double chrome = 12;
        final double frameW = logical.width + chrome;
        final double frameH = logical.height + chrome;
        final double maxW = constraints.maxWidth;
        final double maxH = constraints.maxHeight;
        final double scale = math.min(
          1,
          math.min(maxW / frameW, maxH / frameH),
        );
        return Align(
          alignment: Alignment.topCenter,
          child: SizedBox(
            width: frameW * scale,
            height: frameH * scale,
            child: FittedBox(
              fit: BoxFit.fill,
              child: SizedBox(
                width: frameW,
                height: frameH,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0xFFD7DEE8)),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: 16,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: MediaQuery(
                        data: MediaQuery.of(context).copyWith(
                          size: logical,
                          padding: safePadding,
                          viewPadding: safePadding,
                          viewInsets: EdgeInsets.zero,
                          textScaler: const TextScaler.linear(1.0),
                        ),
                        child: SizedBox(
                          width: logical.width,
                          height: logical.height,
                          child: Stack(
                            children: <Widget>[
                              NotificationListener<ScrollNotification>(
                                onNotification:
                                    (ScrollNotification notification) {
                                      if (notification.metrics.axis !=
                                          Axis.vertical) {
                                        return false;
                                      }
                                      onScrollMetrics?.call(
                                        notification.metrics,
                                      );
                                      return true;
                                    },
                                child: child,
                              ),
                              const Positioned(
                                top: 0,
                                left: 0,
                                right: 0,
                                child: IgnorePointer(
                                  child: _PreviewStatusBar(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class ShopFrontendScrollMeter extends StatelessWidget {
  const ShopFrontendScrollMeter({super.key, required this.stats});

  final ShopFrontendScrollStats stats;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: stats,
      builder: (BuildContext context, Widget? child) {
        return Row(
          children: <Widget>[
            Expanded(
              child: Text(
                stats.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, color: Color(0xFF6B7280)),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 4,
              height: 36,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: Stack(
                  children: <Widget>[
                    const ColoredBox(color: Color(0xFFE5E7EB)),
                    Align(
                      alignment: Alignment.topCenter,
                      child: FractionallySizedBox(
                        heightFactor: stats.fitsInView
                            ? 1
                            : math.max(0.12, 1 / stats.screenCount),
                        child: FractionalTranslation(
                          translation: Offset(
                            0,
                            stats.fitsInView ? 0 : stats.progress,
                          ),
                          child: const ColoredBox(color: Color(0xFF94A3B8)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _PreviewStatusBar extends StatelessWidget {
  const _PreviewStatusBar();

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.paddingOf(context).top;
    if (height <= 0) {
      return const SizedBox.shrink();
    }
    return SizedBox(
      height: height,
      child: const Padding(
        padding: EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: <Widget>[
            Text(
              '9:41',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
            Spacer(),
            Icon(Icons.signal_cellular_alt, size: 13),
            SizedBox(width: 4),
            Icon(Icons.wifi, size: 13),
            SizedBox(width: 4),
            Icon(Icons.battery_full, size: 13),
          ],
        ),
      ),
    );
  }
}
