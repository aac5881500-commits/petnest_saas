// 檔案名稱：lib/features/shop/widgets/shop_frontend_test_panel.dart
// 功能說明：店家後台固定 360×780 前台預覽，以獨立 Navigator 載入既有 ShopPublicPage。

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:petnest_saas/features/shop/pages/shop_public_page.dart';
import 'package:petnest_saas/features/shop/widgets/shop_dashboard_embedded_scope.dart';
import 'package:petnest_saas/features/shop/widgets/shop_frontend_phone_preview.dart';
import 'package:url_launcher/url_launcher.dart';

class ShopFrontendTestPanel extends StatefulWidget {
  const ShopFrontendTestPanel({
    super.key,
    required this.shopId,
    required this.shopCode,
    required this.onClose,
    this.homeResetToken = 0,
    this.onOpenFullPage,
    this.previewBodyOverride,
  });

  static const Size dashboardFrontendPreviewSize = Size(360, 780);
  static const double splitMinWindowWidth = 1280;
  static const double dashboardColumnWidth = 388;

  final String shopId;
  final String shopCode;
  final VoidCallback onClose;
  final int homeResetToken;
  final VoidCallback? onOpenFullPage;

  @visibleForTesting
  final Widget? previewBodyOverride;

  @override
  State<ShopFrontendTestPanel> createState() => _ShopFrontendTestPanelState();
}

class _ShopFrontendTestPanelState extends State<ShopFrontendTestPanel> {
  GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  int _refreshGeneration = 0;
  final ShopFrontendScrollStats _stats = ShopFrontendScrollStats();

  @override
  void dispose() {
    _stats.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant ShopFrontendTestPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.homeResetToken != widget.homeResetToken) {
      _navigatorKey.currentState?.popUntil((Route<dynamic> route) {
        return route.isFirst;
      });
    }
    if (oldWidget.shopId != widget.shopId) {
      _resetNavigator();
    }
  }

  void _resetNavigator() {
    setState(() {
      _refreshGeneration++;
      _navigatorKey = GlobalKey<NavigatorState>();
    });
  }

  void _goBack() {
    _navigatorKey.currentState?.maybePop();
  }

  void _goHome() {
    _navigatorKey.currentState?.popUntil((Route<dynamic> route) {
      return route.isFirst;
    });
  }

  Uri? _publicFrontendUri() {
    final String code = widget.shopCode.trim();
    if (code.isEmpty) {
      return null;
    }
    if (kIsWeb) {
      return Uri.parse('${Uri.base.origin}/s/$code');
    }
    return Uri.parse('https://petnest.tw/s/$code');
  }

  Future<void> _openPublicFrontend() async {
    final Uri? uri = _publicFrontendUri();
    if (uri == null) {
      return;
    }
    await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
      webOnlyWindowName: '_blank',
    );
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme colors = Theme.of(context).colorScheme;
    final bool hasShopCode = widget.shopCode.trim().isNotEmpty;
    const Size previewSize = ShopFrontendTestPanel.dashboardFrontendPreviewSize;

    return ColoredBox(
      color: const Color(0xFFF7F8FC),
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 48,
            child: DecoratedBox(
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(bottom: BorderSide(color: Color(0xFFE6EAF0))),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        '前台',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                          color: colors.onSurface,
                        ),
                      ),
                    ),
                    Flexible(child: ShopFrontendScrollMeter(stats: _stats)),
                    _ToolbarIcon(
                      tooltip: '返回上一頁',
                      icon: Icons.arrow_back,
                      onPressed: _goBack,
                    ),
                    _ToolbarIcon(
                      tooltip: '回到前台首頁',
                      icon: Icons.home_outlined,
                      onPressed: _goHome,
                    ),
                    _ToolbarIcon(
                      tooltip: '重新整理',
                      icon: Icons.refresh,
                      onPressed: _resetNavigator,
                    ),
                    _ToolbarIcon(
                      tooltip: '全頁查看',
                      icon: Icons.open_in_full,
                      onPressed: widget.onOpenFullPage,
                    ),
                    _ToolbarIcon(
                      tooltip: hasShopCode ? '另開完整前台' : '請先設定店家代碼',
                      icon: Icons.open_in_new,
                      onPressed: hasShopCode ? _openPublicFrontend : null,
                    ),
                    _ToolbarIcon(
                      tooltip: '關閉',
                      icon: Icons.close,
                      onPressed: widget.onClose,
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 6, 10, 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '後台預覽模式：可瀏覽前台，不會建立訂單或修改客戶資料。',
                style: TextStyle(fontSize: 11.5, color: Color(0xFF6B7280)),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
              child: ShopFrontendPhoneFrame(
                logicalSize: previewSize,
                onScrollMetrics: (ScrollMetrics metrics) {
                  _stats.update(
                    viewport: metrics.viewportDimension,
                    maxExtent: metrics.maxScrollExtent,
                    offset: metrics.pixels,
                  );
                },
                child: ShopDashboardEmbeddedScope(
                  onExitEmbedded: widget.onClose,
                  previewOnly: true,
                  child: HeroControllerScope.none(
                    child: KeyedSubtree(
                      key: ValueKey<int>(_refreshGeneration),
                      child: Navigator(
                        key: _navigatorKey,
                        onGenerateInitialRoutes:
                            (NavigatorState navigator, String initialRoute) {
                              return <Route<dynamic>>[
                                MaterialPageRoute<void>(
                                  settings: const RouteSettings(name: '/'),
                                  builder: (_) =>
                                      widget.previewBodyOverride ??
                                      ShopPublicPage(
                                        shopId: widget.shopId,
                                        embeddedInDashboard: true,
                                        onExitEmbedded: widget.onClose,
                                      ),
                                ),
                              ];
                            },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ToolbarIcon extends StatelessWidget {
  const _ToolbarIcon({
    required this.tooltip,
    required this.icon,
    required this.onPressed,
  });

  final String tooltip;
  final IconData icon;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: tooltip,
      onPressed: onPressed,
      icon: Icon(icon, size: 20),
      visualDensity: VisualDensity.compact,
      constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
      padding: EdgeInsets.zero,
    );
  }
}

class ShopDashboardFrontendEmbedHost extends StatelessWidget {
  const ShopDashboardFrontendEmbedHost({
    super.key,
    required this.pageWidth,
    required this.openPref,
    required this.preview,
    required this.main,
    required this.onAutoClose,
  });

  static const Key embeddedPreviewKey = Key(
    'shop-dashboard-embedded-frontend-preview',
  );

  final double pageWidth;
  final bool openPref;
  final Widget preview;
  final Widget main;
  final VoidCallback onAutoClose;

  static bool canEmbed(double pageWidth) {
    return pageWidth >= ShopFrontendTestPanel.splitMinWindowWidth;
  }

  @override
  Widget build(BuildContext context) {
    final bool splitMode = canEmbed(pageWidth);
    return Stack(
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            if (splitMode && openPref)
              SizedBox(
                key: embeddedPreviewKey,
                width: ShopFrontendTestPanel.dashboardColumnWidth,
                child: preview,
              ),
            Expanded(child: main),
          ],
        ),
        if (!splitMode && openPref)
          _FrontendEmbedAutoCloser(onClose: onAutoClose),
      ],
    );
  }
}

class _FrontendEmbedAutoCloser extends StatefulWidget {
  const _FrontendEmbedAutoCloser({required this.onClose});

  final VoidCallback onClose;

  @override
  State<_FrontendEmbedAutoCloser> createState() =>
      _FrontendEmbedAutoCloserState();
}

class _FrontendEmbedAutoCloserState extends State<_FrontendEmbedAutoCloser> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      widget.onClose();
    });
  }

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}

Future<void> showShopFrontendPreviewDialog({
  required BuildContext context,
  required String shopId,
  required String shopCode,
  VoidCallback? onOpenFullPage,
  Widget? previewBodyOverride,
}) {
  return showDialog<void>(
    context: context,
    barrierDismissible: true,
    builder: (BuildContext dialogContext) {
      return Dialog(
        insetPadding: const EdgeInsets.all(16),
        clipBehavior: Clip.antiAlias,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 400, maxHeight: 860),
          child: ShopFrontendTestPanel(
            shopId: shopId,
            shopCode: shopCode,
            onClose: () => Navigator.of(dialogContext).pop(),
            onOpenFullPage: () {
              Navigator.of(dialogContext).pop();
              onOpenFullPage?.call();
            },
            previewBodyOverride: previewBodyOverride,
          ),
        ),
      );
    },
  );
}
