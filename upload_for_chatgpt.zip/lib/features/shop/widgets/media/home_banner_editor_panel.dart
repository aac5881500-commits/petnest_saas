// 檔案名稱：lib/features/shop/widgets/media/home_banner_editor_panel.dart
// 功能說明：首頁活動海報編輯。桌機與手機共用欄位，只上傳完整 16:9 海報。

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_banner_display.dart';
import 'package:petnest_saas/core/models/store_banner_model.dart';
import 'package:petnest_saas/features/shop/pages/store/shop_store_banner_editor_page.dart';

class HomeBannerEditorPanel extends StatelessWidget {
  const HomeBannerEditorPanel({
    super.key,
    required this.shopId,
    required this.draft,
    required this.busy,
    required this.uploading,
    required this.onChanged,
    required this.onPickImage,
    required this.onRemoveImage,
    required this.onDelete,
  });

  final String shopId;

  static const List<String> sectionTitles = <String>['海報圖片', '海報狀態', '點擊後動作'];

  final StoreBannerModel? draft;
  final bool busy;
  final bool uploading;
  final ValueChanged<StoreBannerModel> onChanged;
  final VoidCallback onPickImage;
  final VoidCallback onRemoveImage;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final StoreBannerModel? banner = draft;
    if (banner == null) {
      return const Text('請先新增或選擇一張海報');
    }
    final bool locked = busy || uploading;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (!banner.isCompletePoster) ...<Widget>[
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF4E5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFFFCC80)),
            ),
            child: const Text(
              '此為舊版套版海報。建議改為上傳已完成設計的 16:9 完整海報，避免不同裝置文字跑版。',
              style: TextStyle(height: 1.4),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.tonalIcon(
              onPressed: locked ? null : onPickImage,
              icon: const Icon(Icons.swap_horiz),
              label: const Text('更換為完整海報'),
            ),
          ),
          const SizedBox(height: 16),
        ],
        Text(
          sectionTitles[0],
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        const Text(
          '請上傳已完成設計的 16:9 海報，建議 1600 × 900 px。App 不會再自動加入文字或按鈕。',
          style: TextStyle(fontSize: 13, height: 1.4, color: Colors.black54),
        ),
        const SizedBox(height: 4),
        const Text(
          '支援 JPG / PNG / WEBP，最大 5 MB。',
          style: TextStyle(fontSize: 12, color: Colors.black45),
        ),
        const SizedBox(height: 10),
        AspectRatio(
          aspectRatio: HomeBannerDisplay.aspectRatio,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: ColoredBox(
              color: const Color(0xFFF3F1EE),
              child: banner.hasImage
                  ? Image.network(
                      banner.frontImageUrl,
                      fit: BoxFit.contain,
                      errorBuilder:
                          (
                            BuildContext context,
                            Object error,
                            StackTrace? stack,
                          ) {
                            return const Center(child: Text('圖片無法顯示'));
                          },
                    )
                  : const Center(
                      child: Text(
                        '尚未上傳海報',
                        style: TextStyle(color: Colors.black54),
                      ),
                    ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            FilledButton.icon(
              onPressed: locked ? null : onPickImage,
              icon: uploading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.upload_outlined),
              label: Text(banner.hasImage ? '更換海報' : '上傳海報'),
            ),
            OutlinedButton.icon(
              onPressed: locked || !banner.hasImage ? null : onRemoveImage,
              icon: const Icon(Icons.delete_outline),
              label: const Text('移除海報'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Text(
          sectionTitles[1],
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('啟用'),
          subtitle: const Text('關閉後，前台首頁不會顯示這張海報'),
          value: banner.enabled,
          onChanged: locked
              ? null
              : (bool value) => onChanged(banner.copyWith(enabled: value)),
        ),
        const SizedBox(height: 8),
        Text(
          sectionTitles[2],
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        const Text(
          '整張海報都可以點。按鈕不會畫在圖片上。',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: HomeBannerActionTypes.editorTypes.map((String type) {
            return ChoiceChip(
              label: Text(HomeBannerActionTypes.label(type)),
              selected: banner.actionType == type,
              onSelected: locked
                  ? null
                  : (_) => onChanged(
                      banner.copyWith(actionType: type, actionTargetId: ''),
                    ),
            );
          }).toList(),
        ),
        if (banner.actionType == HomeBannerActionTypes.url) ...<Widget>[
          const SizedBox(height: 8),
          TextFormField(
            key: ValueKey<String>('url_${banner.id}'),
            initialValue: banner.actionTargetId,
            decoration: const InputDecoration(
              labelText: '外部網址',
              hintText: 'https://',
              border: OutlineInputBorder(),
            ),
            onChanged: (String value) {
              onChanged(banner.copyWith(actionTargetId: value.trim()));
            },
          ),
        ],
        if (banner.actionType == HomeBannerActionTypes.product)
          StoreBannerActionTargetPicker(
            shopId: shopId,
            actionType: banner.actionType,
            selectedId: banner.actionTargetId,
            onSelected: (String id) {
              onChanged(banner.copyWith(actionTargetId: id));
            },
          ),
        const SizedBox(height: 12),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: locked ? null : onDelete,
            child: const Text('刪除海報'),
          ),
        ),
      ],
    );
  }
}
