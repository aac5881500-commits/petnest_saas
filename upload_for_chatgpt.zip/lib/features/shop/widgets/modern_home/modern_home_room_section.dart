import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_room_section_setting.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';

/// 新版首頁房型展示。正式前台與外觀預覽共用這一個元件。
class ModernHomeRoomSection extends StatelessWidget {
  const ModernHomeRoomSection({
    super.key,
    required this.theme,
    required this.setting,
    required this.roomTypes,
    required this.preview,
    this.loadFailed = false,
    this.selectedRoomTypeId,
    this.onSelectRoomType,
    this.onOpenRoom,
    this.onOpenAllRooms,
    this.onManageRooms,
  });

  final HomeThemeModel theme;
  final HomeRoomSectionSetting setting;
  final List<Map<String, dynamic>> roomTypes;
  final bool preview;
  final bool loadFailed;
  final String? selectedRoomTypeId;
  final ValueChanged<String>? onSelectRoomType;
  final ValueChanged<Map<String, dynamic>>? onOpenRoom;
  final VoidCallback? onOpenAllRooms;
  final VoidCallback? onManageRooms;

  String get _title {
    final String title = setting.title.trim();
    return title.isEmpty ? '房型介紹' : title;
  }

  Map<String, Map<String, dynamic>> get _byId {
    final Map<String, Map<String, dynamic>> rooms =
        <String, Map<String, dynamic>>{};
    for (final Map<String, dynamic> room in roomTypes) {
      final String id = HomeRoomSectionSetting.roomTypeIdOf(room);
      if (id.isNotEmpty) {
        rooms[id] = room;
      }
    }
    return rooms;
  }

  @override
  Widget build(BuildContext context) {
    if (loadFailed) {
      return _message('房型資料讀取失敗');
    }
    final bool published = HomeRoomSectionSetting.hasPublishedRooms(roomTypes);
    if (!published) {
      if (!preview) {
        return const SizedBox.shrink();
      }
      return _emptyPreview();
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (setting.layout != HomeRoomSectionLayouts.simpleEntry) _header(),
        if (setting.layout != HomeRoomSectionLayouts.simpleEntry)
          const SizedBox(height: 9),
        _body(),
      ],
    );
  }

  Widget _header() {
    final bool titleAction =
        setting.layout == HomeRoomSectionLayouts.compactCards &&
        setting.compact.allRoomsPlacement ==
            HomeRoomAllRoomsPlacements.titleRight;
    return Row(
      children: <Widget>[
        Icon(
          Icons.bedroom_parent_outlined,
          size: 16,
          color: theme.primaryColor,
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            _title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 16,
              height: 1.2,
              fontWeight: FontWeight.w800,
              color: theme.textColor,
            ),
          ),
        ),
        if (titleAction)
          TextButton(
            onPressed: _openAll,
            child: Text(
              '全部房型',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: theme.primaryColor,
              ),
            ),
          ),
      ],
    );
  }

  Widget _body() {
    final Map<String, Map<String, dynamic>> rooms = _byId;
    switch (setting.layout) {
      case HomeRoomSectionLayouts.simpleEntry:
        return _simpleEntry();
      case HomeRoomSectionLayouts.mixedGrid:
        return _mixed(rooms);
      default:
        return _compact(rooms);
    }
  }

  Widget _compact(Map<String, Map<String, dynamic>> rooms) {
    final List<List<HomeRoomSlot>> rows = HomeRoomSectionSetting.compactRows(
      roomIds: setting.homeRoomIds(roomTypes),
      columns: setting.compact.safeColumns,
      includeEndCard:
          setting.compact.allRoomsPlacement ==
          HomeRoomAllRoomsPlacements.endCard,
    );
    return _rows(
      rows,
      rooms,
      imageHeight: HomeRoomImageHeights.compactPixels(
        setting.compact.imageHeight,
      ),
      overlay: false,
    );
  }

  Widget _mixed(Map<String, Map<String, dynamic>> rooms) {
    final List<String> ids = setting.homeRoomIds(roomTypes);
    if (ids.isEmpty) {
      return _allRoomsCard(fullWidth: true, imageHeight: 96);
    }
    final bool overlay =
        setting.mixed.textPlacement == HomeRoomMixedTextPlacements.overlay;
    final List<List<HomeRoomSlot>> rows = HomeRoomSectionSetting.mixedRows(
      roomIds: ids,
      sizeOf: setting.mixed.sizeOf,
    );
    return Column(
      children: <Widget>[
        for (int index = 0; index < rows.length; index++) ...<Widget>[
          if (index > 0) const SizedBox(height: 8),
          _row(
            rows[index],
            rooms,
            imageHeightFor: (HomeRoomSlot slot) {
              if (slot.fullWidth) {
                return HomeRoomImageHeights.largePixels(
                  setting.mixed.largeImageHeight,
                );
              }
              return HomeRoomImageHeights.compactPixels(
                setting.mixed.smallImageHeight,
              );
            },
            overlay: overlay,
          ),
        ],
      ],
    );
  }

  Widget _rows(
    List<List<HomeRoomSlot>> rows,
    Map<String, Map<String, dynamic>> rooms, {
    required double imageHeight,
    required bool overlay,
  }) {
    if (rows.isEmpty) {
      return const SizedBox.shrink();
    }
    return Column(
      children: <Widget>[
        for (int index = 0; index < rows.length; index++) ...<Widget>[
          if (index > 0) const SizedBox(height: 8),
          _row(
            rows[index],
            rooms,
            imageHeightFor: (_) => imageHeight,
            overlay: overlay,
          ),
        ],
      ],
    );
  }

  Widget _row(
    List<HomeRoomSlot> slots,
    Map<String, Map<String, dynamic>> rooms, {
    required double Function(HomeRoomSlot slot) imageHeightFor,
    required bool overlay,
  }) {
    if (slots.length == 1 && slots.first.fullWidth) {
      return _slot(
        slots.first,
        rooms,
        imageHeight: imageHeightFor(slots.first),
        overlay: overlay,
      );
    }
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          for (int index = 0; index < slots.length; index++) ...<Widget>[
            if (index > 0) const SizedBox(width: 8),
            Expanded(
              child: _slot(
                slots[index],
                rooms,
                imageHeight: imageHeightFor(slots[index]),
                overlay: overlay,
              ),
            ),
          ],
          if (slots.length == 1) const Expanded(child: SizedBox.shrink()),
        ],
      ),
    );
  }

  Widget _slot(
    HomeRoomSlot slot,
    Map<String, Map<String, dynamic>> rooms, {
    required double imageHeight,
    required bool overlay,
  }) {
    if (slot.allRooms) {
      return _allRoomsCard(fullWidth: slot.fullWidth, imageHeight: imageHeight);
    }
    final Map<String, dynamic>? room = rooms[slot.roomTypeId];
    if (room == null) {
      return const SizedBox.shrink();
    }
    return _roomCard(
      room: room,
      roomTypeId: slot.roomTypeId!,
      imageHeight: imageHeight,
      overlay: overlay,
    );
  }

  Widget _simpleEntry() {
    final Color fill = switch (setting.simple.surface) {
      HomeRoomSimpleSurfaces.transparent => Colors.transparent,
      HomeRoomSimpleSurfaces.outlined => theme.backgroundColor,
      _ => theme.cardColor,
    };
    final Border? border =
        setting.simple.surface == HomeRoomSimpleSurfaces.transparent
        ? null
        : Border.all(color: theme.cardBorderColor);
    return Material(
      color: fill,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        key: const Key('home-room-simple'),
        borderRadius: BorderRadius.circular(14),
        onTap: _openAll,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: border,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: <Widget>[
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: theme.primaryColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _simpleIcon(setting.simple.icon),
                    color: theme.primaryColor,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        _title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 15,
                          height: 1.2,
                          fontWeight: FontWeight.w800,
                          color: theme.textColor,
                        ),
                      ),
                      if (setting.simple.showSubtitle) ...<Widget>[
                        const SizedBox(height: 2),
                        Text(
                          setting.simple.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12,
                            height: 1.2,
                            color: theme.secondaryTextColor,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: theme.primaryColor),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _roomCard({
    required Map<String, dynamic> room,
    required String roomTypeId,
    required double imageHeight,
    required bool overlay,
  }) {
    final String name = (room['name'] ?? '未命名房型').toString().trim();
    final String imageUrl = _firstImage(room);
    final bool selected = selectedRoomTypeId == roomTypeId;
    final String price = HomeRoomSectionSetting.priceLabel(room['price']);
    return Material(
      color: theme.cardColor,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        key: Key('home-room-card-$roomTypeId'),
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          if (preview) {
            onSelectRoomType?.call(roomTypeId);
            return;
          }
          onOpenRoom?.call(room);
        },
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? theme.primaryColor : theme.cardBorderColor,
              width: selected ? 2 : 1,
            ),
          ),
          child: overlay
              ? _overlayCard(
                  name: name,
                  price: price,
                  imageUrl: imageUrl,
                  imageHeight: imageHeight,
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    HomeRoomCover(
                      imageUrl: imageUrl,
                      height: imageHeight,
                      theme: theme,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
                      child: _caption(name: name, price: price, onImage: false),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _overlayCard({
    required String name,
    required String price,
    required String imageUrl,
    required double imageHeight,
  }) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(13)),
      child: SizedBox(
        height: imageHeight,
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            HomeRoomCover(
              imageUrl: imageUrl,
              height: imageHeight,
              theme: theme,
            ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0x00000000), Color(0xB3000000)],
                  stops: <double>[0.45, 1],
                ),
              ),
            ),
            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: _caption(name: name, price: price, onImage: true),
            ),
          ],
        ),
      ),
    );
  }

  Widget _caption({
    required String name,
    required String price,
    required bool onImage,
  }) {
    final Color nameColor = onImage ? Colors.white : theme.textColor;
    final Color priceColor = onImage ? Colors.white : theme.primaryColor;
    final bool showPrice =
        setting.showPrice &&
        setting.layout != HomeRoomSectionLayouts.simpleEntry;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Text(
          name.isEmpty ? '未命名房型' : name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 13,
            height: 1.2,
            fontWeight: FontWeight.w800,
            color: nameColor,
          ),
        ),
        if (showPrice) ...<Widget>[
          const SizedBox(height: 2),
          Text(
            price,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              height: 1.2,
              fontWeight: FontWeight.w800,
              color: priceColor,
            ),
          ),
        ],
      ],
    );
  }

  Widget _allRoomsCard({required bool fullWidth, required double imageHeight}) {
    return Material(
      color: theme.cardColor,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        key: const Key('home-room-all'),
        borderRadius: BorderRadius.circular(14),
        onTap: _openAll,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.cardBorderColor),
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: fullWidth ? 72 : imageHeight,
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    Icons.meeting_room_outlined,
                    color: theme.primaryColor,
                    size: 22,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '查看全部房型',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: theme.textColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _emptyPreview() {
    return Container(
      key: const Key('home-room-empty-preview'),
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.cardBorderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            '目前尚未建立已發布房型',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: theme.textColor,
            ),
          ),
          const SizedBox(height: 8),
          TextButton(onPressed: onManageRooms, child: const Text('前往房型管理')),
        ],
      ),
    );
  }

  Widget _message(String text) {
    return Container(
      width: double.infinity,
      height: 96,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.cardBorderColor),
      ),
      child: Text(
        text,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 12, color: theme.secondaryTextColor),
      ),
    );
  }

  void _openAll() {
    if (preview) {
      onSelectRoomType?.call('');
      return;
    }
    onOpenAllRooms?.call();
  }

  static String _firstImage(Map<String, dynamic> room) {
    final Object? raw = room['images'];
    if (raw is! List) {
      return '';
    }
    for (final Object? item in raw) {
      final String url = item?.toString().trim() ?? '';
      if (url.isNotEmpty) {
        return url;
      }
    }
    return '';
  }

  static IconData _simpleIcon(String icon) {
    switch (icon) {
      case HomeRoomSimpleIcons.home:
        return Icons.home_outlined;
      case HomeRoomSimpleIcons.hotel:
        return Icons.holiday_village_outlined;
      default:
        return Icons.bed_outlined;
    }
  }
}

class HomeRoomCover extends StatelessWidget {
  const HomeRoomCover({
    super.key,
    required this.imageUrl,
    required this.height,
    required this.theme,
    this.imageProvider,
  });

  final String imageUrl;
  final double height;
  final HomeThemeModel theme;
  final ImageProvider<Object>? imageProvider;

  @override
  Widget build(BuildContext context) {
    final ImageProvider<Object>? provider = imageProvider;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(13)),
        child: provider != null
            ? Image(
                image: provider,
                fit: BoxFit.cover,
                gaplessPlayback: true,
                errorBuilder: (_, _, _) => _fallback(),
              )
            : imageUrl.isEmpty
            ? _fallback()
            : Image.network(
                imageUrl,
                fit: BoxFit.cover,
                gaplessPlayback: true,
                errorBuilder: (_, _, _) => _fallback(),
              ),
      ),
    );
  }

  Widget _fallback() {
    return ColoredBox(
      color: theme.primaryColor.withValues(alpha: 0.12),
      child: Center(
        child: Icon(
          Icons.bedroom_parent_outlined,
          key: const Key('home-room-fallback-icon'),
          size: 28,
          color: theme.primaryColor,
        ),
      ),
    );
  }
}
