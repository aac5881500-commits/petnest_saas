import 'dart:ui' show PointerDeviceKind;

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_display_style.dart';
import 'package:petnest_saas/core/models/home_room_section_setting.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/core/models/platform_media_asset.dart';
import 'package:petnest_saas/core/services/platform_media_library_service.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/modern_home_entry_card.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/refined_image_entry_card.dart';

/// 新版首頁房型展示。正式前台與外觀預覽共用這一個元件。
class ModernHomeRoomSection extends StatelessWidget {
  const ModernHomeRoomSection({
    super.key,
    required this.theme,
    required this.setting,
    required this.roomTypes,
    required this.preview,
    this.loadFailed = false,
    this.selectedRoomTypeId,
    this.onSelectRoomType,
    this.onOpenRoom,
    this.onOpenAllRooms,
    this.onManageRooms,
    this.simpleImageUrl = '',
    this.displayStyle,
  });

  final HomeThemeModel theme;
  final HomeRoomSectionSetting setting;
  final List<Map<String, dynamic>> roomTypes;
  final bool preview;
  final bool loadFailed;
  final String? selectedRoomTypeId;
  final ValueChanged<String>? onSelectRoomType;
  final ValueChanged<Map<String, dynamic>>? onOpenRoom;
  final VoidCallback? onOpenAllRooms;
  final VoidCallback? onManageRooms;

  /// 簡約入口的平台圖庫圖片。其他排版不使用，也不會寫回房型。
  final String simpleImageUrl;
  final HomeDisplayStyle? displayStyle;

  String get _title {
    final String title = setting.title.trim();
    return title.isEmpty ? '房型介紹' : title;
  }

  Map<String, Map<String, dynamic>> get _byId {
    final Map<String, Map<String, dynamic>> rooms =
        <String, Map<String, dynamic>>{};
    for (final Map<String, dynamic> room in roomTypes) {
      final String id = HomeRoomSectionSetting.roomTypeIdOf(room);
      if (id.isNotEmpty) {
        rooms[id] = room;
      }
    }
    return rooms;
  }

  @override
  Widget build(BuildContext context) {
    if (loadFailed) {
      return _withFont(_message('房型資料讀取失敗'));
    }
    final bool published = HomeRoomSectionSetting.hasPublishedRooms(roomTypes);
    if (!published) {
      if (!preview) {
        return const SizedBox.shrink();
      }
      return _withFont(_emptyPreview());
    }
    return _withFont(
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (setting.layout != HomeRoomSectionLayouts.simpleEntry) _header(),
          if (setting.layout != HomeRoomSectionLayouts.simpleEntry)
            const SizedBox(height: 9),
          _body(),
        ],
      ),
    );
  }

  Widget _withFont(Widget child) {
    final String? family = setting.appliedFontFamily;
    if (family == null) {
      return child;
    }
    return Builder(
      builder: (BuildContext context) {
        final ThemeData current = Theme.of(context);
        return Theme(
          data: current.copyWith(
            textTheme: current.textTheme.apply(fontFamily: family),
            primaryTextTheme: current.primaryTextTheme.apply(
              fontFamily: family,
            ),
          ),
          child: DefaultTextStyle.merge(
            style: TextStyle(fontFamily: family),
            child: child,
          ),
        );
      },
    );
  }

  Widget _header() {
    final bool titleAction =
        setting.layout == HomeRoomSectionLayouts.cardGrid &&
        setting.compact.allRoomsPlacement ==
            HomeRoomAllRoomsPlacements.titleRight;
    return Row(
      children: <Widget>[
        Icon(
          Icons.bedroom_parent_outlined,
          size: 16,
          color: theme.primaryColor,
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            _title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 16,
              height: 1.2,
              fontWeight: FontWeight.w800,
              color: theme.textColor,
            ),
          ),
        ),
        if (titleAction)
          TextButton(
            onPressed: _openAll,
            child: Text(
              '全部房型',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: theme.primaryColor,
              ),
            ),
          ),
      ],
    );
  }

  Widget _body() {
    final Map<String, Map<String, dynamic>> rooms = _byId;
    switch (setting.layout) {
      case HomeRoomSectionLayouts.simpleEntry:
        return _simpleEntry();
      case HomeRoomSectionLayouts.featured:
        return _featured(rooms);
      case HomeRoomSectionLayouts.cardGrid:
        return _cardGrid(rooms);
      case HomeRoomSectionLayouts.refinedCards:
        return _refined(rooms);
      default:
        return _horizontal(rooms);
    }
  }

  Widget _featured(Map<String, Map<String, dynamic>> rooms) {
    final List<String> ids = setting.homeRoomIds(roomTypes);
    final List<String> visible = ids.take(2).toList();
    return Column(
      key: const Key('home-room-featured'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (int index = 0; index < visible.length; index++) ...<Widget>[
          if (index > 0) const SizedBox(height: 12),
          _featuredRoom(
            room: rooms[visible[index]]!,
            roomTypeId: visible[index],
            imageFirst: index.isEven,
          ),
        ],
        if (ids.length > visible.length) ...<Widget>[
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
              onPressed: _openAll,
              child: Text(
                '查看全部房型',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: theme.primaryColor,
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _featuredRoom({
    required Map<String, dynamic> room,
    required String roomTypeId,
    required bool imageFirst,
  }) {
    final String name = (room['name'] ?? '未命名房型').toString().trim();
    final String imageUrl = _firstImage(room);
    final String description = (room['description'] ?? '').toString().trim();
    final String price = setting.showPrice
        ? HomeRoomSectionSetting.priceLabel(room['price'])
        : '';
    final Widget photo = HomeRoomCover(
      imageUrl: imageUrl,
      height: imageFirst ? 188 : 132,
      theme: theme,
      borderRadius: BorderRadius.circular(16),
    );
    final Widget copy = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          name.isEmpty ? '未命名房型' : name,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: imageFirst ? 20 : 16,
            height: 1.25,
            fontWeight: FontWeight.w800,
            color: theme.textColor,
          ),
        ),
        if (description.isNotEmpty) ...<Widget>[
          const SizedBox(height: 6),
          Text(
            description,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 13,
              height: 1.4,
              color: theme.secondaryTextColor,
            ),
          ),
        ],
        if (price.isNotEmpty) ...<Widget>[
          const SizedBox(height: 8),
          Text(
            price,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: theme.primaryColor,
            ),
          ),
        ],
        const SizedBox(height: 8),
        Text(
          '查看房型',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: theme.primaryColor,
          ),
        ),
      ],
    );
    return Material(
      color: Colors.transparent,
      child: InkWell(
        key: Key('home-room-featured-$roomTypeId'),
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          if (preview) {
            onSelectRoomType?.call(roomTypeId);
            return;
          }
          onOpenRoom?.call(room);
        },
        child: imageFirst
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[photo, const SizedBox(height: 10), copy],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(flex: 5, child: copy),
                  const SizedBox(width: 12),
                  Expanded(flex: 4, child: photo),
                ],
              ),
      ),
    );
  }

  Widget _refined(Map<String, Map<String, dynamic>> rooms) {
    final List<String> ids = setting.homeRoomIds(roomTypes);
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double maxWidth = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : 320;
        final double cardWidth = maxWidth >= 640
            ? 248
            : (maxWidth * 0.78).clamp(196.0, 280.0);
        final double imageHeight = cardWidth * 0.66;
        final double textScale = MediaQuery.textScalerOf(context).scale(1);
        final double cardHeight = imageHeight + 136 * textScale;
        return SizedBox(
          height: cardHeight,
          child: ScrollConfiguration(
            behavior: ScrollConfiguration.of(context).copyWith(
              dragDevices: const <PointerDeviceKind>{
                PointerDeviceKind.touch,
                PointerDeviceKind.mouse,
                PointerDeviceKind.stylus,
                PointerDeviceKind.trackpad,
              },
            ),
            child: ListView.separated(
              key: const Key('home-room-refined'),
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              primary: false,
              itemCount: ids.length + 1,
              separatorBuilder: (_, _) => const SizedBox(width: 12),
              itemBuilder: (BuildContext context, int index) {
                if (index == ids.length) {
                  return SizedBox(
                    width: 132,
                    child: _allRoomsCard(
                      fullWidth: false,
                      imageHeight: imageHeight,
                    ),
                  );
                }
                final String id = ids[index];
                final Map<String, dynamic>? room = rooms[id];
                if (room == null) {
                  return const SizedBox.shrink();
                }
                return SizedBox(
                  width: cardWidth,
                  child: _refinedCard(room: room, roomTypeId: id),
                );
              },
            ),
          ),
        );
      },
    );
  }

  Widget _refinedCard({
    required Map<String, dynamic> room,
    required String roomTypeId,
  }) {
    final String name = (room['name'] ?? '未命名房型').toString().trim();
    final String description = (room['description'] ?? '').toString().trim();
    final String price = setting.showPrice
        ? HomeRoomSectionSetting.priceLabel(room['price'])
        : '';
    final bool selected = selectedRoomTypeId == roomTypeId;
    return Material(
      color: theme.cardColor,
      elevation: 0,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        key: Key('home-room-card-$roomTypeId'),
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          if (preview) {
            onSelectRoomType?.call(roomTypeId);
            return;
          }
          onOpenRoom?.call(room);
        },
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? theme.primaryColor : theme.cardBorderColor,
              width: selected ? 2 : 1,
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: theme.textColor.withValues(alpha: 0.08),
                blurRadius: 14,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                child: HomeRoomCover(
                  imageUrl: _firstImage(room),
                  height: double.infinity,
                  theme: theme,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(17),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      name.isEmpty ? '未命名房型' : name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 15,
                        height: 1.2,
                        fontWeight: FontWeight.w800,
                        color: theme.textColor,
                      ),
                    ),
                    if (price.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Text(
                        price,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.2,
                          fontWeight: FontWeight.w800,
                          color: theme.primaryColor,
                        ),
                      ),
                    ],
                    if (description.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Text(
                        description,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          height: 1.3,
                          color: theme.secondaryTextColor,
                        ),
                      ),
                    ],
                    const SizedBox(height: 6),
                    Text(
                      '查看詳情',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        height: 1.2,
                        fontWeight: FontWeight.w800,
                        color: theme.primaryColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _horizontal(Map<String, Map<String, dynamic>> rooms) {
    final List<String> ids = setting.homeRoomIds(roomTypes);
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double maxWidth = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : 320;
        final double cardWidth = (maxWidth * 0.42).clamp(112.0, 168.0);
        final double textScale = MediaQuery.textScalerOf(context).scale(1);
        final double imageHeight = 70;
        final double cardHeight =
            imageHeight + 18 + (setting.showPrice ? 40 : 24) * textScale;
        return SizedBox(
          height: cardHeight,
          child: MouseRegion(
            cursor: SystemMouseCursors.grab,
            child: ScrollConfiguration(
              behavior: ScrollConfiguration.of(context).copyWith(
                dragDevices: const <PointerDeviceKind>{
                  PointerDeviceKind.touch,
                  PointerDeviceKind.mouse,
                  PointerDeviceKind.stylus,
                  PointerDeviceKind.trackpad,
                },
              ),
              child: ListView.separated(
                key: const Key('home-room-scroll'),
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                primary: false,
                itemCount: ids.length + 1,
                separatorBuilder: (_, _) => const SizedBox(width: 8),
                itemBuilder: (BuildContext context, int index) {
                  if (index == ids.length) {
                    return SizedBox(
                      width: 88,
                      child: _allRoomsCard(
                        fullWidth: false,
                        imageHeight: imageHeight,
                      ),
                    );
                  }
                  final String id = ids[index];
                  final Map<String, dynamic>? room = rooms[id];
                  if (room == null) {
                    return const SizedBox.shrink();
                  }
                  return SizedBox(
                    width: cardWidth,
                    child: _roomCard(
                      room: room,
                      roomTypeId: id,
                      imageHeight: imageHeight,
                      overlay: false,
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _cardGrid(Map<String, Map<String, dynamic>> rooms) {
    final List<String> ids = setting.homeRoomIds(roomTypes);
    final bool fillWithAllRooms =
        setting.compact.allRoomsPlacement == HomeRoomAllRoomsPlacements.endCard;
    if (ids.isEmpty) {
      if (!fillWithAllRooms) {
        return const SizedBox.shrink();
      }
      return _allRoomsCard(fullWidth: true, imageHeight: 96);
    }
    final bool overlay =
        setting.mixed.textPlacement == HomeRoomMixedTextPlacements.overlay;
    final List<List<HomeRoomSlot>> rows = HomeRoomSectionSetting.mixedRows(
      roomIds: ids,
      sizeOf: setting.mixed.sizeOf,
      fillWithAllRooms: fillWithAllRooms,
    );
    return Column(
      children: <Widget>[
        for (int index = 0; index < rows.length; index++) ...<Widget>[
          if (index > 0) const SizedBox(height: 8),
          _row(
            rows[index],
            rooms,
            imageHeightFor: (HomeRoomSlot slot) {
              if (slot.size == HomeRoomCardSizes.single) {
                return HomeRoomImageHeights.singlePixels(
                  setting.mixed.largeImageHeight,
                );
              }
              return HomeRoomImageHeights.compactPixels(
                setting.mixed.smallImageHeight,
              );
            },
            overlay: overlay,
          ),
        ],
      ],
    );
  }

  Widget _row(
    List<HomeRoomSlot> slots,
    Map<String, Map<String, dynamic>> rooms, {
    required double Function(HomeRoomSlot slot) imageHeightFor,
    required bool overlay,
  }) {
    if (slots.length == 1 && slots.first.fullWidth) {
      return _slot(
        slots.first,
        rooms,
        imageHeight: imageHeightFor(slots.first),
        overlay: overlay,
      );
    }
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          for (int index = 0; index < slots.length; index++) ...<Widget>[
            if (index > 0) const SizedBox(width: 8),
            Expanded(
              child: _slot(
                slots[index],
                rooms,
                imageHeight: imageHeightFor(slots[index]),
                overlay: overlay,
              ),
            ),
          ],
          if (slots.length == 1) const Expanded(child: SizedBox.shrink()),
        ],
      ),
    );
  }

  Widget _slot(
    HomeRoomSlot slot,
    Map<String, Map<String, dynamic>> rooms, {
    required double imageHeight,
    required bool overlay,
  }) {
    if (slot.allRooms) {
      return _allRoomsCard(fullWidth: slot.fullWidth, imageHeight: imageHeight);
    }
    final Map<String, dynamic>? room = rooms[slot.roomTypeId];
    if (room == null) {
      return const SizedBox.shrink();
    }
    return _roomCard(
      room: room,
      roomTypeId: slot.roomTypeId!,
      imageHeight: imageHeight,
      overlay: overlay && slot.size != HomeRoomCardSizes.wide,
      layoutSize: slot.size,
      nameMaxLines: 2,
    );
  }

  Widget _simpleEntry() {
    final String imageUrl = simpleImageUrl.trim();
    if (imageUrl.isEmpty) {
      return ModernHomeEntryCard(
        cardKey: const Key('home-room-simple'),
        theme: theme,
        title: _title,
        subtitle: setting.simple.subtitle,
        showSubtitle: setting.simple.showSubtitle,
        cardSize: setting.simple.cardSize,
        surface: setting.simple.surface,
        icon: _simpleIcon(setting.simple.icon),
        actionLabel: '查看全部房型',
        onTap: _openAll,
      );
    }
    final HomeRoomSimpleSetting simple = setting.simple;
    return RefinedImageEntryCard(
      cardKey: const Key('home-room-simple'),
      featureId: 'rooms',
      theme: theme,
      title: _title,
      subtitle: simple.subtitle,
      showSubtitle: simple.showSubtitle,
      textMode: simple.textMode,
      textAlign: simple.textAlign,
      imageUrl: imageUrl,
      surface: displayStyle?.cardBackground ?? simple.surface,
      sizeMode: RefinedEntrySizeMode.independent,
      placeholderIcon: _simpleIcon(simple.icon),
      textPosition: displayStyle?.textPosition,
      textSize: displayStyle?.titleSize ?? simple.textSize,
      textWeight: displayStyle?.titleWeight ?? simple.textWeight,
      textColor: displayStyle == null
          ? simple.textColor
          : HomeRoomSimpleTextColors.custom,
      textColorValue: displayStyle?.titleColor ?? simple.textColorValue,
      aspect: displayStyle?.imageAspect ?? simple.aspect,
      radius: displayStyle?.imageRadius ?? simple.radius,
      mask: displayStyle?.imageMask ?? simple.mask,
      bodySize: displayStyle?.bodySize,
      bodyWeight: displayStyle?.bodyWeight,
      bodyColorValue: displayStyle?.effectiveBodyColor,
      spacing: displayStyle?.spacing ?? HomeDisplaySpacings.normal,
      cardPadding: displayStyle?.cardPadding ?? HomeDisplaySpacings.normal,
      showBorder: displayStyle?.cardBorder ?? true,
      cardShadow: displayStyle?.cardShadow ?? HomeDisplayShadows.none,
      contentAlign: displayStyle?.titleAlign,
      imageFit: displayStyle?.imageFit ?? HomeDisplayFits.cover,
      onTap: _openAll,
    );
  }

  Widget _roomCard({
    required Map<String, dynamic> room,
    required String roomTypeId,
    required double imageHeight,
    required bool overlay,
    String? layoutSize,
    int nameMaxLines = 1,
  }) {
    final String name = (room['name'] ?? '未命名房型').toString().trim();
    final String imageUrl = _firstImage(room);
    final bool selected = selectedRoomTypeId == roomTypeId;
    final String price = HomeRoomSectionSetting.priceLabel(room['price']);
    final bool wide = layoutSize == HomeRoomCardSizes.wide;
    return Material(
      color: theme.cardColor,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        key: Key('home-room-card-$roomTypeId'),
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          if (preview) {
            onSelectRoomType?.call(roomTypeId);
            return;
          }
          onOpenRoom?.call(room);
        },
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? theme.primaryColor : theme.cardBorderColor,
              width: selected ? 2 : 1,
            ),
          ),
          child: wide
              ? _wideCard(
                  roomTypeId: roomTypeId,
                  name: name,
                  price: price,
                  imageUrl: imageUrl,
                )
              : overlay
              ? _overlayCard(
                  name: name,
                  price: price,
                  imageUrl: imageUrl,
                  imageHeight: imageHeight,
                  nameMaxLines: nameMaxLines,
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    HomeRoomCover(
                      imageUrl: imageUrl,
                      height: imageHeight,
                      theme: theme,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
                      child: _caption(
                        name: name,
                        price: price,
                        onImage: false,
                        nameMaxLines: nameMaxLines,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _wideCard({
    required String roomTypeId,
    required String name,
    required String price,
    required String imageUrl,
  }) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double maxWidth = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : 320;
        double imageWidth = maxWidth * 0.36;
        if (imageWidth > 136) {
          imageWidth = 136;
        }
        if (imageWidth > maxWidth * 0.46) {
          imageWidth = maxWidth * 0.46;
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              width: imageWidth,
              child: HomeRoomCover(
                imageUrl: imageUrl,
                height: 108,
                theme: theme,
                borderRadius: const BorderRadius.horizontal(
                  left: Radius.circular(13),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    _caption(
                      name: name,
                      price: price,
                      onImage: false,
                      nameMaxLines: 2,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            '查看房型',
                            key: Key('home-room-wide-hint-$roomTypeId'),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              height: 1.2,
                              fontWeight: FontWeight.w700,
                              color: theme.primaryColor,
                            ),
                          ),
                        ),
                        Icon(
                          Icons.chevron_right_rounded,
                          size: 16,
                          color: theme.primaryColor,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _overlayCard({
    required String name,
    required String price,
    required String imageUrl,
    required double imageHeight,
    int nameMaxLines = 1,
  }) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(13)),
      child: SizedBox(
        height: imageHeight,
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            HomeRoomCover(
              imageUrl: imageUrl,
              height: imageHeight,
              theme: theme,
            ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0x00000000), Color(0xB3000000)],
                  stops: <double>[0.45, 1],
                ),
              ),
            ),
            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: _caption(
                name: name,
                price: price,
                onImage: true,
                nameMaxLines: nameMaxLines,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _caption({
    required String name,
    required String price,
    required bool onImage,
    int nameMaxLines = 1,
  }) {
    final Color nameColor = onImage ? Colors.white : theme.textColor;
    final Color priceColor = onImage ? Colors.white : theme.primaryColor;
    final bool showPrice =
        setting.showPrice &&
        setting.layout != HomeRoomSectionLayouts.simpleEntry;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Text(
          name.isEmpty ? '未命名房型' : name,
          maxLines: nameMaxLines,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 13,
            height: 1.2,
            fontWeight: FontWeight.w800,
            color: nameColor,
          ),
        ),
        if (showPrice) ...<Widget>[
          const SizedBox(height: 2),
          Text(
            price,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              height: 1.2,
              fontWeight: FontWeight.w800,
              color: priceColor,
            ),
          ),
        ],
      ],
    );
  }

  Widget _allRoomsCard({required bool fullWidth, required double imageHeight}) {
    return Material(
      color: theme.cardColor,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        key: const Key('home-room-all'),
        borderRadius: BorderRadius.circular(14),
        onTap: _openAll,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.cardBorderColor),
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: fullWidth ? 72 : imageHeight,
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    Icons.meeting_room_outlined,
                    color: theme.primaryColor,
                    size: 22,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '查看全部房型',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: theme.textColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _emptyPreview() {
    return Container(
      key: const Key('home-room-empty-preview'),
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.cardBorderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            '目前尚未建立已發布房型',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: theme.textColor,
            ),
          ),
          const SizedBox(height: 8),
          TextButton(onPressed: onManageRooms, child: const Text('前往房型管理')),
        ],
      ),
    );
  }

  Widget _message(String text) {
    return Container(
      width: double.infinity,
      height: 96,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.cardBorderColor),
      ),
      child: Text(
        text,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 12, color: theme.secondaryTextColor),
      ),
    );
  }

  void _openAll() {
    if (preview) {
      onSelectRoomType?.call('');
      return;
    }
    onOpenAllRooms?.call();
  }

  static String _firstImage(Map<String, dynamic> room) {
    final Object? raw = room['images'];
    if (raw is! List) {
      return '';
    }
    for (final Object? item in raw) {
      final String url = item?.toString().trim() ?? '';
      if (url.isNotEmpty) {
        return url;
      }
    }
    return '';
  }

  static IconData _simpleIcon(String icon) => homeRoomSimpleIcon(icon);
}

IconData homeRoomSimpleIcon(String icon) {
  switch (icon) {
    case HomeRoomSimpleIcons.home:
      return Icons.home_outlined;
    case HomeRoomSimpleIcons.hotel:
      return Icons.holiday_village_outlined;
    default:
      return Icons.bed_outlined;
  }
}

/// 讀取簡約入口的平台圖庫圖片。不會改房型照片。
class ModernHomeRoomSectionHost extends StatefulWidget {
  const ModernHomeRoomSectionHost({
    super.key,
    required this.assetId,
    required this.builder,
  });

  final String assetId;
  final Widget Function(String imageUrl) builder;

  @override
  State<ModernHomeRoomSectionHost> createState() =>
      _ModernHomeRoomSectionHostState();
}

class _ModernHomeRoomSectionHostState extends State<ModernHomeRoomSectionHost> {
  String _url = '';
  int _token = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(ModernHomeRoomSectionHost oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.assetId != widget.assetId) {
      _load();
    }
  }

  Future<void> _load() async {
    final int token = ++_token;
    final String id = widget.assetId.trim();
    if (id.isEmpty) {
      if (mounted && _url.isNotEmpty) {
        setState(() => _url = '');
      }
      return;
    }
    final PlatformMediaAsset? asset = await PlatformMediaLibraryService.instance
        .getEnabledAssetById(id);
    if (!mounted || token != _token) {
      return;
    }
    final String next = asset?.imageUrl.trim() ?? '';
    if (next == _url) {
      return;
    }
    setState(() => _url = next);
  }

  @override
  Widget build(BuildContext context) {
    return widget.builder(_url);
  }
}

class HomeRoomCover extends StatelessWidget {
  const HomeRoomCover({
    super.key,
    required this.imageUrl,
    required this.height,
    required this.theme,
    this.imageProvider,
    this.borderRadius = _topRadius,
  });

  final String imageUrl;
  final double height;
  final HomeThemeModel theme;
  final ImageProvider<Object>? imageProvider;
  final BorderRadius borderRadius;

  static const BorderRadius _topRadius = BorderRadius.vertical(
    top: Radius.circular(13),
  );

  @override
  Widget build(BuildContext context) {
    final ImageProvider<Object>? provider = imageProvider;
    final Widget clipped = ClipRRect(
      borderRadius: borderRadius,
      child: provider != null
          ? Image(
              image: provider,
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, _, _) => _fallback(),
            )
          : imageUrl.isEmpty
          ? _fallback()
          : Image.network(
              imageUrl,
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, _, _) => _fallback(),
            ),
    );
    if (!height.isFinite) {
      return SizedBox.expand(child: clipped);
    }
    return SizedBox(height: height, width: double.infinity, child: clipped);
  }

  Widget _fallback() {
    return ColoredBox(
      color: theme.primaryColor.withValues(alpha: 0.12),
      child: Center(
        child: Icon(
          Icons.bedroom_parent_outlined,
          key: const Key('home-room-fallback-icon'),
          size: 28,
          color: theme.primaryColor,
        ),
      ),
    );
  }
}
