import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';

/// 首頁店家識別與側邊欄精簡店名是兩種顯示情境，不可共用位置或 GlobalKey。
enum StoreBrandDisplayContext { home, drawer }

/// 店家識別區的排版。座標是首頁內容區內的 0～1，不是螢幕像素。
class StoreBrandStyle {
  const StoreBrandStyle({
    this.x = 0.5,
    this.y = 0,
    this.widthRatio = defaultWidthRatio,
    this.nameColorValue,
    this.subtitleColorValue,
    this.textShadowEnabled = false,
    this.textAlign = 'center',
    this.nameFontSize = 18,
    this.subtitleFontSize = 12,
    this.logoPlacement = 'leading',
    this.logoSize = 'medium',
    this.fallbackIcon = 'paw',
  });

  static const double defaultWidthRatio = 0.72;
  static const double minWidthRatio = 0.3;
  static const double maxWidthRatio = 1;
  static const double logoGap = 10;
  static const Object _keep = Object();

  final double x;
  final double y;
  final double widthRatio;
  final int? nameColorValue;
  final int? subtitleColorValue;
  final bool textShadowEnabled;
  final String textAlign;
  final double nameFontSize;
  final double subtitleFontSize;
  final String logoPlacement;
  final String logoSize;
  final String fallbackIcon;

  bool get showsLogo => logoPlacement == 'leading' || logoPlacement == 'trailing';

  double get logoExtent {
    switch (logoSize) {
      case 'small':
        return 32;
      case 'large':
        return 56;
      default:
        return 44;
    }
  }

  TextAlign get flutterTextAlign {
    switch (textAlign) {
      case 'left':
        return TextAlign.left;
      case 'right':
        return TextAlign.right;
      default:
        return TextAlign.center;
    }
  }

  CrossAxisAlignment get columnAlign {
    switch (textAlign) {
      case 'left':
        return CrossAxisAlignment.start;
      case 'right':
        return CrossAxisAlignment.end;
      default:
        return CrossAxisAlignment.center;
    }
  }

  Color nameColor(Color themeText) {
    final int? value = nameColorValue;
    if (value == null) {
      return themeText;
    }
    return Color(value);
  }

  Color subtitleColor(Color themeText) {
    final int? value = subtitleColorValue;
    if (value == null) {
      return themeText.withValues(alpha: 0.68);
    }
    return Color(value);
  }

  List<Shadow>? get textShadows {
    if (!textShadowEnabled) {
      return null;
    }
    return const <Shadow>[
      Shadow(color: Color(0x99000000), blurRadius: 8, offset: Offset(0, 1)),
    ];
  }

  StoreBrandStyle copyWith({
    double? x,
    double? y,
    double? widthRatio,
    Object? nameColorValue = _keep,
    Object? subtitleColorValue = _keep,
    bool? textShadowEnabled,
    String? textAlign,
    double? nameFontSize,
    double? subtitleFontSize,
    String? logoPlacement,
    String? logoSize,
    String? fallbackIcon,
  }) {
    return StoreBrandStyle(
      x: x ?? this.x,
      y: y ?? this.y,
      widthRatio: widthRatio ?? this.widthRatio,
      nameColorValue: identical(nameColorValue, _keep)
          ? this.nameColorValue
          : nameColorValue as int?,
      subtitleColorValue: identical(subtitleColorValue, _keep)
          ? this.subtitleColorValue
          : subtitleColorValue as int?,
      textShadowEnabled: textShadowEnabled ?? this.textShadowEnabled,
      textAlign: textAlign ?? this.textAlign,
      nameFontSize: nameFontSize ?? this.nameFontSize,
      subtitleFontSize: subtitleFontSize ?? this.subtitleFontSize,
      logoPlacement: logoPlacement ?? this.logoPlacement,
      logoSize: logoSize ?? this.logoSize,
      fallbackIcon: fallbackIcon ?? this.fallbackIcon,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'homepageBrandX': x,
      'homepageBrandY': y,
      'homepageBrandWidthRatio': widthRatio,
      if (nameColorValue != null) 'homepageBrandNameColor': nameColorValue,
      if (subtitleColorValue != null)
        'homepageBrandSubtitleColor': subtitleColorValue,
      'homepageBrandTextShadowEnabled': textShadowEnabled,
      'homepageBrandTextAlign': textAlign,
      'homepageBrandNameFontSize': nameFontSize,
      'homepageBrandSubtitleFontSize': subtitleFontSize,
      'homepageBrandLogoPlacement': logoPlacement,
      'homepageBrandLogoSize': logoSize,
      'showLeftHeaderIcon': logoPlacement == 'leading',
      'showRightHeaderIcon': logoPlacement == 'trailing',
      'leftHeaderIcon': fallbackIcon,
      'rightHeaderIcon': fallbackIcon,
    };
  }

  static StoreBrandStyle fromMap(dynamic raw) {
    final Map<String, dynamic> map = raw is Map
        ? Map<String, dynamic>.from(raw)
        : <String, dynamic>{};
    return StoreBrandStyle(
      x: _unit(map['homepageBrandX'], 0.5),
      y: _unit(map['homepageBrandY'], 0),
      widthRatio: _width(map['homepageBrandWidthRatio']),
      nameColorValue: map.containsKey('homepageBrandNameColor')
          ? HomeThemeModel.parseColorValue(map['homepageBrandNameColor'], 0)
          : null,
      subtitleColorValue: map.containsKey('homepageBrandSubtitleColor')
          ? HomeThemeModel.parseColorValue(
              map['homepageBrandSubtitleColor'],
              0,
            )
          : null,
      textShadowEnabled: map['homepageBrandTextShadowEnabled'] == true,
      textAlign: _align(map['homepageBrandTextAlign']),
      nameFontSize: _font(map['homepageBrandNameFontSize'], 18, 16, 48),
      subtitleFontSize: _font(
        map['homepageBrandSubtitleFontSize'],
        12,
        10,
        28,
      ),
      logoPlacement: _placement(map),
      logoSize: _logoSize(map['homepageBrandLogoSize']),
      fallbackIcon: _icon(map),
    );
  }

  static StoreBrandStyle resetPlacement(StoreBrandStyle style) {
    return style.copyWith(x: 0.5, y: 0, widthRatio: defaultWidthRatio);
  }

  static double _unit(dynamic value, double fallback) {
    if (value is! num) {
      return fallback;
    }
    return value.toDouble().clamp(0, 1).toDouble();
  }

  static double _width(dynamic value) {
    if (value is! num) {
      return defaultWidthRatio;
    }
    return value
        .toDouble()
        .clamp(minWidthRatio, maxWidthRatio)
        .toDouble();
  }

  static double _font(
    dynamic value,
    double fallback,
    double min,
    double max,
  ) {
    if (value is! num) {
      return fallback;
    }
    return value.toDouble().clamp(min, max).toDouble();
  }

  static String _align(dynamic value) {
    switch (value) {
      case 'left':
      case 'right':
      case 'center':
        return value as String;
      default:
        return 'center';
    }
  }

  static String _logoSize(dynamic value) {
    switch (value) {
      case 'small':
      case 'large':
        return value as String;
      default:
        return 'medium';
    }
  }

  static String _placement(Map<String, dynamic> map) {
    final String raw = (map['homepageBrandLogoPlacement'] ?? '').toString();
    if (raw == 'none' || raw == 'leading' || raw == 'trailing') {
      return raw;
    }
    final bool left = map.containsKey('showLeftHeaderIcon')
        ? map['showLeftHeaderIcon'] != false
        : true;
    final bool right = map.containsKey('showRightHeaderIcon')
        ? map['showRightHeaderIcon'] != false
        : true;
    if (left && !right) {
      return 'leading';
    }
    if (right && !left) {
      return 'trailing';
    }
    if (!left && !right) {
      return 'none';
    }
    return 'leading';
  }

  static String _icon(Map<String, dynamic> map) {
    final String placement = _placement(map);
    final String preferred = placement == 'trailing'
        ? (map['rightHeaderIcon'] ?? map['leftHeaderIcon'] ?? 'paw').toString()
        : (map['leftHeaderIcon'] ?? map['rightHeaderIcon'] ?? 'paw').toString();
    switch (preferred) {
      case 'heart':
      case 'star':
      case 'home':
      case 'crown':
      case 'paw':
        return preferred;
      default:
        return 'paw';
    }
  }

  static IconData iconData(String value) {
    switch (value) {
      case 'heart':
        return Icons.favorite_rounded;
      case 'star':
        return Icons.star_rounded;
      case 'home':
        return Icons.home_rounded;
      case 'crown':
        return Icons.workspace_premium_rounded;
      case 'paw':
      default:
        return Icons.pets_rounded;
    }
  }
}

/// 把 normalized x/y 換成父層內容區內的左上角，再夾回安全範圍。
class StoreBrandGeometry {
  static double widthFor(double parentWidth, double ratio) {
    if (parentWidth <= 0) {
      return 0;
    }
    final double clamped = ratio
        .clamp(StoreBrandStyle.minWidthRatio, StoreBrandStyle.maxWidthRatio)
        .toDouble();
    return parentWidth * clamped;
  }

  static Rect travel({
    required Size parent,
    required double blockWidth,
    required double blockHeight,
    required double bottomObstacle,
  }) {
    final double maxX = math.max(0, parent.width - blockWidth);
    final double maxY = math.max(
      0,
      parent.height - math.max(0, bottomObstacle) - blockHeight,
    );
    return Rect.fromLTRB(0, 0, maxX, maxY);
  }

  static Offset denormalize({
    required double x,
    required double y,
    required Rect travel,
  }) {
    return Offset(
      travel.left + x.clamp(0, 1) * (travel.right - travel.left),
      travel.top + y.clamp(0, 1) * (travel.bottom - travel.top),
    );
  }

  static Offset normalize({
    required Offset topLeft,
    required Rect travel,
  }) {
    final double dx = travel.right - travel.left;
    final double dy = travel.bottom - travel.top;
    return Offset(
      dx <= 0.5 ? 0.5 : ((topLeft.dx - travel.left) / dx).clamp(0.0, 1.0),
      dy <= 0.5 ? 0 : ((topLeft.dy - travel.top) / dy).clamp(0.0, 1.0),
    );
  }

  static Offset clampTopLeft(Offset topLeft, Rect travel) {
    return Offset(
      topLeft.dx.clamp(travel.left, travel.right).toDouble(),
      topLeft.dy.clamp(travel.top, travel.bottom).toDouble(),
    );
  }
}
