import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/shop_modern_logo.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_style.dart';

/// 只負責顯示店家識別。首頁與側邊欄各自建立，不共用 GlobalKey，也不讀取拖曳座標。
class StoreBrandBlock extends StatelessWidget {
  const StoreBrandBlock({
    super.key,
    required this.contextKind,
    required this.style,
    required this.shopName,
    required this.subtitle,
    required this.logoUrl,
    required this.theme,
  });

  final StoreBrandDisplayContext contextKind;
  final StoreBrandStyle style;
  final String shopName;
  final String subtitle;
  final String logoUrl;
  final HomeThemeModel theme;

  @override
  Widget build(BuildContext context) {
    final String name = shopName.trim().isEmpty ? '店家' : shopName.trim();
    final String caption = subtitle.trim();
    final Color nameColor = style.nameColor(theme.textColor);
    final Color subtitleColor = style.subtitleColor(theme.textColor);
    final List<Shadow>? shadows = style.textShadows;
    final Widget text = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: style.columnAlign,
      children: <Widget>[
        Text(
          name,
          textAlign: style.flutterTextAlign,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: style.nameFontSize,
            height: 1.2,
            fontWeight: FontWeight.w800,
            color: nameColor,
            shadows: shadows,
          ),
        ),
        if (caption.isNotEmpty) ...<Widget>[
          const SizedBox(height: 2),
          Text(
            caption,
            textAlign: style.flutterTextAlign,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: style.subtitleFontSize,
              height: 1.2,
              fontWeight: FontWeight.w500,
              color: subtitleColor,
              shadows: shadows,
            ),
          ),
        ],
      ],
    );
    return Semantics(
      container: true,
      label: contextKind == StoreBrandDisplayContext.home ? '首頁店家識別' : '側邊欄店家',
      child: SizedBox(
      width: double.infinity,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          if (style.logoPlacement == 'leading') ...<Widget>[
            _mark(),
            const SizedBox(width: StoreBrandStyle.logoGap),
          ],
          Flexible(child: text),
          if (style.logoPlacement == 'trailing') ...<Widget>[
            const SizedBox(width: StoreBrandStyle.logoGap),
            _mark(),
          ],
        ],
      ),
    ),
    );
  }

  Widget _mark() {
    if (!style.showsLogo) {
      return const SizedBox.shrink();
    }
    final double size = style.logoExtent;
    final String url = logoUrl.trim();
    if (url.isNotEmpty) {
      return ShopModernLogo(
        imageUrl: url,
        size: size,
        primaryColor: theme.primaryColor,
        borderRadius: size * 0.22,
      );
    }
    return SizedBox(
      width: size,
      height: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: theme.primaryColor.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(size * 0.22),
        ),
        child: Icon(
          StoreBrandStyle.iconData(style.fallbackIcon),
          size: size * 0.56,
          color: theme.primaryColor,
        ),
      ),
    );
  }
}
