import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_block.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_style.dart';

/// 正式前台只放位置，不畫選取框，也不接收拖曳。
class StoreBrandPlacement extends StatefulWidget {
  const StoreBrandPlacement({
    super.key,
    required this.style,
    required this.shopName,
    required this.subtitle,
    required this.logoUrl,
    required this.theme,
    required this.bottomObstacle,
  });

  final StoreBrandStyle style;
  final String shopName;
  final String subtitle;
  final String logoUrl;
  final HomeThemeModel theme;
  final double bottomObstacle;

  @override
  State<StoreBrandPlacement> createState() => _StoreBrandPlacementState();
}

class _StoreBrandPlacementState extends State<StoreBrandPlacement> {
  final GlobalKey _blockKey = GlobalKey(debugLabel: 'storeBrandHome');
  double _height = 56;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final Size parent = Size(constraints.maxWidth, constraints.maxHeight);
        final double width = StoreBrandGeometry.widthFor(
          parent.width,
          widget.style.widthRatio,
        );
        final Rect travel = StoreBrandGeometry.travel(
          parent: parent,
          blockWidth: width,
          blockHeight: _height,
          bottomObstacle: widget.bottomObstacle,
        );
        final Offset topLeft = StoreBrandGeometry.denormalize(
          x: widget.style.x,
          y: widget.style.y,
          travel: travel,
        );
        _scheduleMeasure();
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Positioned(
              left: topLeft.dx,
              top: topLeft.dy,
              width: width,
              child: KeyedSubtree(
                key: _blockKey,
                child: _block(),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _block() {
    return StoreBrandBlock(
      contextKind: StoreBrandDisplayContext.home,
      style: widget.style,
      shopName: widget.shopName,
      subtitle: widget.subtitle,
      logoUrl: widget.logoUrl,
      theme: widget.theme,
    );
  }

  void _scheduleMeasure() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final double? next = _blockKey.currentContext?.size?.height;
      if (!mounted || next == null || (next - _height).abs() < 0.5) {
        return;
      }
      setState(() => _height = next);
    });
  }
}

/// 左側預覽的選取框、拖曳與寬度控制。正式前台不要建立這個 widget。
class StoreBrandEditorOverlay extends StatefulWidget {
  const StoreBrandEditorOverlay({
    super.key,
    required this.style,
    required this.shopName,
    required this.subtitle,
    required this.logoUrl,
    required this.theme,
    required this.bottomObstacle,
    required this.onChanged,
  });

  final StoreBrandStyle style;
  final String shopName;
  final String subtitle;
  final String logoUrl;
  final HomeThemeModel theme;
  final double bottomObstacle;
  final ValueChanged<StoreBrandStyle> onChanged;

  @override
  State<StoreBrandEditorOverlay> createState() =>
      _StoreBrandEditorOverlayState();
}

class _StoreBrandEditorOverlayState extends State<StoreBrandEditorOverlay> {
  final GlobalKey _layerKey = GlobalKey(debugLabel: 'storeBrandLayer');
  final GlobalKey _blockKey = GlobalKey(debugLabel: 'storeBrandEditor');
  bool _selected = false;
  bool _gesture = false;
  double _height = 56;
  double? _left;
  double? _top;
  double? _width;
  Offset? _grab;

  @override
  void didUpdateWidget(StoreBrandEditorOverlay oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!_gesture) {
      _left = null;
      _top = null;
      _width = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final Size parent = Size(constraints.maxWidth, constraints.maxHeight);
        final double width =
            _width ??
            StoreBrandGeometry.widthFor(parent.width, widget.style.widthRatio);
        final Rect travel = StoreBrandGeometry.travel(
          parent: parent,
          blockWidth: width,
          blockHeight: _height,
          bottomObstacle: widget.bottomObstacle,
        );
        final Offset resolved = StoreBrandGeometry.clampTopLeft(
          _left == null || _top == null
              ? StoreBrandGeometry.denormalize(
                  x: widget.style.x,
                  y: widget.style.y,
                  travel: travel,
                )
              : Offset(_left!, _top!),
          travel,
        );
        _scheduleMeasure();
        return SizedBox.expand(
          key: _layerKey,
          child: Stack(
            clipBehavior: Clip.none,
            children: <Widget>[
              Positioned(
                left: resolved.dx,
                top: resolved.dy,
                width: width,
                child: _moveTarget(resolved, width),
              ),
              if (_selected) ...<Widget>[
                Positioned(
                  left: resolved.dx - 9,
                  top: resolved.dy + _height / 2 - 14,
                  child: _handle(side: 'left', origin: resolved, width: width),
                ),
                Positioned(
                  left: resolved.dx + width - 9,
                  top: resolved.dy + _height / 2 - 14,
                  child: _handle(side: 'right', origin: resolved, width: width),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _moveTarget(Offset origin, double width) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanDown: (DragDownDetails details) {
        final RenderBox? box = _layerBox();
        if (box == null) {
          return;
        }
        final Offset local = box.globalToLocal(details.globalPosition);
        setState(() {
          _selected = true;
          _gesture = true;
          _grab = local - origin;
          _left = origin.dx;
          _top = origin.dy;
          _width = width;
        });
      },
      onPanUpdate: (DragUpdateDetails details) {
        final RenderBox? box = _layerBox();
        final Offset? grab = _grab;
        if (box == null || grab == null || !_gesture) {
          return;
        }
        final Offset local = box.globalToLocal(details.globalPosition);
        final Rect travel = _travelFor(box.size, _width ?? width);
        final Offset next = StoreBrandGeometry.clampTopLeft(
          local - grab,
          travel,
        );
        setState(() {
          _left = next.dx;
          _top = next.dy;
        });
      },
      onPanEnd: (_) => _commit(),
      onPanCancel: _commit,
      child: KeyedSubtree(
        key: _blockKey,
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: _selected
                  ? const Color(0xFFB86B18)
                  : const Color(0x00000000),
              width: 1.5,
            ),
          ),
          child: StoreBrandBlock(
            contextKind: StoreBrandDisplayContext.home,
            style: widget.style,
            shopName: widget.shopName,
            subtitle: widget.subtitle,
            logoUrl: widget.logoUrl,
            theme: widget.theme,
          ),
        ),
      ),
    );
  }

  Widget _handle({
    required String side,
    required Offset origin,
    required double width,
  }) {
    return GestureDetector(
      key: ValueKey<String>('store-brand-handle-$side'),
      behavior: HitTestBehavior.opaque,
      onPanDown: (DragDownDetails details) {
        final RenderBox? box = _layerBox();
        if (box == null) {
          return;
        }
        final Offset local = box.globalToLocal(details.globalPosition);
        final double edge = side == 'left' ? origin.dx : origin.dx + width;
        setState(() {
          _gesture = true;
          _grab = Offset(local.dx - edge, 0);
          _left = origin.dx;
          _top = origin.dy;
          _width = width;
        });
      },
      onPanUpdate: (DragUpdateDetails details) {
        final RenderBox? box = _layerBox();
        final Offset? grab = _grab;
        if (box == null || grab == null) {
          return;
        }
        final double pointer =
            box.globalToLocal(details.globalPosition).dx - grab.dx;
        final double minW = StoreBrandGeometry.widthFor(
          box.size.width,
          StoreBrandStyle.minWidthRatio,
        );
        final double maxW = StoreBrandGeometry.widthFor(
          box.size.width,
          StoreBrandStyle.maxWidthRatio,
        );
        final double right = (_left ?? origin.dx) + (_width ?? width);
        final double nextLeft;
        final double nextWidth;
        if (side == 'right') {
          final double left = (_left ?? origin.dx).clamp(0, box.size.width);
          final double raw = (pointer - left).clamp(minW, maxW).toDouble();
          nextLeft = left;
          nextWidth = math.min(raw, box.size.width - left);
        } else {
          final double raw = (right - pointer).clamp(minW, maxW).toDouble();
          final double left = (right - raw).clamp(0, box.size.width - raw);
          nextLeft = left.toDouble();
          nextWidth = right - nextLeft;
        }
        setState(() {
          _left = nextLeft;
          _width = nextWidth;
        });
      },
      onPanEnd: (_) => _commit(),
      onPanCancel: _commit,
      child: const SizedBox(
        width: 18,
        height: 28,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Color(0xFFB86B18),
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
        ),
      ),
    );
  }

  RenderBox? _layerBox() {
    final RenderObject? object = _layerKey.currentContext?.findRenderObject();
    if (object is RenderBox && object.hasSize) {
      return object;
    }
    return null;
  }

  Rect _travelFor(Size parent, double width) {
    return StoreBrandGeometry.travel(
      parent: parent,
      blockWidth: width,
      blockHeight: _height,
      bottomObstacle: widget.bottomObstacle,
    );
  }

  void _commit() {
    final RenderBox? box = _layerBox();
    final double? left = _left;
    final double? top = _top;
    final double? width = _width;
    if (box == null || left == null || top == null || width == null) {
      setState(() => _gesture = false);
      return;
    }
    final Rect travel = _travelFor(box.size, width);
    final Offset clamped = StoreBrandGeometry.clampTopLeft(
      Offset(left, top),
      travel,
    );
    final Offset normalized = StoreBrandGeometry.normalize(
      topLeft: clamped,
      travel: travel,
    );
    final double ratio = box.size.width <= 0
        ? widget.style.widthRatio
        : (width / box.size.width)
              .clamp(
                StoreBrandStyle.minWidthRatio,
                StoreBrandStyle.maxWidthRatio,
              )
              .toDouble();
    final Offset settled = StoreBrandGeometry.denormalize(
      x: normalized.dx,
      y: normalized.dy,
      travel: travel,
    );
    setState(() {
      _gesture = false;
      _left = settled.dx;
      _top = settled.dy;
      _width = width;
    });
    widget.onChanged(
      widget.style.copyWith(
        x: normalized.dx,
        y: normalized.dy,
        widthRatio: ratio,
      ),
    );
  }

  void _scheduleMeasure() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final double? next = _blockKey.currentContext?.size?.height;
      if (!mounted || next == null || (next - _height).abs() < 0.5) {
        return;
      }
      setState(() => _height = next);
    });
  }
}
