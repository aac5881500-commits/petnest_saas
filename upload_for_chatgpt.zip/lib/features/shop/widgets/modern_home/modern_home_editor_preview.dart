// 檔案名稱：lib/features/shop/widgets/modern_home/modern_home_editor_preview.dart
// 功能說明：新版 Beta 外觀設定的手機預覽。內容就是正式新版首頁。

import 'package:flutter/material.dart';
import 'package:petnest_saas/features/shop/pages/shop_public_modern_page.dart';

class ModernHomeEditorPreview extends StatelessWidget {
  const ModernHomeEditorPreview({
    super.key,
    required this.shopId,
    required this.draftModernAppearance,
    required this.draftLogoUrl,
    this.showCaption = true,
  });

  final String shopId;
  final Map<String, dynamic> draftModernAppearance;
  final String draftLogoUrl;
  final bool showCaption;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (showCaption) ...<Widget>[
          const Text(
            '即時預覽',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 2),
          Text(
            '調整右側設定後立即查看新版首頁效果',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
          ),
          const SizedBox(height: 12),
        ],
        Expanded(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 390, maxHeight: 780),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: const Color(0xFFD0D5DD)),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(
                      color: Color(0x14000000),
                      blurRadius: 18,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: Navigator(
                      pages: <Page<void>>[
                        MaterialPage<void>(
                          key: const ValueKey<String>('modern-home-preview'),
                          child: ShopPublicModernPage(
                            key: const ValueKey<String>(
                              'modern-home-preview-page',
                            ),
                            shopId: shopId,
                            isPreview: true,
                            draftModernAppearance: draftModernAppearance,
                            draftLogoUrl: draftLogoUrl,
                          ),
                        ),
                      ],
                      onDidRemovePage: (Page<Object?> page) {},
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
