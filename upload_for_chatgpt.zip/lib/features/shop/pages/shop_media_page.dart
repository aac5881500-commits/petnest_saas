// 檔案名稱：lib/features/shop/pages/shop_media_page.dart
// 功能說明：首頁活動海報管理。桌機與手機共用 HomeBannerEditorPanel。

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:petnest_saas/core/models/home_banner_display.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/core/models/store_banner_model.dart';
import 'package:petnest_saas/core/services/home_banner_service.dart';
import 'package:petnest_saas/core/services/inventory_image_service.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/features/shop/widgets/media/home_banner_editor_panel.dart';
import 'package:petnest_saas/features/shop/widgets/media/shop_banner_device_preview.dart';

class ShopMediaPage extends StatefulWidget {
  const ShopMediaPage({super.key, required this.shopId});

  final String shopId;

  @override
  State<ShopMediaPage> createState() => _ShopMediaPageState();
}

class _ShopMediaPageState extends State<ShopMediaPage> {
  final ImagePicker _picker = ImagePicker();
  bool _loaded = false;
  bool _busy = false;
  bool _uploading = false;
  List<StoreBannerModel> _banners = <StoreBannerModel>[];
  HomeThemeModel _theme = HomeThemeModel.modernDefault;
  BannerPreviewSize _previewSize = BannerPreviewSize.phone;
  int _selectedIndex = 0;
  bool _dirty = false;
  bool _retainUploadedImage = false;
  String _pendingUrl = '';
  String _pendingPath = '';
  String _retiredUrl = '';
  String _retiredPath = '';

  StoreBannerModel? get _draft {
    if (_banners.isEmpty ||
        _selectedIndex < 0 ||
        _selectedIndex >= _banners.length) {
      return null;
    }
    return _banners[_selectedIndex];
  }

  @override
  void initState() {
    super.initState();
    _loadBanners();
  }

  @override
  void dispose() {
    if (!_retainUploadedImage) {
      _discardPending();
    }
    super.dispose();
  }

  Future<void> _discardPending() async {
    if (_pendingPath.isEmpty && _pendingUrl.isEmpty) {
      return;
    }
    await InventoryImageService.instance.tryDeleteImage(
      imageUrl: _pendingUrl,
      imageStoragePath: _pendingPath,
    );
  }

  Future<void> _loadBanners() async {
    final Map<String, dynamic>? shop = await ShopService.instance.getShop(
      widget.shopId,
    );
    if (!mounted) {
      return;
    }
    setState(() {
      _banners = HomeBannerService.instance.parseBanners(shop?['banners']);
      _theme = HomeBannerService.instance.themeFromShop(shop);
      _loaded = true;
      _selectedIndex = 0;
      _dirty = false;
    });
  }

  Future<void> _persist(List<StoreBannerModel> banners) async {
    await HomeBannerService.instance.saveBanners(
      shopId: widget.shopId,
      banners: banners,
    );
  }

  void _replaceSelected(StoreBannerModel next) {
    if (_draft == null) {
      return;
    }
    setState(() {
      _banners[_selectedIndex] = next;
      _dirty = true;
    });
  }

  Future<void> _addBanner() async {
    if (_banners.length >= HomeBannerService.maxCount) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('最多只能 5 張海報')));
      return;
    }
    final StoreBannerModel created = StoreBannerModel(
      id: 'home_${DateTime.now().millisecondsSinceEpoch}',
      enabled: true,
      sortOrder: _banners.length,
      sizePreset: StoreBannerSizePresets.standard,
      contentMode: StoreBannerContentModes.imageOnly,
      actionType: HomeBannerActionTypes.none,
      createdAt: DateTime.now(),
    );
    setState(() {
      _banners = <StoreBannerModel>[..._banners, created];
      _selectedIndex = _banners.length - 1;
      _dirty = true;
    });
  }

  Future<void> _pickImage() async {
    final StoreBannerModel? current = _draft;
    if (current == null || _uploading) {
      return;
    }
    try {
      final XFile? file = await _picker.pickImage(source: ImageSource.gallery);
      if (file == null) {
        return;
      }
      final String name = file.name.toLowerCase();
      final bool allowed =
          name.endsWith('.jpg') ||
          name.endsWith('.jpeg') ||
          name.endsWith('.png') ||
          name.endsWith('.webp');
      if (!allowed) {
        _toast('只支援 JPG、PNG、WEBP');
        return;
      }
      final Uint8List bytes = await file.readAsBytes();
      if (bytes.length > HomeBannerDisplay.maxBytes) {
        _toast('圖片不可超過 5 MB');
        return;
      }
      final img.Image? decoded = img.decodeImage(bytes);
      if (decoded == null) {
        _toast('無法讀取這張圖片，請換一張再上傳');
        return;
      }
      if (!HomeBannerDisplay.isSixteenByNine(decoded.width, decoded.height)) {
        _toast('請重新製作 16:9 海報後再上傳。建議尺寸 1600 × 900 px，App 不會裁切或加字。');
        return;
      }
      if (!mounted) {
        return;
      }
      setState(() => _uploading = true);
      final String contentType = name.endsWith('.png')
          ? 'image/png'
          : name.endsWith('.webp')
          ? 'image/webp'
          : 'image/jpeg';
      final InventoryImageUploadResult uploaded = await InventoryImageService
          .instance
          .uploadBytes(
            shopId: widget.shopId,
            itemId: '${current.id}/p_${DateTime.now().millisecondsSinceEpoch}',
            bytes: bytes,
            folder: HomeBannerService.imageFolder,
            imageType: 'home_banner',
            idMetadataKey: 'bannerId',
            contentType: contentType,
          );
      if (_pendingPath.isNotEmpty) {
        await InventoryImageService.instance.tryDeleteImage(
          imageUrl: _pendingUrl,
          imageStoragePath: _pendingPath,
        );
      } else if (current.imageStoragePath.isNotEmpty) {
        _retiredUrl = current.imageUrl;
        _retiredPath = current.imageStoragePath;
      }
      if (!mounted) {
        return;
      }
      setState(() {
        _pendingUrl = uploaded.imageUrl;
        _pendingPath = uploaded.imageStoragePath;
        _banners[_selectedIndex] = current.copyWith(
          imageUrl: uploaded.imageUrl,
          imageStoragePath: uploaded.imageStoragePath,
          contentMode: StoreBannerContentModes.imageOnly,
          imageScale: 1,
        );
        _dirty = true;
      });
    } catch (error) {
      _toast('上傳失敗：$error');
    } finally {
      if (mounted) {
        setState(() => _uploading = false);
      }
    }
  }

  Future<void> _removeImage() async {
    final StoreBannerModel? current = _draft;
    if (current == null) {
      return;
    }
    if (_pendingPath.isNotEmpty) {
      await InventoryImageService.instance.tryDeleteImage(
        imageUrl: _pendingUrl,
        imageStoragePath: _pendingPath,
      );
      _pendingUrl = '';
      _pendingPath = '';
    } else if (current.imageStoragePath.isNotEmpty) {
      _retiredUrl = current.imageUrl;
      _retiredPath = current.imageStoragePath;
    }
    _replaceSelected(
      current.copyWith(
        imageUrl: '',
        imageStoragePath: '',
        contentMode: StoreBannerContentModes.imageOnly,
      ),
    );
  }

  Future<void> _deleteBanner() async {
    if (_draft == null) {
      return;
    }
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('刪除海報'),
          content: const Text('確定刪除此活動海報？'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('刪除'),
            ),
          ],
        );
      },
    );
    if (confirmed != true || !mounted || _draft == null) {
      return;
    }
    final StoreBannerModel banner = _banners[_selectedIndex];
    final List<StoreBannerModel> next = List<StoreBannerModel>.from(_banners)
      ..removeAt(_selectedIndex);
    setState(() {
      _banners = next;
      _selectedIndex = next.isEmpty
          ? 0
          : _selectedIndex.clamp(0, next.length - 1);
      _dirty = true;
    });
    if (banner.imageStoragePath == _pendingPath && _pendingPath.isNotEmpty) {
      await InventoryImageService.instance.tryDeleteImage(
        imageUrl: _pendingUrl,
        imageStoragePath: _pendingPath,
      );
      _pendingUrl = '';
      _pendingPath = '';
    }
  }

  void _onReorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex--;
      }
      final String selectedId = _draft?.id ?? '';
      final StoreBannerModel item = _banners.removeAt(oldIndex);
      _banners.insert(newIndex, item);
      for (int i = 0; i < _banners.length; i++) {
        _banners[i] = _banners[i].copyWith(sortOrder: i);
      }
      final int found = _banners.indexWhere(
        (StoreBannerModel banner) => banner.id == selectedId,
      );
      _selectedIndex = found < 0 ? 0 : found;
      _dirty = true;
    });
  }

  Future<void> _save() async {
    for (final StoreBannerModel banner in _banners) {
      if (!banner.hasImage) {
        _toast('請先上傳海報圖片');
        return;
      }
    }
    for (final StoreBannerModel banner in _banners) {
      final String? error = HomeBannerDisplay.validateAction(banner);
      if (error != null) {
        _toast(error);
        return;
      }
    }
    setState(() => _busy = true);
    try {
      final List<StoreBannerModel> next = <StoreBannerModel>[];
      for (int i = 0; i < _banners.length; i++) {
        next.add(_banners[i].copyWith(sortOrder: i, updatedAt: DateTime.now()));
      }
      await _persist(next);
      _retainUploadedImage = true;
      if (_retiredPath.isNotEmpty) {
        await InventoryImageService.instance.tryDeleteImage(
          imageUrl: _retiredUrl,
          imageStoragePath: _retiredPath,
        );
      }
      _pendingUrl = '';
      _pendingPath = '';
      _retiredUrl = '';
      _retiredPath = '';
      if (!mounted) {
        return;
      }
      setState(() {
        _banners = next;
        _dirty = false;
      });
      _toast('活動海報已儲存');
    } catch (error) {
      _toast('儲存失敗：$error');
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  void _toast(String message) {
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F4F0),
      appBar: AppBar(title: const Text('活動海報管理')),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                if (constraints.maxWidth >= 1100) {
                  return _desktopStudio();
                }
                return _narrowStudio();
              },
            ),
    );
  }

  Widget _desktopStudio() {
    return Row(
      children: <Widget>[
        Expanded(flex: 42, child: _previewColumn(showSizeChips: true)),
        const VerticalDivider(width: 1),
        Expanded(
          flex: 58,
          child: Column(
            children: <Widget>[
              Expanded(child: _editorColumn()),
              _saveBar(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _narrowStudio() {
    return Column(
      children: <Widget>[
        SizedBox(height: 280, child: _previewColumn(showSizeChips: false)),
        const Divider(height: 1),
        Expanded(child: _editorColumn()),
        _saveBar(),
      ],
    );
  }

  Widget _previewColumn({required bool showSizeChips}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (showSizeChips)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: _previewSizeChips(),
          ),
        Expanded(child: _livePreview()),
      ],
    );
  }

  Widget _editorColumn() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      children: <Widget>[
        const Text(
          '活動海報',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 8),
        if (_banners.isEmpty)
          const Text('尚未新增海報')
        else
          ReorderableListView(
            buildDefaultDragHandles: false,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            onReorder: _onReorder,
            children: List<Widget>.generate(_banners.length, (int index) {
              final StoreBannerModel banner = _banners[index];
              return ListTile(
                key: ValueKey<String>(banner.id),
                selected: index == _selectedIndex,
                leading: ReorderableDragStartListener(
                  index: index,
                  child: const Icon(Icons.drag_handle),
                ),
                title: Text('海報 ${index + 1}'),
                subtitle: Text(banner.enabled ? '啟用' : '停用'),
                onTap: () => setState(() => _selectedIndex = index),
              );
            }),
          ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _busy ? null : _addBanner,
          icon: const Icon(Icons.add),
          label: const Text('新增海報'),
        ),
        const SizedBox(height: 12),
        HomeBannerEditorPanel(
          shopId: widget.shopId,
          draft: _draft,
          busy: _busy,
          uploading: _uploading,
          onChanged: _replaceSelected,
          onPickImage: _pickImage,
          onRemoveImage: _removeImage,
          onDelete: _deleteBanner,
        ),
      ],
    );
  }

  Widget _saveBar() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton(
          onPressed: _busy || !_dirty ? null : _save,
          child: Text(_busy ? '儲存中...' : '儲存變更'),
        ),
      ),
    );
  }

  Widget _previewSizeChips() {
    return Wrap(
      spacing: 8,
      children: BannerPreviewSize.values.map((BannerPreviewSize size) {
        final String label = switch (size) {
          BannerPreviewSize.phone => '手機',
          BannerPreviewSize.tablet => '平板',
          BannerPreviewSize.desktop => '電腦',
        };
        return ChoiceChip(
          label: Text(label),
          selected: _previewSize == size,
          onSelected: (_) => setState(() => _previewSize = size),
        );
      }).toList(),
    );
  }

  Widget _livePreview() {
    final StoreBannerModel? banner = _draft;
    if (banner == null) {
      return const Center(child: Text('尚未新增海報'));
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: ShopBannerDevicePreview(
        banner: banner,
        theme: _theme,
        size: _previewSize,
      ),
    );
  }
}
