// 檔案名稱：lib/features/shop/pages/inventory/shop_inventory_detail_page.dart
// 功能說明：庫存品項詳情。總覽、連動用途、進貨紀錄、異動流水、設定分開。
// 📦 庫存品項詳情頁

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:petnest_saas/core/constants/shop_permission_keys.dart';
import 'package:petnest_saas/core/models/inventory_item_model.dart';
import 'package:petnest_saas/core/services/inventory_linkage_service.dart';
import 'package:petnest_saas/core/services/inventory_service.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/features/shop/pages/inventory/shop_inventory_form_page.dart';
import 'package:petnest_saas/features/shop/widgets/inventory/inventory_batches_tab.dart';
import 'package:petnest_saas/features/shop/widgets/inventory/inventory_linkages_tab.dart';
import 'package:petnest_saas/features/shop/widgets/inventory/inventory_movements_tab.dart';
import 'package:petnest_saas/features/shop/widgets/inventory/inventory_overview_tab.dart';
import 'package:petnest_saas/features/shop/widgets/inventory/inventory_settings_tab.dart';

class ShopInventoryDetailPage extends StatefulWidget {
  const ShopInventoryDetailPage({
    super.key,
    required this.shopId,
    required this.itemId,
    this.memberData,
  });

  final String shopId;
  final String itemId;
  final Map<String, dynamic>? memberData;

  @override
  State<ShopInventoryDetailPage> createState() =>
      _ShopInventoryDetailPageState();
}

class _ShopInventoryDetailPageState extends State<ShopInventoryDetailPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  StreamSubscription<InventoryLinkageSnapshot>? _linkSubscription;
  InventoryLinkageSnapshot _linkages = const InventoryLinkageSnapshot.pending();

  bool _can(String key) {
    return ShopService.instance.hasPermission(widget.memberData, key);
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _linkSubscription = InventoryLinkageService.instance
        .watchShop(widget.shopId)
        .listen(
          (InventoryLinkageSnapshot snapshot) {
            if (!mounted) {
              return;
            }
            setState(() => _linkages = snapshot);
          },
          onError: (Object _) {
            if (!mounted) {
              return;
            }
            setState(() {
              _linkages = const InventoryLinkageSnapshot(
                ready: true,
                hasError: true,
                byItemId: <String, List<InventoryLinkage>>{},
              );
            });
          },
        );
  }

  @override
  void dispose() {
    _linkSubscription?.cancel();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool canManage = _can(ShopPermissionKeys.manageInventory);
    final bool canReceive =
        _can(ShopPermissionKeys.receiveInventory) || canManage;
    final bool canAdjust =
        _can(ShopPermissionKeys.adjustInventory) || canManage;
    final bool canViewCost = _can(ShopPermissionKeys.viewInventoryCost);
    final double pageWidth = MediaQuery.sizeOf(context).width;
    final bool scrollTabs = pageWidth < 900;

    return StreamBuilder<InventoryItemModel?>(
      stream: InventoryService.instance.streamItem(
        shopId: widget.shopId,
        itemId: widget.itemId,
      ),
      builder:
          (BuildContext context, AsyncSnapshot<InventoryItemModel?> snapshot) {
            final InventoryItemModel? item = snapshot.data;

            return Scaffold(
              backgroundColor: const Color(0xFFF6F8FB),
              appBar: AppBar(
                title: Text(item?.name ?? '庫存詳情'),
                actions: <Widget>[
                  if (canManage && item != null)
                    IconButton(
                      icon: const Icon(Icons.edit_outlined),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute<void>(
                            builder: (BuildContext context) {
                              return ShopInventoryFormPage(
                                shopId: widget.shopId,
                                item: item,
                              );
                            },
                          ),
                        );
                      },
                    ),
                ],
                bottom: TabBar(
                  controller: _tabController,
                  isScrollable: scrollTabs,
                  tabAlignment: scrollTabs
                      ? TabAlignment.start
                      : TabAlignment.fill,
                  labelPadding: const EdgeInsets.symmetric(horizontal: 12),
                  labelStyle: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                  unselectedLabelStyle: const TextStyle(fontSize: 13),
                  tabs: const <Widget>[
                    Tab(text: '總覽'),
                    Tab(text: '連動用途'),
                    Tab(text: '進貨紀錄'),
                    Tab(text: '異動流水'),
                    Tab(text: '設定'),
                  ],
                ),
              ),
              body: item == null
                  ? Center(
                      child: snapshot.hasError
                          ? const Text('暫時無法讀取此庫存品項')
                          : const CircularProgressIndicator(),
                    )
                  : TabBarView(
                      controller: _tabController,
                      children: <Widget>[
                        InventoryOverviewTab(
                          shopId: widget.shopId,
                          item: item,
                          canReceive: canReceive,
                          canAdjust: canAdjust,
                          canViewCost: canViewCost,
                          linkages: _linkages,
                          onViewLinkages: () => _tabController.animateTo(1),
                          onViewAllMovements: () => _tabController.animateTo(3),
                        ),
                        InventoryLinkagesTab(item: item, snapshot: _linkages),
                        InventoryBatchesTab(
                          shopId: widget.shopId,
                          item: item,
                          canViewCost: canViewCost,
                        ),
                        InventoryMovementsTab(
                          shopId: widget.shopId,
                          item: item,
                        ),
                        InventorySettingsTab(
                          shopId: widget.shopId,
                          item: item,
                          canManage: canManage,
                        ),
                      ],
                    ),
            );
          },
    );
  }
}
