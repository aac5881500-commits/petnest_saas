// 檔案名稱：lib/features/shop/pages/shop_theme_setting_page.dart
// 功能說明：設定首頁版型、主題顏色、卡片與圖示樣式
// 🎨 店家前台外觀設定頁

import 'dart:async';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:petnest_saas/core/models/home_about_section_setting.dart';
import 'package:petnest_saas/core/models/home_display_style.dart';
import 'package:petnest_saas/core/models/home_appearance_preset.dart';
import 'package:petnest_saas/core/models/home_information_sections_setting.dart';
import 'package:petnest_saas/core/models/daycare_settings_model.dart';
import 'package:petnest_saas/core/models/home_news_section_setting.dart';
import 'package:petnest_saas/core/models/home_quick_action_setting.dart';
import 'package:petnest_saas/core/models/home_shortcut_gate.dart';
import 'package:petnest_saas/core/models/home_quick_booking_section_setting.dart';
import 'package:petnest_saas/core/models/home_environment_section_setting.dart';
import 'package:petnest_saas/core/models/home_room_section_setting.dart';
import 'package:petnest_saas/core/models/home_shared_entry_section_setting.dart';
import 'package:petnest_saas/core/models/home_text_style_model.dart';
import 'package:petnest_saas/core/models/home_theme_model.dart';
import 'package:petnest_saas/core/models/modern_banner_frame_setting.dart';
import 'package:petnest_saas/core/models/modern_store_home_setting.dart';
import 'package:petnest_saas/core/services/daycare_settings_service.dart';
import 'package:petnest_saas/core/services/home_banner_service.dart';
import 'package:petnest_saas/core/services/storefront_access.dart';
import 'package:petnest_saas/core/services/shop_chat_service.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/features/shop/pages/shop_announcement_manage_page.dart';
import 'package:petnest_saas/features/shop/pages/shop_faq_manage_page.dart';
import 'package:petnest_saas/features/shop/pages/shop_media_page.dart';
import 'package:petnest_saas/features/shop/pages/store/shop_store_settings_page.dart';
import 'package:petnest_saas/features/shop/pages/shop_room_type_page.dart';
import 'package:petnest_saas/features/shop/navigation/frontend_navigation_models.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/frontend_navigation_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/home_banner_display_settings.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/home_color_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/modern_home_editor_preview.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_settings_card.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/store_brand_style.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/home_quick_action_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/home_section_order.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/about_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/home_appearance_preset_strip.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/appearance_category_bar.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/modern_home_appearance_tabs.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/faq_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/policy_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/review_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/news_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/quick_booking_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/environment_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/room_section_settings_panel.dart';
import 'package:petnest_saas/features/shop/widgets/modern_home/shared_entry_settings_card.dart';

class ShopThemeSettingPage extends StatefulWidget {
  const ShopThemeSettingPage({super.key, required this.shopId});

  final String shopId;

  @override
  State<ShopThemeSettingPage> createState() => _ShopThemeSettingPageState();
}

class _ShopThemeSettingPageState extends State<ShopThemeSettingPage>
    with SingleTickerProviderStateMixin {
  final ImagePicker _imagePicker = ImagePicker();

  String _modernLogoUrl = '';
  Uint8List? _modernLogoPreviewBytes;
  bool _isUploadingModernLogo = false;
  final TextEditingController _modernHeaderSubtitleController =
      TextEditingController();
  final TextEditingController _modernBannerTitleController =
      TextEditingController();
  final TextEditingController _modernBannerSubtitleController =
      TextEditingController();

  final TextEditingController _modernBannerButtonTextController =
      TextEditingController();
  final TextEditingController _featuredStoreTitleController =
      TextEditingController(text: ModernStoreHomeSetting.defaultFeaturedTitle);
  final TextEditingController _storeBannerTitleController =
      TextEditingController(text: ModernStoreHomeSetting.defaultBannerTitle);
  final TextEditingController _storeBannerSubtitleController =
      TextEditingController(text: ModernStoreHomeSetting.defaultBannerSubtitle);
  final TextEditingController _storeBannerButtonTextController =
      TextEditingController(
        text: ModernStoreHomeSetting.defaultBannerButtonText,
      );
  bool _showFeaturedStoreProducts = true;
  bool _showStoreBanner = true;
  String _storeCardBackgroundFit = ModernStoreCardFits.cover;
  String _storeCardBackgroundAlignment = ModernStoreCardAlignments.center;
  String _storeCardOverlayPreset = ModernStoreCardOverlays.none;
  String _storeCardOverlayTone = ModernStoreCardOverlayTones.dark;
  String _storeCardTitleColorPreset = ModernStoreCardTextColors.dark;
  String _storeCardSubtitleColorPreset = ModernStoreCardTextColors.dark;
  String _storeCardButtonColorPreset = ModernStoreCardButtonColors.brand;
  String _storeCardContentPosition = ModernStoreCardPositions.centerLeft;
  String _featuredProductLayout = ModernFeaturedProductLayouts.horizontal;
  String _storeEntryLayout = ModernStoreEntryLayouts.banner;
  String _loadedFeaturedProductLayout = ModernFeaturedProductLayouts.horizontal;
  String _loadedStoreEntryLayout = ModernStoreEntryLayouts.banner;
  String _committedStoreCardImageUrl = '';
  String _committedStoreCardImagePath = '';
  String _selectedLayout = 'classic';
  String _selectedTheme = 'warmOrange';
  String _selectedBackground = 'warmWhite';
  String _selectedCardStyle = 'standard';
  String _selectedIconStyle = 'circle';
  String _selectedDensity = 'comfortable';
  StoreBrandStyle _brandStyle = const StoreBrandStyle();
  List<String> _homeSectionOrder = HomeSectionOrder.normalize(null);
  HomeRoomSectionSetting _roomSection = const HomeRoomSectionSetting();
  HomeSharedEntrySectionSetting _sharedEntrySection =
      const HomeSharedEntrySectionSetting();
  HomeDisplayStyleSetting _displayStyle = HomeDisplayStyleSetting.unset;
  HomeEnvironmentSectionSetting _environmentSection =
      const HomeEnvironmentSectionSetting();
  HomeAboutSectionSetting _aboutSection = const HomeAboutSectionSetting();
  HomeNewsSectionSetting _newsSection = const HomeNewsSectionSetting();
  HomeQuickBookingSectionSetting _quickBookingSection =
      const HomeQuickBookingSectionSetting();
  HomeInformationSectionsSetting _informationSections =
      const HomeInformationSectionsSetting();
  HomeQuickActionSetting _quickActions = const HomeQuickActionSetting();
  int _environmentFocusToken = 0;
  int _aboutFocusToken = 0;
  int _newsFocusToken = 0;
  int _quickBookingFocusToken = 0;
  StreamSubscription<DaycareSettingsModel>? _daycareSettingsSub;
  DaycareSettingsModel? _daycareSettings;
  int _policyFocusToken = 0;
  int _faqFocusToken = 0;
  int _reviewFocusToken = 0;
  final GlobalKey _appearanceTabBarKey = GlobalKey();
  String? _selectedRoomTypeId;
  int _roomFocusToken = 0;
  HomeTextStyleModel _modernBannerTitleStyle = const HomeTextStyleModel(
    fontSize: 22,
    colorValue: 0xFFFFFFFF,
    isBold: true,
    hasShadow: true,
    alignment: 'left',
  );

  HomeTextStyleModel _modernBannerSubtitleStyle = const HomeTextStyleModel(
    fontSize: 13,
    colorValue: 0xFFFFFFFF,
    isBold: true,
    hasShadow: true,
    alignment: 'left',
  );
  HomeThemeModel _modernTheme = const HomeThemeModel(
    backgroundColorValue: 0xFFFFFBF7,
    cardColorValue: 0xFFFFFFFF,
    cardBorderColorValue: 0xFFFFD9B3,
    primaryColorValue: 0xFFFF8A00,
    textColorValue: 0xFF3A2A20,
  );

  int _modernBannerButtonColorValue = 0xFFFF7A1A;
  int _modernBannerButtonTextColorValue = 0xFFFFFFFF;
  ModernBannerFrameSetting _modernBannerFrame =
      const ModernBannerFrameSetting();
  int _enabledHomeBannerCount = 0;
  late final TabController _tabController;
  final Map<String, Map<String, String>> _layoutSettings = {
    'classic': {
      'theme': 'warmOrange',
      'background': 'warmWhite',
      'cardStyle': 'standard',
      'iconStyle': 'circle',
      'density': 'comfortable',
    },
    'modern': {
      'theme': 'warmOrange',
      'background': 'warmWhite',
      'cardStyle': 'standard',
      'iconStyle': 'circle',
      'density': 'comfortable',
    },
  };

  bool _isSaving = false;
  bool _isLoading = true;
  bool _appearanceDirty = false;
  String? _appearancePresetId;
  String? _browsingPresetId;
  bool _showStayServiceStrip = true;
  Map<String, dynamic> _loadedShop = <String, dynamic>{};
  FrontendNavigationConfig _navigationConfig =
      FrontendNavigationConfig.defaults();
  FrontendNavigationConfig _savedNavigation =
      FrontendNavigationConfig.defaults();
  final ScrollController _appearanceScroll = ScrollController();
  final List<ScrollController> _appearanceCategoryScrolls =
      List<ScrollController>.generate(
        AppearanceCategories.length,
        (_) => ScrollController(),
      );
  int _appearanceCategory = AppearanceCategories.brand;
  final ScrollController _navigationScroll = ScrollController();
  HomeThemeModel _colorEntryTheme = HomeThemeModel.modernDefault;
  String? _selectedHomeSection;
  int _homeCanvasPane = 0;
  final GlobalKey _headerSettingsKey = GlobalKey();
  final GlobalKey _bannerSettingsKey = GlobalKey();
  final GlobalKey _sharedEntrySettingsKey = GlobalKey();
  final GlobalKey _storeSettingsKey = GlobalKey();
  final GlobalKey _pendingSettingsKey = GlobalKey();
  // ========================
  // 快速聯絡按鈕
  // ========================

  bool _floatingButtonEnabled = false;
  String _floatingButtonSize = 'medium';
  String _floatingButtonType = ShopChatService.floatingTypePetnestChat;
  bool _chatProvisioned = false;
  String _shopPhone = '';
  String _shopLineUrl = '';
  String _shopFacebookUrl = '';
  String _shopInstagramUrl = '';

  final TextEditingController _floatingButtonLabelController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: ModernHomeAppearanceTabs.length,
      vsync: this,
    );
    _tabController.addListener(_onTabChanged);
    _bindModernDraftListeners();
    _daycareSettingsSub = DaycareSettingsService.instance
        .stream(widget.shopId)
        .listen((DaycareSettingsModel settings) {
          if (!mounted) {
            return;
          }
          setState(() => _daycareSettings = settings);
        }, onError: (Object _) {});
    _loadSettings();
  }

  void _onTabChanged() {
    if (_tabController.indexIsChanging || !mounted) {
      return;
    }
    setState(() {
      if (_tabController.index == ModernHomeAppearanceTabs.rooms &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'rooms';
        _roomFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.facilities &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'facilities';
        _environmentFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.about &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'about';
        _aboutFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.news &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'announcements';
        _newsFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.quickBooking &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'quickBooking';
        _quickBookingFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.policy &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'policy';
        _policyFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.faq &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'faq';
        _faqFocusToken++;
      }
      if (_tabController.index == ModernHomeAppearanceTabs.reviews &&
          _selectedLayout == 'modern') {
        _selectedHomeSection = 'reviews';
        _reviewFocusToken++;
      }
    });
  }

  void _bindModernDraftListeners() {
    for (final TextEditingController controller in <TextEditingController>[
      _modernHeaderSubtitleController,
      _modernBannerTitleController,
      _modernBannerSubtitleController,
      _modernBannerButtonTextController,
      _featuredStoreTitleController,
      _storeBannerTitleController,
      _storeBannerSubtitleController,
      _storeBannerButtonTextController,
    ]) {
      controller.addListener(_onModernDraftChanged);
    }
  }

  void _onModernDraftChanged() {
    if (!mounted || _isLoading || _selectedLayout != 'modern') {
      return;
    }
    _appearanceDirty = true;
    setState(() {});
  }

  @override
  void dispose() {
    _daycareSettingsSub?.cancel();
    _tabController.removeListener(_onTabChanged);
    _tabController.dispose();
    for (final TextEditingController controller in <TextEditingController>[
      _modernHeaderSubtitleController,
      _modernBannerTitleController,
      _modernBannerSubtitleController,
      _modernBannerButtonTextController,
      _featuredStoreTitleController,
      _storeBannerTitleController,
      _storeBannerSubtitleController,
      _storeBannerButtonTextController,
    ]) {
      controller.removeListener(_onModernDraftChanged);
    }
    _modernHeaderSubtitleController.dispose();
    _modernBannerTitleController.dispose();
    _modernBannerSubtitleController.dispose();
    _modernBannerButtonTextController.dispose();
    _featuredStoreTitleController.dispose();
    _storeBannerTitleController.dispose();
    _storeBannerSubtitleController.dispose();
    _storeBannerButtonTextController.dispose();
    _floatingButtonLabelController.dispose();
    _appearanceScroll.dispose();
    for (final ScrollController controller in _appearanceCategoryScrolls) {
      controller.dispose();
    }
    _navigationScroll.dispose();
    super.dispose();
  }

  void _applySharedSection(HomeSharedEntrySectionSetting value) {
    setState(() {
      _sharedEntrySection = value;
      final String placement = value.isJoined(HomeSharedEntrySources.rooms)
          ? HomeRoomSimplePlacements.shared
          : HomeRoomSimplePlacements.independent;
      if (_roomSection.simple.placement != placement) {
        _roomSection = _roomSection.copyWith(
          simple: _roomSection.simple.copyWith(placement: placement),
        );
      }
      _appearanceDirty = true;
    });
  }

  Widget _sharedJoin(String sourceId) {
    return SharedEntryJoinSwitch(
      joined: _sharedEntryForDraft.isJoined(sourceId),
      zoneEnabled: _sharedEntrySection.enabled,
      onChanged: (bool join) {
        HomeSharedEntryCardSetting? seed;
        if (join &&
            sourceId == HomeSharedEntrySources.rooms &&
            !_sharedEntrySection.cards.containsKey(sourceId)) {
          final String title = _roomSection.title.trim();
          seed = HomeSharedEntryCardSetting.fallback(sourceId).copyWith(
            title: title.isEmpty ? null : title,
            subtitle: _roomSection.simple.subtitle,
            showSubtitle: _roomSection.simple.showSubtitle,
          );
        }
        _applySharedSection(
          join
              ? _sharedEntrySection.including(sourceId, when: true, seed: seed)
              : _sharedEntrySection.without(sourceId),
        );
      },
    );
  }

  Widget _withSharedJoin(String sourceId, Widget settings) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _sharedJoin(sourceId),
        Expanded(child: settings),
      ],
    );
  }

  HomeSharedEntrySectionSetting get _sharedEntryForDraft {
    return _sharedEntrySection.including(
      HomeSharedEntrySources.rooms,
      when: roomSimpleUsesSharedZone(_roomSection),
    );
  }

  Map<String, dynamic> get _draftModernAppearance {
    return <String, dynamic>{
      ...Map<String, String>.from(_layoutSettings['modern']!),
      'headerSubtitle': StoreBrandTextPolicy.sanitizeSubtitle(
        _modernHeaderSubtitleController.text,
      ),
      'bannerTitle': _modernBannerTitleController.text.trim(),
      'bannerSubtitle': _modernBannerSubtitleController.text.trim(),
      'bannerTitleStyle': _modernBannerTitleStyle.toMap(),
      'bannerSubtitleStyle': _modernBannerSubtitleStyle.toMap(),
      'bannerButtonText': _modernBannerButtonTextController.text.trim(),
      'bannerButtonColor': _modernBannerButtonColorValue,
      'bannerButtonTextColor': _modernBannerButtonTextColorValue,
      ..._modernBannerFrame.toMap(),
      'themeColors': _modernTheme.toMap(),
      ..._brandStyle.toMap(),
      'homeSectionOrder': _homeSectionOrder,
      'roomSection': _roomSection.toMap(),
      HomeSharedEntrySectionSetting.mapKey: _sharedEntryForDraft.toMap(),
      if (_displayStyle.saved)
        HomeDisplayStyleSetting.mapKey: _displayStyle.toMap(),
      'environmentSection': _environmentSection.toMap(),
      'aboutSection': _aboutSection.toMap(),
      'newsSection': _newsSection.toMap(),
      'quickBookingSection': _quickBookingSection.toMap(),
      'informationSections': _informationSections.toMap(),
      homeAppearancePresetIdKey: ?_appearancePresetId,
      'showStayServiceStrip': _showStayServiceStrip,
      HomeQuickActionSetting.mapKey: _quickActions.toMap(),
      ..._draftStoreHomeSetting.toMap(),
      ..._navigationConfig.toMap(),
    };
  }

  String get _bannerStatusText {
    final String mode = _modernBannerFrame.isActivity ? '活動滑動海報' : '經典完整海報';
    return '已啟用・$_enabledHomeBannerCount 張海報・$mode';
  }

  ModernStoreHomeSetting get _draftStoreHomeSetting {
    final String imageUrl = _committedStoreCardImageUrl;
    final String imagePath = _committedStoreCardImagePath;
    return ModernStoreHomeSetting(
      showFeaturedProducts: _showFeaturedStoreProducts,
      featuredTitle: _featuredStoreTitleController.text.trim(),
      featuredProductLayout: _featuredProductLayout,
      showStoreBanner: _showStoreBanner,
      storeBannerTitle: _storeBannerTitleController.text.trim(),
      storeBannerSubtitle: _storeBannerSubtitleController.text.trim(),
      storeBannerButtonText: _storeBannerButtonTextController.text.trim(),
      storeBannerImageUrl: imageUrl,
      storeBannerImageStoragePath: imagePath,
      storeBannerBackgroundFit: _storeCardBackgroundFit,
      storeBannerBackgroundAlignment: _storeCardBackgroundAlignment,
      storeBannerOverlayPreset: _storeCardOverlayPreset,
      storeBannerOverlayTone: _storeCardOverlayTone,
      storeBannerTitleColorPreset: _storeCardTitleColorPreset,
      storeBannerSubtitleColorPreset: _storeCardSubtitleColorPreset,
      storeBannerButtonColorPreset: _storeCardButtonColorPreset,
      storeBannerContentPosition: _storeCardContentPosition,
      storeEntryLayout: _storeEntryLayout,
    );
  }

  void _adoptStoreHome(ModernStoreHomeSetting setting) {
    _showFeaturedStoreProducts = setting.showFeaturedProducts;
    _featuredStoreTitleController.text = setting.featuredTitle;
    _showStoreBanner = setting.showStoreBanner;
    _storeBannerTitleController.text = setting.storeBannerTitle;
    _storeBannerSubtitleController.text = setting.storeBannerSubtitle;
    _storeBannerButtonTextController.text = setting.storeBannerButtonText;
    _storeCardBackgroundFit = setting.storeBannerBackgroundFit;
    _storeCardBackgroundAlignment = setting.storeBannerBackgroundAlignment;
    _storeCardOverlayPreset = setting.storeBannerOverlayPreset;
    _storeCardOverlayTone = setting.storeBannerOverlayTone;
    _storeCardTitleColorPreset = setting.storeBannerTitleColorPreset;
    _storeCardSubtitleColorPreset = setting.storeBannerSubtitleColorPreset;
    _storeCardButtonColorPreset = setting.storeBannerButtonColorPreset;
    _storeCardContentPosition = setting.storeBannerContentPosition;
    _featuredProductLayout = setting.featuredProductLayout;
    _storeEntryLayout = setting.storeEntryLayout;
    _loadedFeaturedProductLayout = setting.featuredProductLayout;
    _loadedStoreEntryLayout = setting.storeEntryLayout;
    _committedStoreCardImageUrl = setting.storeBannerImageUrl;
    _committedStoreCardImagePath = setting.storeBannerImageStoragePath;
  }

  Future<ModernStoreHomeSetting> _storeHomeSettingForSave() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('shops')
        .doc(widget.shopId)
        .get();
    final Object? rawAppearance = snapshot.data()?['homeAppearance'];
    final Map<String, dynamic> appearance = rawAppearance is Map
        ? Map<String, dynamic>.from(rawAppearance)
        : <String, dynamic>{};
    final Object? rawModern = appearance['modern'];
    final Map<String, dynamic> modern = rawModern is Map
        ? Map<String, dynamic>.from(rawModern)
        : <String, dynamic>{};
    final ModernStoreHomeSetting latest = ModernStoreHomeSetting.fromMap(
      modern,
    );
    return latest.copyWith(
      featuredProductLayout:
          _featuredProductLayout == _loadedFeaturedProductLayout
          ? null
          : _featuredProductLayout,
      storeEntryLayout: _storeEntryLayout == _loadedStoreEntryLayout
          ? null
          : _storeEntryLayout,
    );
  }

  Future<void> _loadSettings() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('shops')
          .doc(widget.shopId)
          .get();

      final shopData = snapshot.data();

      _shopPhone = (shopData?['phone'] ?? '').toString().trim();
      _shopLineUrl = (shopData?['lineUrl'] ?? '').toString().trim();
      _shopFacebookUrl = (shopData?['fbUrl'] ?? '').toString().trim();
      _shopInstagramUrl = (shopData?['igUrl'] ?? '').toString().trim();

      final rawFloatingButton = shopData?['floatingContactButton'];

      if (rawFloatingButton is Map) {
        final floatingButton = Map<String, dynamic>.from(rawFloatingButton);

        _floatingButtonEnabled = floatingButton['enabled'] == true;
        final String loadedType = (floatingButton['type'] ?? '')
            .toString()
            .trim();
        _floatingButtonType = loadedType.isEmpty
            ? ShopChatService.floatingTypePetnestChat
            : loadedType;

        final loadedSize = (floatingButton['size'] ?? 'medium').toString();

        _floatingButtonSize =
            const ['small', 'medium', 'large'].contains(loadedSize)
            ? loadedSize
            : 'medium';

        _floatingButtonLabelController.text = (floatingButton['label'] ?? '')
            .toString();
        _chatProvisioned =
            shopData?['storeChatEnabled'] == true ||
            loadedType == ShopChatService.floatingTypePetnestChat;
      }
      if (shopData?['storeChatEnabled'] == true) {
        _chatProvisioned = true;
      }

      _modernLogoUrl = (shopData?['logoUrl'] ?? '').toString().trim();
      _enabledHomeBannerCount = shopData == null
          ? 0
          : HomeBannerService.instance
                .parseEnabledFrontBanners(Map<String, dynamic>.from(shopData))
                .length;

      final rawAppearance = shopData?['homeAppearance'];

      if (rawAppearance is Map) {
        final appearance = Map<String, dynamic>.from(rawAppearance);

        _selectedLayout = (appearance['layout'] ?? 'classic').toString();

        if (_selectedLayout != 'classic' && _selectedLayout != 'modern') {
          _selectedLayout = 'classic';
        }

        final legacySettings = <String, String>{
          'theme': (appearance['theme'] ?? 'warmOrange').toString(),
          'background': (appearance['background'] ?? 'warmWhite').toString(),
          'cardStyle': (appearance['cardStyle'] ?? 'standard').toString(),
          'iconStyle': (appearance['iconStyle'] ?? 'circle').toString(),
          'density': (appearance['density'] ?? 'comfortable').toString(),
        };

        for (final layout in ['classic', 'modern']) {
          final rawLayoutSettings = appearance[layout];

          final layoutData = rawLayoutSettings is Map
              ? Map<String, dynamic>.from(rawLayoutSettings)
              : <String, dynamic>{};

          _layoutSettings[layout] = {
            'theme': (layoutData['theme'] ?? legacySettings['theme']!)
                .toString(),
            'background':
                (layoutData['background'] ?? legacySettings['background']!)
                    .toString(),
            'cardStyle':
                (layoutData['cardStyle'] ?? legacySettings['cardStyle']!)
                    .toString(),
            'iconStyle':
                (layoutData['iconStyle'] ?? legacySettings['iconStyle']!)
                    .toString(),
            'density': (layoutData['density'] ?? legacySettings['density']!)
                .toString(),
          };
        }

        _applySelectedLayoutSettings();
        final rawModernAppearance = appearance['modern'];

        final modernAppearance = rawModernAppearance is Map
            ? Map<String, dynamic>.from(rawModernAppearance)
            : <String, dynamic>{};
        _modernTheme = HomeThemeModel.fromMap(
          modernAppearance['themeColors'],
          fallback: HomeThemeModel.modernDefault,
        );
        _colorEntryTheme = _modernTheme;

        _modernHeaderSubtitleController.text =
            StoreBrandTextPolicy.sanitizeSubtitle(
              (modernAppearance['headerSubtitle'] ?? '讓每一隻貓咪都有溫暖的家').toString(),
            );
        _modernBannerTitleController.text =
            (modernAppearance['bannerTitle'] ?? '安心住宿').toString();
        _modernBannerSubtitleController.text =
            (modernAppearance['bannerSubtitle'] ?? '毛孩的第二個家').toString();

        _modernBannerButtonTextController.text =
            (modernAppearance['bannerButtonText'] ?? '立即預約住宿').toString();

        _modernBannerTitleStyle = HomeTextStyleModel.fromMap(
          modernAppearance['bannerTitleStyle'],
          fallback: const HomeTextStyleModel(
            fontSize: 22,
            colorValue: 0xFFFFFFFF,
            isBold: true,
            hasShadow: true,
            alignment: 'left',
          ),
        );

        _modernBannerSubtitleStyle = HomeTextStyleModel.fromMap(
          modernAppearance['bannerSubtitleStyle'],
          fallback: const HomeTextStyleModel(
            fontSize: 13,
            colorValue: 0xFFFFFFFF,
            isBold: true,
            hasShadow: true,
            alignment: 'left',
          ),
        );

        final rawButtonColor = modernAppearance['bannerButtonColor'];
        _modernBannerButtonColorValue = rawButtonColor is num
            ? rawButtonColor.toInt()
            : 0xFFFF7A1A;

        final rawButtonTextColor = modernAppearance['bannerButtonTextColor'];

        _modernBannerButtonTextColorValue = rawButtonTextColor is num
            ? rawButtonTextColor.toInt()
            : 0xFFFFFFFF;
        _modernBannerFrame = ModernBannerFrameSetting.fromMap(modernAppearance);
        _homeSectionOrder = HomeSectionOrder.normalize(
          modernAppearance['homeSectionOrder'],
        );
        _roomSection = HomeRoomSectionSetting.fromMap(
          modernAppearance['roomSection'],
        );
        _sharedEntrySection = HomeSharedEntrySectionSetting.fromMap(
          modernAppearance[HomeSharedEntrySectionSetting.mapKey],
        );
        _displayStyle = HomeDisplayStyleSetting.fromMap(
          modernAppearance[HomeDisplayStyleSetting.mapKey],
        );
        _environmentSection = HomeEnvironmentSectionSetting.fromMap(
          modernAppearance['environmentSection'],
        );
        _aboutSection = HomeAboutSectionSetting.fromMap(
          modernAppearance['aboutSection'],
        );
        _newsSection = HomeNewsSectionSetting.fromMap(
          modernAppearance['newsSection'],
        );
        _quickBookingSection = HomeQuickBookingSectionSetting.fromMap(
          modernAppearance['quickBookingSection'],
        );
        _informationSections = HomeInformationSectionsSetting.fromMap(
          modernAppearance['informationSections'],
        );
        _quickActions = HomeQuickActionSetting.fromMap(
          modernAppearance[HomeQuickActionSetting.mapKey],
        );
        _appearancePresetId = homeAppearancePresetById(
          modernAppearance[homeAppearancePresetIdKey]?.toString(),
        )?.id;
        _browsingPresetId = null;
        _showStayServiceStrip =
            modernAppearance['showStayServiceStrip'] != false;
        _brandStyle = StoreBrandStyle.fromMap(
          modernAppearance,
          logoUrl: _modernLogoUrl,
        );

        final storeHomeSetting = ModernStoreHomeSetting.fromMap(
          modernAppearance,
        );
        _showFeaturedStoreProducts = storeHomeSetting.showFeaturedProducts;
        _featuredStoreTitleController.text = storeHomeSetting.featuredTitle;
        _showStoreBanner = storeHomeSetting.showStoreBanner;
        _storeBannerTitleController.text = storeHomeSetting.storeBannerTitle;
        _storeBannerSubtitleController.text =
            storeHomeSetting.storeBannerSubtitle;
        _storeBannerButtonTextController.text =
            storeHomeSetting.storeBannerButtonText;
        _storeCardBackgroundFit = storeHomeSetting.storeBannerBackgroundFit;
        _storeCardBackgroundAlignment =
            storeHomeSetting.storeBannerBackgroundAlignment;
        _storeCardOverlayPreset = storeHomeSetting.storeBannerOverlayPreset;
        _storeCardOverlayTone = storeHomeSetting.storeBannerOverlayTone;
        _storeCardTitleColorPreset =
            storeHomeSetting.storeBannerTitleColorPreset;
        _storeCardSubtitleColorPreset =
            storeHomeSetting.storeBannerSubtitleColorPreset;
        _storeCardButtonColorPreset =
            storeHomeSetting.storeBannerButtonColorPreset;
        _storeCardContentPosition = storeHomeSetting.storeBannerContentPosition;
        _featuredProductLayout = storeHomeSetting.featuredProductLayout;
        _storeEntryLayout = storeHomeSetting.storeEntryLayout;
        _loadedFeaturedProductLayout = storeHomeSetting.featuredProductLayout;
        _loadedStoreEntryLayout = storeHomeSetting.storeEntryLayout;
        _committedStoreCardImageUrl = storeHomeSetting.storeBannerImageUrl;
        _committedStoreCardImagePath =
            storeHomeSetting.storeBannerImageStoragePath;
        _loadedShop = shopData == null
            ? <String, dynamic>{}
            : Map<String, dynamic>.from(shopData);
        _navigationConfig = FrontendNavigationConfig.fromMap(modernAppearance);
        _savedNavigation = _navigationConfig;
        _appearanceDirty = false;
      }
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('讀取外觀設定失敗：$error')));
    } finally {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _pickAndUploadModernLogo() async {
    if (_isUploadingModernLogo) return;

    try {
      final XFile? pickedFile = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
        maxWidth: 1200,
      );

      if (pickedFile == null) return;

      final Uint8List bytes = await pickedFile.readAsBytes();

      if (!mounted) return;

      setState(() {
        _modernLogoPreviewBytes = bytes;
        _isUploadingModernLogo = true;
      });

      final String uploadedUrl = await ShopService.instance.uploadShopLogo(
        shopId: widget.shopId,
        bytes: bytes,
      );

      if (!mounted) return;

      setState(() {
        _modernLogoUrl = uploadedUrl;
        _modernLogoPreviewBytes = null;
        _isUploadingModernLogo = false;
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('新版首頁 Logo 已更新')));
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _modernLogoPreviewBytes = null;
        _isUploadingModernLogo = false;
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Logo 上傳失敗：$error')));
    }
  }

  void _storeSelectedLayoutSettings() {
    _layoutSettings[_selectedLayout] = {
      'theme': _selectedTheme,
      'background': _selectedBackground,
      'cardStyle': _selectedCardStyle,
      'iconStyle': _selectedIconStyle,
      'density': _selectedDensity,
    };
  }

  void _applySelectedLayoutSettings() {
    final settings = _layoutSettings[_selectedLayout];

    if (settings == null) return;

    _selectedTheme = settings['theme'] ?? 'warmOrange';
    _selectedBackground = settings['background'] ?? 'warmWhite';
    _selectedCardStyle = settings['cardStyle'] ?? 'standard';
    _selectedIconStyle = settings['iconStyle'] ?? 'circle';
    _selectedDensity = settings['density'] ?? 'comfortable';
  }

  void _changeLayout(String layout) {
    if (layout == _selectedLayout) return;

    setState(() {
      _storeSelectedLayoutSettings();
      _selectedLayout = layout;
      _applySelectedLayoutSettings();
    });
  }

  Future<void> _saveSettings() async {
    if (_isSaving) return;

    setState(() {
      _isSaving = true;
    });

    try {
      _storeSelectedLayoutSettings();
      final ModernStoreHomeSetting storeHomeForSave =
          await _storeHomeSettingForSave();

      await FirebaseFirestore.instance
          .collection('shops')
          .doc(widget.shopId)
          .set({
            'homeAppearance': {
              'layout': _selectedLayout,
              'classic': Map<String, String>.from(_layoutSettings['classic']!),
              'modern': {
                ...Map<String, String>.from(_layoutSettings['modern']!),
                'headerSubtitle': StoreBrandTextPolicy.sanitizeSubtitle(
                  _modernHeaderSubtitleController.text,
                ),

                'bannerTitle': _modernBannerTitleController.text.trim(),

                'bannerSubtitle': _modernBannerSubtitleController.text.trim(),

                'bannerTitleStyle': _modernBannerTitleStyle.toMap(),

                'bannerSubtitleStyle': _modernBannerSubtitleStyle.toMap(),

                'bannerButtonText': _modernBannerButtonTextController.text
                    .trim(),

                'bannerButtonColor': _modernBannerButtonColorValue,

                'bannerButtonTextColor': _modernBannerButtonTextColorValue,

                ..._modernBannerFrame.toMap(),

                'themeColors': _modernTheme.toMap(),

                ..._brandStyle.toMap(),
                'homeSectionOrder': _homeSectionOrder,
                'roomSection': _roomSection.toMap(),
                HomeSharedEntrySectionSetting.mapKey: _sharedEntryForDraft
                    .toMap(),
                if (_displayStyle.saved)
                  HomeDisplayStyleSetting.mapKey: _displayStyle.toMap(),
                'environmentSection': _environmentSection.toMap(),
                'aboutSection': _aboutSection.toMap(),
                'newsSection': _newsSection.toMap(),
                'quickBookingSection': _quickBookingSection.toMap(),
                'informationSections': _informationSections.toMap(),
                homeAppearancePresetIdKey: ?_appearancePresetId,
                'showStayServiceStrip': _showStayServiceStrip,
                HomeQuickActionSetting.mapKey: _quickActions.toMap(),

                ...storeHomeForSave.toMap(),
                ..._navigationConfig.toMap(),
              },
            },
            'floatingContactButton': {
              'enabled': _floatingButtonEnabled,
              'type': _floatingButtonType,
              'size': _floatingButtonSize,
              'label': _floatingButtonLabelController.text.trim(),
            },
            'storeChatEnabled':
                _chatProvisioned ||
                _floatingButtonType == ShopChatService.floatingTypePetnestChat,
          }, SetOptions(merge: true));

      _adoptStoreHome(storeHomeForSave);
      _savedNavigation = _navigationConfig;
      _appearanceDirty = false;

      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('前台外觀設定已儲存')));
    } on FirebaseException catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            error.code == 'permission-denied'
                ? '儲存失敗：Firestore 權限尚未開放'
                : '儲存失敗：${error.message ?? error.code}',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('儲存失敗：$error')));
    } finally {
      if (!mounted) return;

      setState(() {
        _isSaving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('前台外觀設定')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final bool desktopModern =
        MediaQuery.sizeOf(context).width >= 1100 && _selectedLayout == 'modern';
    final bool pinSaveOnEditor = desktopModern;
    return PopScope(
      canPop: !_hasUnsaved,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (didPop || !_hasUnsaved) {
          return;
        }
        _confirmLeave();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFFFCF7),
        appBar: AppBar(
          title: const Text('前台外觀設定'),
          backgroundColor: const Color(0xFFFFFCF7),
          surfaceTintColor: Colors.transparent,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(72),
            child: Listener(
              onPointerSignal: _onAppearanceTabSignal,
              child: TabBar(
                key: _appearanceTabBarKey,
                controller: _tabController,
                isScrollable: true,
                tabAlignment: TabAlignment.start,
                tabs: const [
                  Tab(icon: Icon(Icons.palette_outlined), text: '外觀設定'),
                  Tab(icon: Icon(Icons.bedroom_parent_outlined), text: '房型展示'),
                  Tab(icon: Icon(Icons.yard_outlined), text: '環境展示'),
                  Tab(icon: Icon(Icons.favorite_border), text: '關於我們'),
                  Tab(icon: Icon(Icons.campaign_outlined), text: '消息展示'),
                  Tab(icon: Icon(Icons.event_available_outlined), text: '快速預約'),
                  Tab(icon: Icon(Icons.description_outlined), text: '入住須知'),
                  Tab(icon: Icon(Icons.quiz_outlined), text: '常見問題'),
                  Tab(icon: Icon(Icons.star_outline), text: '顧客評價'),
                  Tab(icon: Icon(Icons.menu_rounded), text: '導覽設定'),
                ],
              ),
            ),
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            _buildAppearancePane(desktopModern),
            _buildRoomPane(desktopModern),
            _buildEnvironmentPane(desktopModern),
            _buildAboutPane(desktopModern),
            _buildNewsPane(desktopModern),
            _buildQuickBookingPane(desktopModern),
            _buildPolicyPane(desktopModern),
            _buildFaqPane(desktopModern),
            _buildReviewPane(desktopModern),
            _buildNavigationPane(desktopModern),
          ],
        ),
        bottomNavigationBar: pinSaveOnEditor ? null : _saveBar(),
      ),
    );
  }

  bool get _hasUnsaved {
    return _appearanceDirty || _navigationConfig != _savedNavigation;
  }

  Future<void> _confirmLeave() async {
    final bool? leave = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('尚未儲存'),
          content: const Text('導覽與外觀的修改尚未儲存，要放棄這些變更嗎？'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('繼續編輯'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('放棄變更'),
            ),
          ],
        );
      },
    );
    if (leave == true && mounted) {
      Navigator.of(context).pop();
    }
  }

  FrontendNavShopState get _navShopState {
    return FrontendNavShopState.fromShop(
      _loadedShop,
      showMemberCenter: _modernTheme.drawerSetting.showMemberCenter,
      showShopMenus: _modernTheme.drawerSetting.showShopMenus,
      loggedIn: true,
    );
  }

  void _replaceModernTheme(HomeThemeModel value) {
    setState(() {
      _modernTheme = value;
      _appearanceDirty = true;
    });
  }

  HomeAppearanceDraft get _appearanceDraft {
    return HomeAppearanceDraft(
      theme: _modernTheme,
      sectionOrder: _homeSectionOrder,
      rooms: _roomSection,
      environment: _environmentSection,
      about: _aboutSection,
      news: _newsSection,
      quickBooking: _quickBookingSection,
      information: _informationSections,
      navigation: _navigationConfig,
      bannerFrame: _modernBannerFrame,
      showStayServiceStrip: _showStayServiceStrip,
      featuredProductLayout: _featuredProductLayout,
      storeEntryLayout: _storeEntryLayout,
    );
  }

  bool get _chatReady {
    return _chatProvisioned ||
        _floatingButtonType == ShopChatService.floatingTypePetnestChat;
  }

  Map<String, dynamic> get _draftFloatingContact {
    return <String, dynamic>{
      'enabled': _floatingButtonEnabled,
      'type': _floatingButtonType,
      'size': _floatingButtonSize,
      'label': _floatingButtonLabelController.text.trim(),
    };
  }

  HomeShortcutGate _shortcutGate() {
    return HomeShortcutGate.fromShop(
      _loadedShop,
      memberCenterEnabled: _modernTheme.drawerSetting.showMemberCenter,
      showShopMenus: _modernTheme.drawerSetting.showShopMenus,
      floatingEnabled: _floatingButtonEnabled,
      floatingType: _floatingButtonType,
      chatProvisioned: _chatReady,
    );
  }

  Map<String, dynamic> get _previewModernAppearance {
    final HomeAppearancePreset? browsing = homeAppearancePresetById(
      _browsingPresetId,
    );
    if (browsing == null) {
      return _draftModernAppearance;
    }
    final HomeAppearanceDraft next = browsing.apply(_appearanceDraft);
    return <String, dynamic>{
      ..._draftModernAppearance,
      'themeColors': next.theme.toMap(),
      'homeSectionOrder': next.sectionOrder,
      'roomSection': next.rooms.toMap(),
      'environmentSection': next.environment.toMap(),
      'aboutSection': next.about.toMap(),
      'newsSection': next.news.toMap(),
      'quickBookingSection': next.quickBooking.toMap(),
      'informationSections': next.information.toMap(),
      'showStayServiceStrip': next.showStayServiceStrip,
      'featuredProductLayout': next.featuredProductLayout,
      'storeEntryLayout': next.storeEntryLayout,
      ...next.bannerFrame.toMap(),
      ...next.navigation.toMap(),
    };
  }

  void _applyAppearancePreset(HomeAppearancePreset preset) {
    final HomeAppearanceDraft next = preset.apply(_appearanceDraft);
    setState(() {
      if (_selectedLayout != 'modern') {
        _storeSelectedLayoutSettings();
        _selectedLayout = 'modern';
        _applySelectedLayoutSettings();
      }
      _modernTheme = next.theme;
      _homeSectionOrder = next.sectionOrder;
      _roomSection = next.rooms;
      _environmentSection = next.environment;
      _aboutSection = next.about;
      _newsSection = next.news;
      _quickBookingSection = next.quickBooking;
      _informationSections = next.information;
      _navigationConfig = next.navigation;
      _modernBannerFrame = next.bannerFrame;
      _showStayServiceStrip = next.showStayServiceStrip;
      _featuredProductLayout = next.featuredProductLayout;
      _storeEntryLayout = next.storeEntryLayout;
      _appearancePresetId = preset.id;
      _browsingPresetId = null;
      _appearanceDirty = true;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已套用『${preset.name}』預覽，確認後請儲存外觀設定。')),
    );
  }

  Widget _appearancePresetStrip() {
    return HomeAppearancePresetStrip(
      showHeading: false,
      draft: _appearanceDraft,
      presetId: _appearancePresetId,
      previewingId: _browsingPresetId,
      accent: _modernTheme.primaryColor,
      onPreview: (HomeAppearancePreset preset) {
        setState(() => _browsingPresetId = preset.id);
      },
      onApply: _applyAppearancePreset,
    );
  }

  Widget _buildRoomPane(bool desktopModern) {
    if (_selectedLayout != 'modern') {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: const <Widget>[
          Text('房型展示只套用在新版前台。請先在外觀設定改用新版首頁。', style: TextStyle(height: 1.4)),
        ],
      );
    }
    final Widget settings = RoomSectionSettingsPanel(
      shopId: widget.shopId,
      setting: _roomSection,
      theme: _modernTheme,
      selectedRoomTypeId: _selectedRoomTypeId,
      sharedZoneEnabled: _sharedEntrySection.enabled,
      hideSharedPlacement: true,
      onChanged: (HomeRoomSectionSetting value) {
        setState(() {
          _roomSection = value;
          _sharedEntrySection = _sharedEntrySection.including(
            HomeSharedEntrySources.rooms,
            when: roomSimpleUsesSharedZone(value),
          );
          _appearanceDirty = true;
        });
      },
      onManageRooms: _openRoomManagement,
    );
    final Widget roomSettings = _withSharedJoin(
      HomeSharedEntrySources.rooms,
      settings,
    );
    if (desktopModern) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: 452,
              child: _homeCanvasPreview(
                showCaption: true,
                canvasMode: 'roomDesktop',
                focusSectionId: 'rooms',
                focusSectionToken: _roomFocusToken,
              ),
            ),
            const SizedBox(width: 16),
            const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(child: roomSettings),
                  _saveBar(),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              onPressed: _openRoomSectionPreview,
              icon: const Icon(Icons.smartphone_outlined),
              label: const Text('預覽房型區塊'),
            ),
          ),
        ),
        Expanded(child: roomSettings),
      ],
    );
  }

  Widget _buildEnvironmentPane(bool desktopModern) {
    if (_selectedLayout != 'modern') {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: const <Widget>[
          Text('環境展示只套用在新版前台。請先在外觀設定改用新版首頁。', style: TextStyle(height: 1.4)),
        ],
      );
    }
    final Widget settings = EnvironmentSectionSettingsPanel(
      setting: _environmentSection,
      theme: _modernTheme,
      onChanged: (HomeEnvironmentSectionSetting value) {
        setState(() {
          _environmentSection = value;
          _appearanceDirty = true;
        });
      },
    );
    final Widget environmentSettings = _withSharedJoin(
      HomeSharedEntrySources.facilities,
      settings,
    );
    if (desktopModern) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: 452,
              child: _homeCanvasPreview(
                showCaption: true,
                canvasMode: 'environmentDesktop',
                focusSectionId: 'facilities',
                focusSectionToken: _environmentFocusToken,
              ),
            ),
            const SizedBox(width: 16),
            const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(child: environmentSettings),
                  _saveBar(),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              onPressed: _openEnvironmentSectionPreview,
              icon: const Icon(Icons.smartphone_outlined),
              label: const Text('預覽環境區塊'),
            ),
          ),
        ),
        Expanded(child: environmentSettings),
      ],
    );
  }

  void _openEnvironmentSectionPreview() {
    setState(() => _environmentFocusToken++);
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog.fullscreen(
          child: Scaffold(
            appBar: AppBar(
              title: const Text('預覽環境區塊'),
              leading: const CloseButton(),
            ),
            body: _homeCanvasPreview(
              showCaption: false,
              canvasMode: 'environmentDialog',
              focusSectionId: 'facilities',
              focusSectionToken: _environmentFocusToken,
              embeddedAdminPreview: false,
            ),
          ),
        );
      },
    );
  }

  Widget _buildAboutPane(bool desktopModern) {
    if (_selectedLayout != 'modern') {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: const <Widget>[
          Text(
            '關於我們首頁區塊只套用在新版前台。請先在外觀設定改用新版首頁。',
            style: TextStyle(height: 1.4),
          ),
        ],
      );
    }
    final Map<String, dynamic> intro = _loadedShop['environmentIntro'] is Map
        ? Map<String, dynamic>.from(_loadedShop['environmentIntro'] as Map)
        : <String, dynamic>{};
    final Widget settings = AboutSectionSettingsPanel(
      setting: _aboutSection,
      theme: _modernTheme,
      imageChoices: HomeAboutSectionSetting.imageChoices(
        shop: _loadedShop,
        environmentIntro: intro,
      ),
      onChanged: (HomeAboutSectionSetting value) {
        setState(() {
          _aboutSection = value;
          _appearanceDirty = true;
        });
      },
    );
    final Widget aboutSettings = _withSharedJoin(
      HomeSharedEntrySources.about,
      settings,
    );
    if (desktopModern) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: 452,
              child: _homeCanvasPreview(
                showCaption: true,
                canvasMode: 'aboutDesktop',
                focusSectionId: 'about',
                focusSectionToken: _aboutFocusToken,
              ),
            ),
            const SizedBox(width: 16),
            const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(child: aboutSettings),
                  _saveBar(),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              onPressed: _openAboutSectionPreview,
              icon: const Icon(Icons.smartphone_outlined),
              label: const Text('預覽關於我們'),
            ),
          ),
        ),
        Expanded(child: aboutSettings),
      ],
    );
  }

  Widget _buildNewsPane(bool desktopModern) {
    if (_selectedLayout != 'modern') {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: const <Widget>[
          Text(
            '最新消息首頁區塊只套用在新版前台。請先在外觀設定改用新版首頁。',
            style: TextStyle(height: 1.4),
          ),
        ],
      );
    }
    final Widget settings = NewsSectionSettingsPanel(
      setting: _newsSection,
      theme: _modernTheme,
      locked: _loadedShop['showAnnouncementSection'] == false,
      onOpenFeatures: () {
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ShopAnnouncementManagePage(shopId: widget.shopId),
          ),
        );
      },
      onChanged: (HomeNewsSectionSetting value) {
        setState(() {
          _newsSection = value;
          _appearanceDirty = true;
        });
      },
    );
    final Widget newsSettings = _withSharedJoin(
      HomeSharedEntrySources.announcements,
      settings,
    );
    if (desktopModern) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: 452,
              child: _homeCanvasPreview(
                showCaption: true,
                canvasMode: 'newsDesktop',
                focusSectionId: 'announcements',
                focusSectionToken: _newsFocusToken,
              ),
            ),
            const SizedBox(width: 16),
            const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(child: newsSettings),
                  _saveBar(),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              onPressed: _openNewsSectionPreview,
              icon: const Icon(Icons.smartphone_outlined),
              label: const Text('預覽最新消息'),
            ),
          ),
        ),
        Expanded(child: newsSettings),
      ],
    );
  }

  void _openNewsSectionPreview() {
    setState(() => _newsFocusToken++);
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog.fullscreen(
          child: Scaffold(
            appBar: AppBar(
              title: const Text('預覽最新消息'),
              leading: const CloseButton(),
            ),
            body: _homeCanvasPreview(
              showCaption: false,
              canvasMode: 'newsDialog',
              focusSectionId: 'announcements',
              focusSectionToken: _newsFocusToken,
              embeddedAdminPreview: false,
            ),
          ),
        );
      },
    );
  }

  void _openAboutSectionPreview() {
    setState(() => _aboutFocusToken++);
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog.fullscreen(
          child: Scaffold(
            appBar: AppBar(
              title: const Text('預覽關於我們'),
              leading: const CloseButton(),
            ),
            body: _homeCanvasPreview(
              showCaption: false,
              canvasMode: 'aboutDialog',
              focusSectionId: 'about',
              focusSectionToken: _aboutFocusToken,
              embeddedAdminPreview: false,
            ),
          ),
        );
      },
    );
  }

  void _openRoomManagement() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ShopRoomTypePage(shopId: widget.shopId),
      ),
    );
  }

  void _openRoomSectionPreview() {
    setState(() => _roomFocusToken++);
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog.fullscreen(
          child: Scaffold(
            appBar: AppBar(
              title: const Text('預覽房型區塊'),
              leading: const CloseButton(),
            ),
            body: _homeCanvasPreview(
              showCaption: false,
              canvasMode: 'roomDialog',
              focusSectionId: 'rooms',
              focusSectionToken: _roomFocusToken,
              embeddedAdminPreview: false,
            ),
          ),
        );
      },
    );
  }

  void _onAppearanceTabSignal(PointerSignalEvent event) {
    if (event is! PointerScrollEvent) {
      return;
    }
    final BuildContext? root = _appearanceTabBarKey.currentContext;
    if (root == null) {
      return;
    }
    ScrollableState? scrollable;
    void visit(Element element) {
      if (scrollable != null) {
        return;
      }
      if (element is StatefulElement && element.state is ScrollableState) {
        scrollable = element.state as ScrollableState;
        return;
      }
      element.visitChildren(visit);
    }

    root.visitChildElements(visit);
    final ScrollPosition? position = scrollable?.position;
    if (position == null || !position.hasContentDimensions) {
      return;
    }
    final double delta = event.scrollDelta.dx.abs() > event.scrollDelta.dy.abs()
        ? event.scrollDelta.dx
        : event.scrollDelta.dy;
    if (delta == 0) {
      return;
    }
    position.jumpTo(
      (position.pixels + delta).clamp(
        position.minScrollExtent,
        position.maxScrollExtent,
      ),
    );
  }

  bool get _accommodationAvailable => _loadedShop['bookingEnabled'] != false;

  bool get _daycareAvailable => DaycareSettingsService.instance
      .isEnabledForShop(shop: _loadedShop, settings: _daycareSettings);

  Widget _buildQuickBookingPane(bool desktopModern) {
    return _sectionEditorPane(
      desktopModern: desktopModern,
      classicMessage: '快速預約首頁區塊只套用在新版前台。請先在外觀設定改用新版首頁。',
      previewLabel: '預覽快速預約',
      focusSectionId: 'quickBooking',
      focusSectionToken: _quickBookingFocusToken,
      canvasMode: 'quickBooking',
      sharedSourceId: HomeSharedEntrySources.quickBooking,
      settings: QuickBookingSectionSettingsPanel(
        setting: _quickBookingSection,
        theme: _modernTheme,
        accommodationAvailable: _accommodationAvailable,
        daycareAvailable: _daycareAvailable,
        onChanged: (HomeQuickBookingSectionSetting value) {
          setState(() {
            _quickBookingSection = value;
            _appearanceDirty = true;
          });
        },
      ),
    );
  }

  Widget _buildPolicyPane(bool desktopModern) {
    return _sectionEditorPane(
      desktopModern: desktopModern,
      classicMessage: '入住須知首頁區塊只套用在新版前台。請先在外觀設定改用新版首頁。',
      previewLabel: '預覽入住須知',
      focusSectionId: 'policy',
      focusSectionToken: _policyFocusToken,
      canvasMode: 'policy',
      sharedSourceId: HomeSharedEntrySources.policy,
      settings: PolicySectionSettingsPanel(
        setting: _informationSections,
        theme: _modernTheme,
        onChanged: (HomeInformationSectionsSetting value) {
          setState(() {
            _informationSections = value;
            _appearanceDirty = true;
          });
        },
      ),
    );
  }

  Widget _buildFaqPane(bool desktopModern) {
    return _sectionEditorPane(
      desktopModern: desktopModern,
      classicMessage: '常見問題首頁區塊只套用在新版前台。請先在外觀設定改用新版首頁。',
      previewLabel: '預覽常見問題',
      focusSectionId: 'faq',
      focusSectionToken: _faqFocusToken,
      canvasMode: 'faq',
      sharedSourceId: HomeSharedEntrySources.faq,
      settings: FaqSectionSettingsPanel(
        setting: _informationSections,
        theme: _modernTheme,
        locked: _loadedShop['showFaqSection'] == false,
        onOpenFeatures: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => ShopFaqManagePage(shopId: widget.shopId),
            ),
          );
        },
        onChanged: (HomeInformationSectionsSetting value) {
          setState(() {
            _informationSections = value;
            _appearanceDirty = true;
          });
        },
      ),
    );
  }

  Widget _buildReviewPane(bool desktopModern) {
    return _sectionEditorPane(
      desktopModern: desktopModern,
      classicMessage: '顧客評價首頁區塊只套用在新版前台。請先在外觀設定改用新版首頁。',
      previewLabel: '預覽顧客評價',
      focusSectionId: 'reviews',
      focusSectionToken: _reviewFocusToken,
      canvasMode: 'reviews',
      sharedSourceId: HomeSharedEntrySources.reviews,
      settings: ReviewSectionSettingsPanel(
        setting: _informationSections,
        theme: _modernTheme,
        onChanged: (HomeInformationSectionsSetting value) {
          setState(() {
            _informationSections = value;
            _appearanceDirty = true;
          });
        },
      ),
    );
  }

  Widget _sectionEditorPane({
    required bool desktopModern,
    required String classicMessage,
    required String previewLabel,
    required String focusSectionId,
    required int focusSectionToken,
    required String canvasMode,
    required Widget settings,
    String? sharedSourceId,
  }) {
    if (_selectedLayout != 'modern') {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: <Widget>[
          Text(classicMessage, style: const TextStyle(height: 1.4)),
        ],
      );
    }
    final Widget settingsBody = sharedSourceId == null
        ? settings
        : _withSharedJoin(sharedSourceId, settings);
    if (desktopModern) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: 452,
              child: _homeCanvasPreview(
                showCaption: true,
                canvasMode: '${canvasMode}Desktop',
                focusSectionId: focusSectionId,
                focusSectionToken: focusSectionToken,
              ),
            ),
            const SizedBox(width: 16),
            const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(child: settingsBody),
                  _saveBar(),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              onPressed: () => _openSectionPreview(
                title: previewLabel,
                focusSectionId: focusSectionId,
                canvasMode: canvasMode,
              ),
              icon: const Icon(Icons.smartphone_outlined),
              label: Text(previewLabel),
            ),
          ),
        ),
        Expanded(child: settingsBody),
      ],
    );
  }

  void _openSectionPreview({
    required String title,
    required String focusSectionId,
    required String canvasMode,
  }) {
    setState(() {
      if (focusSectionId == 'quickBooking') {
        _quickBookingFocusToken++;
      } else if (focusSectionId == 'policy') {
        _policyFocusToken++;
      } else if (focusSectionId == 'faq') {
        _faqFocusToken++;
      } else if (focusSectionId == 'reviews') {
        _reviewFocusToken++;
      }
    });
    final int token = switch (focusSectionId) {
      'quickBooking' => _quickBookingFocusToken,
      'faq' => _faqFocusToken,
      'reviews' => _reviewFocusToken,
      _ => _policyFocusToken,
    };
    showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return Dialog.fullscreen(
          child: Scaffold(
            appBar: AppBar(title: Text(title), leading: const CloseButton()),
            body: _homeCanvasPreview(
              showCaption: false,
              canvasMode: '${canvasMode}Dialog',
              focusSectionId: focusSectionId,
              focusSectionToken: token,
              embeddedAdminPreview: false,
            ),
          ),
        );
      },
    );
  }

  Widget _buildNavigationPane(bool desktopModern) {
    if (_selectedLayout != 'modern') {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: const <Widget>[
          Text('導覽設定只套用在新版前台。請先在外觀設定改用新版首頁。', style: TextStyle(height: 1.4)),
        ],
      );
    }
    if (desktopModern) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              width: 452,
              child: _homeCanvasPreview(
                showCaption: true,
                canvasMode: 'desktop',
              ),
            ),
            const SizedBox(width: 16),
            const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                children: <Widget>[
                  Expanded(child: _navigationSettingsScroll()),
                  _saveBar(),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: SegmentedButton<int>(
            segments: const <ButtonSegment<int>>[
              ButtonSegment<int>(
                value: 0,
                label: Text('預覽'),
                icon: Icon(Icons.smartphone_outlined),
              ),
              ButtonSegment<int>(
                value: 1,
                label: Text('設定'),
                icon: Icon(Icons.tune),
              ),
            ],
            selected: <int>{_homeCanvasPane},
            onSelectionChanged: (Set<int> value) {
              setState(() => _homeCanvasPane = value.first);
            },
          ),
        ),
        Expanded(
          child: _homeCanvasPane == 0
              ? Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                  child: _homeCanvasPreview(
                    showCaption: false,
                    canvasMode: 'mobile',
                  ),
                )
              : _navigationSettingsScroll(),
        ),
      ],
    );
  }

  Widget _navigationSettingsScroll() {
    return Scrollbar(
      controller: _navigationScroll,
      thumbVisibility: true,
      child: ListView(
        controller: _navigationScroll,
        primary: false,
        padding: const EdgeInsets.fromLTRB(4, 4, 8, 24),
        children: <Widget>[
          Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 860),
              child: FrontendNavigationPanel(
                config: _navigationConfig,
                shopState: _navShopState,
                onChanged: (FrontendNavigationConfig value) {
                  setState(() {
                    _navigationConfig = value;
                    _appearanceDirty = true;
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppearancePane(bool desktopModern) {
    if (_selectedLayout != 'modern') {
      return _classicAppearanceList();
    }
    if (desktopModern) {
      return _modernDesktopWorkspace();
    }
    return _modernMobileWorkspace();
  }

  bool get _desktopModernLayout =>
      MediaQuery.sizeOf(context).width >= 1100 && _selectedLayout == 'modern';

  void _selectHomeSection(String sectionId) {
    final int? tab = ModernHomeAppearanceTabs.sectionTab(sectionId);
    if (tab != null) {
      setState(() {
        _selectedHomeSection = sectionId;
        if (sectionId == 'policy') {
          _policyFocusToken++;
        } else if (sectionId == 'faq') {
          _faqFocusToken++;
        } else if (sectionId == 'reviews') {
          _reviewFocusToken++;
        } else if (sectionId == 'rooms') {
          _roomFocusToken++;
        } else if (sectionId == 'facilities') {
          _environmentFocusToken++;
        } else if (sectionId == 'about') {
          _aboutFocusToken++;
        } else if (sectionId == 'announcements') {
          _newsFocusToken++;
        } else if (sectionId == 'quickBooking') {
          _quickBookingFocusToken++;
        }
      });
      if (_tabController.index != tab) {
        _tabController.animateTo(tab);
      }
      return;
    }
    final int category = AppearanceCategories.forSection(sectionId);
    setState(() {
      _selectedHomeSection = sectionId;
      _appearanceCategory = category;
      if (!_desktopModernLayout) {
        _homeCanvasPane = 1;
      }
    });
    if (_tabController.index != ModernHomeAppearanceTabs.appearance) {
      _tabController.animateTo(ModernHomeAppearanceTabs.appearance);
    }
  }

  String _pendingSectionLabel(String? sectionId) {
    switch (sectionId) {
      case 'facilities':
        return '設備特色';
      case 'announcements':
        return '最新公告';
      case 'dailyCare':
        return '住宿日誌';
      case 'services':
        return '住宿服務';
      case 'footer':
        return '店家資訊';
      default:
        return '此區塊';
    }
  }

  bool get _pendingSectionSelected {
    switch (_selectedHomeSection) {
      case 'facilities':
      case 'announcements':
      case 'dailyCare':
      case 'services':
      case 'footer':
        return true;
      default:
        return false;
    }
  }

  Widget _homeCanvasPreview({
    required bool showCaption,
    required String canvasMode,
    bool embeddedAdminPreview = true,
    String? focusSectionId,
    int focusSectionToken = 0,
  }) {
    return ModernHomeEditorPreview(
      shopId: widget.shopId,
      draftModernAppearance: _previewModernAppearance,
      draftLogoUrl: _modernLogoUrl,
      draftFloatingContact: _draftFloatingContact,
      draftStoreChatEnabled: _chatReady,
      showCaption: showCaption,
      showPhoneChrome: false,
      layoutCanvas: true,
      isEmbeddedAdminPreview: embeddedAdminPreview,
      canvasMode: canvasMode,
      frameWidth: 390,
      selectedSectionId: _selectedHomeSection,
      focusSectionId: focusSectionId,
      focusSectionToken: focusSectionToken,
      selectedRoomTypeId: _selectedRoomTypeId,
      onSelectRoomType: (String roomTypeId) {
        setState(() {
          _selectedRoomTypeId = roomTypeId.isEmpty ? null : roomTypeId;
        });
      },
      onSelectSection: _selectHomeSection,
      onBrandStyleChanged: (StoreBrandStyle style) {
        setState(() {
          _brandStyle = style;
          _appearanceDirty = true;
        });
      },
      onHomeSectionOrderChanged: (List<String> order) {
        setState(() {
          _homeSectionOrder = HomeSectionOrder.normalize(order);
          _appearanceDirty = true;
        });
      },
    );
  }

  Widget _classicAppearanceList() {
    return Scrollbar(
      controller: _appearanceScroll,
      thumbVisibility: true,
      child: ListView(
        controller: _appearanceScroll,
        primary: false,
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: <Widget>[
          _appearancePresetStrip(),
          const SizedBox(height: 18),
          _buildSectionTitle(
            icon: Icons.view_quilt_outlined,
            title: '首頁版型',
            description: '選擇顧客進入店家首頁時看到的排版',
          ),
          const SizedBox(height: 10),
          _buildLayoutSelector(),
          const SizedBox(height: 24),
          _buildSectionTitle(
            icon: Icons.palette_outlined,
            title: '主題顏色',
            description: '控制按鈕、圖示與重點文字的主要顏色',
          ),
          const SizedBox(height: 10),
          _buildThemeSelector(),
          const SizedBox(height: 24),
          _buildSectionTitle(
            icon: Icons.format_paint_outlined,
            title: '背景顏色',
            description: '選擇店家前台整體背景色',
          ),
          const SizedBox(height: 10),
          _buildBackgroundSelector(),
          const SizedBox(height: 24),
          _roleActionCards(),
        ],
      ),
    );
  }

  Widget _modernDesktopWorkspace() {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final double previewWidth = (constraints.maxWidth * 0.30).clamp(
          360.0,
          480.0,
        );
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 12, 0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SizedBox(
                width: previewWidth,
                child: _homeCanvasPreview(
                  showCaption: true,
                  canvasMode: 'desktop',
                ),
              ),
              const SizedBox(width: 12),
              const VerticalDivider(width: 1, color: Color(0xFFE6E8EC)),
              const SizedBox(width: 12),
              Expanded(child: _appearanceSettingsColumn(showSave: true)),
            ],
          ),
        );
      },
    );
  }

  Widget _appearanceSettingsColumn({required bool showSave}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Expanded(
          child: Column(
            children: <Widget>[
              Expanded(child: _appearanceCategoryStack()),
              if (showSave) _saveBar(),
            ],
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          width: 112,
          child: SingleChildScrollView(
            primary: false,
            padding: const EdgeInsets.only(bottom: 12),
            child: AppearanceCategoryRail(
              selected: _appearanceCategory,
              onSelected: _selectAppearanceCategory,
            ),
          ),
        ),
      ],
    );
  }

  Widget _appearanceCategoryStack() {
    return IndexedStack(
      index: _appearanceCategory.clamp(0, AppearanceCategories.length - 1),
      sizing: StackFit.expand,
      children: <Widget>[
        for (int index = 0; index < AppearanceCategories.length; index++)
          _appearanceCategoryScroll(index),
      ],
    );
  }

  Widget _appearanceCategoryScroll(int index) {
    return Scrollbar(
      controller: _appearanceCategoryScrolls[index],
      thumbVisibility: true,
      child: ListView(
        controller: _appearanceCategoryScrolls[index],
        primary: false,
        padding: const EdgeInsets.fromLTRB(0, 4, 4, 24),
        children: <Widget>[
          Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 920),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  _appearanceCategoryHeading(index),
                  ..._appearanceCategoryChildren(index),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _modernMobileWorkspace() {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: SegmentedButton<int>(
            segments: const <ButtonSegment<int>>[
              ButtonSegment<int>(
                value: 0,
                label: Text('預覽'),
                icon: Icon(Icons.smartphone_outlined),
              ),
              ButtonSegment<int>(
                value: 1,
                label: Text('設定'),
                icon: Icon(Icons.tune),
              ),
            ],
            selected: <int>{_homeCanvasPane},
            onSelectionChanged: (Set<int> value) {
              setState(() => _homeCanvasPane = value.first);
            },
          ),
        ),
        Expanded(
          child: _homeCanvasPane == 0
              ? Padding(
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                  child: _homeCanvasPreview(
                    showCaption: false,
                    canvasMode: 'mobile',
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                  child: Column(
                    children: <Widget>[
                      _appearanceCategorySelector(),
                      const SizedBox(height: 8),
                      Expanded(child: _appearanceCategoryStack()),
                    ],
                  ),
                ),
        ),
      ],
    );
  }

  Widget _appearanceCategoryHeading(int index) {
    final AppearanceCategoryItem item = AppearanceCategories.of(index);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            item.label,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 2),
          Text(
            item.description,
            style: const TextStyle(
              fontSize: 13,
              height: 1.35,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }

  Widget _appearanceCategorySelector() {
    final AppearanceCategoryItem item = AppearanceCategories.of(
      _appearanceCategory,
    );
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        key: const ValueKey<String>('appearance-category-selector'),
        borderRadius: BorderRadius.circular(12),
        onTap: _openAppearanceCategorySheet,
        child: Container(
          constraints: const BoxConstraints(minHeight: 48),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE6E8EC)),
          ),
          child: Row(
            children: <Widget>[
              Icon(item.icon, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '目前分類：${item.shortLabel}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              const Icon(Icons.expand_more),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openAppearanceCategorySheet() async {
    final int? next = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Text(
                  '選擇設定分類',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
                AppearanceCategoryPicker(
                  selected: _appearanceCategory,
                  onSelected: (int value) {
                    Navigator.of(sheetContext).pop(value);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
    if (next == null || !mounted) {
      return;
    }
    _selectAppearanceCategory(next);
  }

  void _selectAppearanceCategory(int value) {
    setState(() => _appearanceCategory = value);
    final ScrollController controller = _appearanceCategoryScrolls[value];
    if (controller.hasClients) {
      controller.jumpTo(0);
    }
  }

  List<Widget> _appearanceCategoryChildren(int index) {
    return switch (index) {
      AppearanceCategories.presets => _presetCategory(),
      AppearanceCategories.brand => _brandCategory(),
      AppearanceCategories.cards => _sharedCardCategory(),
      AppearanceCategories.banners => _bannerCategory(),
      AppearanceCategories.background => _backgroundCategory(),
      _ => _otherAppearanceCategory(),
    };
  }

  List<Widget> _brandCategory() {
    return <Widget>[
      KeyedSubtree(
        key: _headerSettingsKey,
        child: StoreBrandSettingsCard(
          style: _brandStyle,
          theme: _modernTheme,
          shopName: (_loadedShop['name'] ?? '').toString(),
          subtitleController: _modernHeaderSubtitleController,
          logoSection: _buildModernLogoSettings(),
          hasLogo:
              _modernLogoUrl.trim().isNotEmpty ||
              _modernLogoPreviewBytes != null,
          onChanged: (StoreBrandStyle style) {
            setState(() {
              _brandStyle = style;
              _appearanceDirty = true;
            });
          },
        ),
      ),
    ];
  }

  List<Widget> _sharedCardCategory() {
    return <Widget>[
      KeyedSubtree(
        key: _sharedEntrySettingsKey,
        child: _editorCard(
          title: '首頁共用精緻小卡區',
          subtitle: '選擇要放上首頁的功能入口。外觀在這裡統一調整，每張小卡只編輯圖片、文字與顏色。',
          summary: _sharedEntrySection.enabled ? '已啟用' : '未啟用',
          child: SharedEntrySettingsCard(
            setting: _sharedEntryForDraft,
            cards: <SharedEntryCardRef>[
              for (final String id in sharedEntryJoinedIds(
                section: _sharedEntryForDraft,
                rooms: _roomSection,
              ))
                SharedEntryCardRef(id: id, label: sharedEntryCardLabel(id)),
            ],
            onChanged: _applySharedSection,
          ),
        ),
      ),
    ];
  }

  List<Widget> _bannerCategory() {
    return <Widget>[
      KeyedSubtree(
        key: _bannerSettingsKey,
        child: _editorCard(
          title: '首頁活動海報',
          subtitle: '同一個海報區域可切換經典完整海報或活動滑動海報。圖片與連結仍到活動海報管理編輯。',
          summary: _bannerStatusText,
          child: _buildHomeBannerDisplaySettings(),
        ),
      ),
    ];
  }

  List<Widget> _presetCategory() {
    return <Widget>[_appearancePresetStrip()];
  }

  List<Widget> _backgroundCategory() {
    return <Widget>[
      HomeColorSettingsPanel(
        theme: _modernTheme,
        entryTheme: _colorEntryTheme,
        onChanged: _replaceModernTheme,
      ),
    ];
  }

  List<Widget> _otherAppearanceCategory() {
    return <Widget>[
      _editorCard(
        title: '新版首頁基本外觀',
        subtitle: '目前使用新版首頁',
        trailing: TextButton(
          onPressed: () => _changeLayout('classic'),
          child: const Text('改用經典版'),
        ),
        child: const Text(
          '顧客進入店家時會看到新版 Beta。經典版的顏色設定會保留。',
          style: TextStyle(fontSize: 13, height: 1.4),
        ),
      ),
      _roleActionCards(),
      if (StorefrontAccess.isModuleEnabled(_loadedShop))
        KeyedSubtree(
          key: _storeSettingsKey,
          child: _editorCard(
            title: '商城',
            subtitle: '商城首頁與商品展示已移至商城專屬設定。',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  '此區塊內容與外觀請至商城設定管理。首頁排序只決定它出現的位置。',
                  style: TextStyle(fontSize: 13, height: 1.4),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => ShopStoreSettingsPage(
                            shopId: widget.shopId,
                            canManage: true,
                          ),
                        ),
                      );
                    },
                    child: const Text('前往商城設定 →'),
                  ),
                ),
              ],
            ),
          ),
        ),
      if (_pendingSectionSelected)
        KeyedSubtree(
          key: _pendingSettingsKey,
          child: _editorCard(
            title: _pendingSectionLabel(_selectedHomeSection),
            subtitle: '此區塊設定後續開放',
            child: const Text(
              '此區塊設定後續開放',
              style: TextStyle(fontSize: 13, height: 1.4),
            ),
          ),
        ),
      _editorCard(
        title: '側邊選單',
        subtitle: '影響新版首頁左上角選單要顯示的內容',
        child: _buildModernDrawerSettings(),
      ),
    ];
  }

  Widget _roleActionCards() {
    return FrontendRoleActionsPanel(
      floatingEnabled: _floatingButtonEnabled,
      floatingType: _floatingButtonType,
      floatingSize: _floatingButtonSize,
      labelController: _floatingButtonLabelController,
      quickActions: _quickActions,
      gate: _shortcutGate(),
      onFloatingEnabled: (bool value) {
        setState(() {
          _floatingButtonEnabled = value;
          if (value &&
              _floatingButtonType == ShopChatService.floatingTypePetnestChat) {
            _chatProvisioned = true;
          }
          _appearanceDirty = true;
        });
      },
      onFloatingType: (String value) {
        setState(() {
          _floatingButtonType = value;
          if (value == ShopChatService.floatingTypePetnestChat) {
            _chatProvisioned = true;
          }
          _appearanceDirty = true;
        });
      },
      onFloatingSize: (String value) {
        setState(() {
          _floatingButtonSize = value;
          _appearanceDirty = true;
        });
      },
      onQuickActions: (HomeQuickActionSetting value) {
        setState(() {
          _quickActions = value;
          _appearanceDirty = true;
        });
      },
      onLabelChanged: () {
        setState(() => _appearanceDirty = true);
      },
    );
  }

  Widget _editorCard({
    required String title,
    required String subtitle,
    required Widget child,
    String? summary,
    Widget? trailing,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE6E8EC)),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          style: const TextStyle(
                            fontSize: 12,
                            height: 1.35,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (summary != null) ...<Widget>[
                    const SizedBox(width: 8),
                    Text(
                      summary,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF9A5B12),
                      ),
                    ),
                  ],
                  if (trailing != null) trailing,
                ],
              ),
              const SizedBox(height: 12),
              child,
            ],
          ),
        ),
      ),
    );
  }

  Widget _saveBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.grey.shade200)),
        ),
        child: FilledButton.icon(
          onPressed: _isSaving ? null : _saveSettings,
          icon: _isSaving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.save_outlined),
          label: Text(_isSaving ? '儲存中...' : '儲存外觀設定'),
        ),
      ),
    );
  }

  bool get _hasAvailableContactMethod {
    return _shopPhone.isNotEmpty ||
        _shopLineUrl.isNotEmpty ||
        _shopFacebookUrl.isNotEmpty ||
        _shopInstagramUrl.isNotEmpty;
  }

  Widget _buildSectionTitle({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 22, color: Colors.brown.shade700),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                description,
                style: TextStyle(fontSize: 13, color: Colors.grey.shade700),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLayoutSelector() {
    return Column(
      children: [
        _buildLayoutCard(
          value: 'classic',
          title: '經典版',
          subtitle: '目前穩定使用中的首頁版面',
          icon: Icons.dashboard_outlined,
        ),
        const SizedBox(height: 10),
        _buildLayoutCard(
          value: 'modern',
          title: '新版 Beta',
          subtitle: '較緊湊、房型與評價資訊更醒目',
          icon: Icons.auto_awesome_outlined,
          beta: true,
        ),
      ],
    );
  }

  Widget _buildLayoutCard({
    required String value,
    required String title,
    required String subtitle,
    required IconData icon,
    bool beta = false,
  }) {
    final selected = _selectedLayout == value;

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        _changeLayout(value);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? Colors.orange.shade50 : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? Colors.orange : Colors.grey.shade300,
            width: selected ? 1.6 : 1,
          ),
        ),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: selected
                  ? Colors.orange.shade100
                  : Colors.grey.shade100,
              child: Icon(
                icon,
                color: selected ? Colors.orange.shade800 : Colors.grey.shade700,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      if (beta) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.orange,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: const Text(
                            'Beta',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(fontSize: 13, color: Colors.grey.shade700),
                  ),
                ],
              ),
            ),
            Radio<String>(
              value: value,
              groupValue: _selectedLayout,
              onChanged: (newValue) {
                if (newValue == null) return;

                _changeLayout(newValue);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernLogoSettings() {
    final bool hasPreview = _modernLogoPreviewBytes != null;
    final bool hasNetworkLogo = _modernLogoUrl.trim().isNotEmpty;

    Widget logoPreview;

    if (hasPreview) {
      logoPreview = Image.memory(_modernLogoPreviewBytes!, fit: BoxFit.contain);
    } else if (hasNetworkLogo) {
      logoPreview = Image.network(
        _modernLogoUrl,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          return const Icon(
            Icons.pets_rounded,
            size: 42,
            color: Color(0xFFFF8A00),
          );
        },
      );
    } else {
      logoPreview = const Icon(
        Icons.pets_rounded,
        size: 42,
        color: Color(0xFFFF8A00),
      );
    }

    final Widget logoButton = FilledButton.icon(
      onPressed: _isUploadingModernLogo ? null : _pickAndUploadModernLogo,
      icon: _isUploadingModernLogo
          ? const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          : const Icon(Icons.photo_library_outlined),
      label: Text(
        _isUploadingModernLogo
            ? '上傳中'
            : hasNetworkLogo
            ? '更換 Logo'
            : '上傳 Logo',
      ),
    );
    final Widget logoThumb = Container(
      width: 56,
      height: 56,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE6E8EC)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: logoPreview,
      ),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          children: <Widget>[
            logoThumb,
            const SizedBox(width: 12),
            Flexible(child: logoButton),
          ],
        ),
        const SizedBox(height: 6),
        const Text(
          '建議 600 × 600 px，PNG 或 JPG，最大 5 MB。',
          style: TextStyle(
            fontSize: 12,
            color: Color(0xFF64748B),
            height: 1.35,
          ),
        ),
      ],
    );
  }

  Widget _buildHomeBannerDisplaySettings() {
    return HomeBannerDisplaySettings(
      frame: _modernBannerFrame,
      bannerCount: _enabledHomeBannerCount,
      onChanged: (ModernBannerFrameSetting next) {
        setState(() => _modernBannerFrame = next);
      },
      onManage: () {
        Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (_) => ShopMediaPage(shopId: widget.shopId),
          ),
        );
      },
    );
  }

  Widget _buildModernDrawerSettings() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('顯示會員區'),
            subtitle: const Text('會員中心、我的訂單、我的評價'),
            value: _modernTheme.drawerSetting.showMemberCenter,
            onChanged: (value) {
              setState(() {
                _modernTheme = _modernTheme.copyWith(
                  drawerSetting: _modernTheme.drawerSetting.copyWith(
                    showMemberCenter: value,
                  ),
                );
              });
            },
          ),

          const Divider(),

          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('顯示最新訂單'),
            value: _modernTheme.drawerSetting.showLatestBooking,
            onChanged: (value) {
              setState(() {
                _modernTheme = _modernTheme.copyWith(
                  drawerSetting: _modernTheme.drawerSetting.copyWith(
                    showLatestBooking: value,
                  ),
                );
              });
            },
          ),

          if (!_hasAvailableContactMethod)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, color: Colors.orange),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '目前尚未設定電話、LINE、Facebook 或 Instagram，請先到店家基本資料完成設定。',
                    ),
                  ),
                ],
              ),
            ),

          const Divider(),

          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('顯示店家功能'),
            value: _modernTheme.drawerSetting.showShopMenus,
            onChanged: (value) {
              setState(() {
                _modernTheme = _modernTheme.copyWith(
                  drawerSetting: _modernTheme.drawerSetting.copyWith(
                    showShopMenus: value,
                  ),
                );
              });
            },
          ),

          const Divider(),

          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('顯示底部店家資訊'),
            value: _modernTheme.drawerSetting.showFooter,
            onChanged: (value) {
              setState(() {
                _modernTheme = _modernTheme.copyWith(
                  drawerSetting: _modernTheme.drawerSetting.copyWith(
                    showFooter: value,
                  ),
                );
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildThemeSelector() {
    const themes = [
      _ColorOption(value: 'warmOrange', title: '暖橘', color: Color(0xFFC96E18)),
      _ColorOption(value: 'milkTea', title: '奶茶', color: Color(0xFF9B7653)),
      _ColorOption(value: 'rosePink', title: '柔粉', color: Color(0xFFD77887)),
      _ColorOption(
        value: 'forestGreen',
        title: '森林綠',
        color: Color(0xFF4F7D61),
      ),
    ];

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: themes.map((theme) {
        final selected = _selectedTheme == theme.value;

        return InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () {
            setState(() {
              _selectedTheme = theme.value;
            });
          },
          child: Container(
            width: 98,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: selected ? theme.color : Colors.grey.shade300,
                width: selected ? 2 : 1,
              ),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: theme.color,
                  child: selected
                      ? const Icon(Icons.check, color: Colors.white, size: 20)
                      : null,
                ),
                const SizedBox(height: 8),
                Text(
                  theme.title,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildBackgroundSelector() {
    const backgrounds = [
      _ColorOption(value: 'warmWhite', title: '暖白', color: Color(0xFFFFFCF7)),
      _ColorOption(value: 'cream', title: '奶油', color: Color(0xFFFFF5E8)),
      _ColorOption(value: 'lightPink', title: '淡粉', color: Color(0xFFFFF4F5)),
      _ColorOption(value: 'lightGray', title: '淡灰', color: Color(0xFFF5F5F5)),
    ];

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: backgrounds.map((background) {
        final selected = _selectedBackground == background.value;

        return InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () {
            setState(() {
              _selectedBackground = background.value;
            });
          },
          child: Container(
            width: 98,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: background.color,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: selected ? Colors.orange : Colors.grey.shade300,
                width: selected ? 2 : 1,
              ),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: background.color,
                  child: selected
                      ? const Icon(Icons.check, color: Colors.brown, size: 20)
                      : null,
                ),
                const SizedBox(height: 8),
                Text(
                  background.title,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _ColorOption {
  const _ColorOption({
    required this.value,
    required this.title,
    required this.color,
  });

  final String value;
  final String title;
  final Color color;
}
