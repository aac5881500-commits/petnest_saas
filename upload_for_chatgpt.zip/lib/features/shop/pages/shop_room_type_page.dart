// 檔案名稱：lib/features/shop/pages/shop_room_type_page.dart
// 功能說明：整理房型列表、新增表單、編輯表單，以及響應式即時預覽。

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:petnest_saas/core/services/action_log_service.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/core/widgets/shop_task_center_button.dart';
import 'package:petnest_saas/features/shop/widgets/shop_room_type_editor.dart';

class ShopRoomTypePage extends StatefulWidget {
  const ShopRoomTypePage({
    super.key,
    required this.shopId,
    this.embeddedInSetupCenter = false,
  });

  final String shopId;
  final bool embeddedInSetupCenter;

  @override
  State<ShopRoomTypePage> createState() => _ShopRoomTypePageState();
}

/// 🔥 限制最大數字 Formatter
class MaxValueInputFormatter extends TextInputFormatter {
  MaxValueInputFormatter(this.max);

  final int max;

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    if (newValue.text.isEmpty) {
      return newValue;
    }

    final value = int.tryParse(newValue.text);

    if (value == null) {
      return oldValue;
    }

    if (value > max) {
      return oldValue;
    }

    return newValue;
  }
}

class _ShopRoomTypePageState extends State<ShopRoomTypePage> {
  Future<void> _openEditor({Map<String, dynamic>? existing}) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (BuildContext context) {
          return ShopRoomTypeEditorPage(
            shopId: widget.shopId,
            existing: existing,
          );
        },
      ),
    );
  }

  Future<void> _deleteRoomTypeWithRooms(Map<String, dynamic> item) async {
    final roomTypeId = item['id'];
    final roomTypeName = item['name'] ?? '此房型';

    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('確認刪除房型'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('確定要刪除「$roomTypeName」嗎？'),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8F0),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE8D4B8)),
              ),
              child: const Text(
                '刪除後，這個房型底下建立的房間也會一併刪除，且無法復原。\n'
                '若只是暫時不開放，請到房間管理關閉房間，或到房務管理設定單日關閉，不要直接刪除房型。',
                style: TextStyle(
                  fontSize: 13,
                  height: 1.45,
                  color: Color(0xFF5C4A38),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('確認刪除'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final rooms = await ShopService.instance.getRooms(widget.shopId);

    final targetRooms = rooms.where((room) => room['roomTypeId'] == roomTypeId);

    for (final room in targetRooms) {
      await ShopService.instance.deleteRoom(
        shopId: widget.shopId,
        roomId: room['id'],
      );
    }

    await ShopService.instance.deleteRoomType(
      shopId: widget.shopId,
      roomTypeId: roomTypeId,
    );

    final user = FirebaseAuth.instance.currentUser;

    await ActionLogService.instance.logAction(
      shopId: widget.shopId,
      targetType: 'room_type',
      targetId: roomTypeId,
      action: '刪除房型',
      operatorUid: user?.uid ?? '',
      operatorRole: 'owner',
      payload: {
        'roomTypeName': roomTypeName,
        'deletedRoomCount': targetRooms.length,
      },
    );

    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('已刪除房型與其底下房間')));
  }

  Widget _compactChip(String label, {bool muted = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: muted ? Colors.grey.shade100 : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(12),
        border: muted ? Border.all(color: Colors.grey.shade300) : null,
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: muted ? Colors.grey.shade700 : Colors.grey.shade900,
        ),
      ),
    );
  }

  String _formatThousands(int value) {
    final String digits = value.toString();
    final StringBuffer buffer = StringBuffer();
    for (int i = 0; i < digits.length; i++) {
      final int fromEnd = digits.length - i;
      if (i > 0 && fromEnd % 3 == 0) {
        buffer.write(',');
      }
      buffer.write(digits[i]);
    }
    return buffer.toString();
  }

  String? _roomTypeSizeText(Map<String, dynamic> item) {
    int? parseDim(Object? raw) {
      if (raw == null) {
        return null;
      }
      if (raw is num) {
        return raw.toInt();
      }
      return int.tryParse(raw.toString().trim());
    }

    final List<String> parts = <String>[];
    final int? width = parseDim(item['width']);
    final int? depth = parseDim(item['depth']);
    final int? height = parseDim(item['height']);

    if (width != null && width > 0) {
      parts.add('$width');
    }
    if (depth != null && depth > 0) {
      parts.add('$depth');
    }
    if (height != null && height > 0) {
      parts.add('$height');
    }

    if (parts.isEmpty) {
      return null;
    }
    return '${parts.join(' × ')} cm';
  }

  List<String> _roomTypeFeatureLabels(Map<String, dynamic> item) {
    final List<String> labels = <String>[];
    final Object? rawFeatures = item['features'];
    if (rawFeatures is List) {
      for (final Object? key in rawFeatures) {
        final Map<String, dynamic> option = ShopRoomTypeFeatureCatalog.options
            .firstWhere(
              (Map<String, dynamic> e) => e['key'] == key,
              orElse: () => <String, dynamic>{},
            );
        final String name = (option['name'] ?? '').toString().trim();
        if (name.isNotEmpty) {
          labels.add(name);
        }
      }
    }

    final Object? rawCustom = item['customFeatures'];
    if (rawCustom is List) {
      for (final Object? raw in rawCustom) {
        if (raw is! Map) {
          continue;
        }
        final String name = (raw['name'] ?? '').toString().trim();
        final String icon = (raw['icon'] ?? '').toString().trim();
        if (name.isEmpty) {
          continue;
        }
        labels.add(icon.isEmpty ? name : '$icon $name');
      }
    }

    return labels;
  }

  Widget _buildRoomTypeSummaryCard(Map<String, dynamic> item) {
    final String name = (item['name'] ?? '').toString().trim();
    final int price = (item['price'] as num?)?.toInt() ?? 0;
    final int capacity = (item['capacity'] as num?)?.toInt() ?? 0;
    final int totalRooms = (item['totalRooms'] as num?)?.toInt() ?? 0;
    final int extraPrice = (item['extraPrice'] as num?)?.toInt() ?? 0;
    final String? sizeText = _roomTypeSizeText(item);
    final List<String> featureLabels = _roomTypeFeatureLabels(item);
    final List<dynamic> images = List<dynamic>.from(item['images'] ?? []);
    final String imageUrl = images.isNotEmpty ? images.first.toString() : '';

    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (imageUrl.isNotEmpty)
            AspectRatio(
              aspectRatio: 4 / 3,
              child: Image.network(
                imageUrl,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder:
                    (
                      BuildContext context,
                      Object error,
                      StackTrace? stackTrace,
                    ) {
                      return _photoPlaceholder();
                    },
              ),
            )
          else
            AspectRatio(aspectRatio: 4 / 3, child: _photoPlaceholder()),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 4, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        name.isEmpty ? '未命名房型' : name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          height: 1.25,
                        ),
                      ),
                    ),
                    PopupMenuButton<String>(
                      tooltip: '更多',
                      padding: EdgeInsets.zero,
                      icon: const Icon(Icons.more_vert, size: 20),
                      onSelected: (String value) {
                        if (value == 'edit') {
                          _openEditor(existing: item);
                        } else if (value == 'delete') {
                          _deleteRoomTypeWithRooms(item);
                        }
                      },
                      itemBuilder: (BuildContext context) {
                        return const <PopupMenuEntry<String>>[
                          PopupMenuItem<String>(
                            value: 'edit',
                            child: Text('編輯房型'),
                          ),
                          PopupMenuItem<String>(
                            value: 'delete',
                            child: Text(
                              '刪除房型',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ];
                      },
                    ),
                  ],
                ),
                Text(
                  'NT\$${_formatThousands(price)} / 晚',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Colors.grey.shade800,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: <Widget>[
                    _compactChip('可住 $capacity 隻'),
                    _compactChip('設定 $totalRooms 間'),
                    _compactChip(
                      extraPrice > 0 ? '加寵 +\$$extraPrice' : '不加收寵物費',
                    ),
                  ],
                ),
                if (sizeText != null) ...<Widget>[
                  const SizedBox(height: 8),
                  Text(
                    '尺寸  $sizeText',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                ],
                if (featureLabels.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: featureLabels.map(_compactChip).toList(),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _photoPlaceholder() {
    return ColoredBox(
      color: const Color(0xFFF1F3F7),
      child: Center(
        child: Icon(Icons.bed_outlined, size: 36, color: Colors.grey.shade500),
      ),
    );
  }

  Widget _buildRoomTypeActionLogs() {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: ActionLogService.instance.streamShopLogs(widget.shopId),
      builder: (context, snapshot) {
        final logs = (snapshot.data ?? []).where((log) {
          return log['targetType'] == 'room_type' &&
              (log['action'] == '新增房型' ||
                  log['action'] == '編輯房型' ||
                  log['action'] == '刪除房型');
        }).toList();

        if (logs.isEmpty) {
          return const SizedBox();
        }

        return Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '操作紀錄',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                ...logs.map((log) {
                  final payload = Map<String, dynamic>.from(
                    log['payload'] ?? {},
                  );
                  final roomTypeName = payload['roomTypeName'] ?? '未命名房型';
                  final operatorEmail = log['operatorEmail'] ?? '';
                  final createdAt = log['createdAt'];

                  String timeText = '';
                  if (createdAt is Timestamp) {
                    final date = createdAt.toDate();
                    timeText =
                        '${date.year}/${date.month}/${date.day} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
                  }

                  return Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(top: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${log['action']}：$roomTypeName\n'
                      '操作信箱：$operatorEmail\n'
                      '操作時間：$timeText',
                      style: const TextStyle(fontSize: 13, height: 1.5),
                    ),
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Widget body = LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final bool twoColumns = constraints.maxWidth >= 760;
        return Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1280),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              children: <Widget>[
                const Text(
                  '房型管理',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  '設定顧客看得到的房型介紹、價格與容量。這裡的房間數量是房型設定上限，實際房間請到房間管理建立。',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.45,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 14),
                Align(
                  alignment: Alignment.centerLeft,
                  child: FilledButton.icon(
                    onPressed: () => _openEditor(),
                    icon: const Icon(Icons.add),
                    label: const Text('新增房型'),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 14,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF8F0),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE8D4B8)),
                  ),
                  child: const Text(
                    '刪除房型時，房間管理內該房型底下的房間也會一併刪除。\n'
                    '暫停開放請使用房間管理或房務管理，不要直接刪除房型。',
                    style: TextStyle(
                      fontSize: 13,
                      height: 1.45,
                      color: Color(0xFF5C4A38),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                StreamBuilder<List<Map<String, dynamic>>>(
                  stream: ShopService.instance.streamRoomTypes(widget.shopId),
                  builder: (context, snapshot) {
                    final list = snapshot.data ?? [];
                    if (list.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: Center(child: Text('尚未建立房型')),
                      );
                    }
                    final double maxW = constraints.maxWidth > 1280
                        ? 1280 - 32
                        : constraints.maxWidth - 32;
                    final double cardW = twoColumns ? (maxW - 12) / 2 : maxW;
                    return Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: list
                          .map(
                            (Map<String, dynamic> item) => SizedBox(
                              width: cardW < 280 ? maxW : cardW,
                              child: _buildRoomTypeSummaryCard(item),
                            ),
                          )
                          .toList(),
                    );
                  },
                ),
                const SizedBox(height: 12),
                _buildRoomTypeActionLogs(),
              ],
            ),
          ),
        );
      },
    );
    if (widget.embeddedInSetupCenter) {
      return ColoredBox(color: const Color(0xFFF6F8FB), child: body);
    }
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FB),
      appBar: AppBar(
        title: const Text('房型管理'),
        actions: <Widget>[ShopTaskCenterButton(shopId: widget.shopId)],
      ),
      body: body,
    );
  }
}
