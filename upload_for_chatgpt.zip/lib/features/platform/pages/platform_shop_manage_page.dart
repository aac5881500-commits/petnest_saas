// 檔案名稱：lib/features/platform/pages/platform_shop_manage_page.dart
// 功能說明：平台後台查看所有店家，管理公開狀態、方案、付款期限與店家狀態
// 🏪 平台店家管理頁
// 桌機（寬度 >= 1000）與手機／平板共用同一份資料、權限與按鈕行為。

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../../core/constants/platform_permission_keys.dart';
import '../../../core/constants/platform_root_admin.dart';
import '../../../core/services/platform_admin_service.dart';
import 'package:petnest_saas/features/shop/pages/shop_public_page.dart';
import 'package:petnest_saas/features/platform/pages/platform_send_shop_notification_page.dart';
import 'package:petnest_saas/features/platform/widgets/shop_plan_manage_dialog.dart';
import 'package:petnest_saas/features/platform/pages/platform_shop_device_manage_page.dart';
import 'package:petnest_saas/features/platform/widgets/platform_transfer_shop_owner_dialog.dart';

const Color _kPageBackground = Color(0xFFF6F7FB);
const Color _kCardBorder = Color(0xFFD7E0EA);
const Color _kInk = Color(0xFF111827);
const Color _kMuted = Color(0xFF6B7280);
const double _kDesktopBreakpoint = 1000;
const double _kTabletBreakpoint = 600;
const double _kContentMaxWidth = 1480;

class PlatformShopManagePage extends StatelessWidget {
  const PlatformShopManagePage({super.key});

  String _formatDate(dynamic value) {
    if (value == null) return '尚未設定';

    DateTime? date;

    if (value is Timestamp) {
      date = value.toDate();
    } else if (value is DateTime) {
      date = value;
    }

    if (date == null) return '尚未設定';

    final diff = DateTime.now().difference(date);

    if (diff.inMinutes < 1) {
      return '剛剛';
    }

    if (diff.inMinutes < 60) {
      return '${diff.inMinutes}分鐘前';
    }

    if (diff.inHours < 24) {
      return '${diff.inHours}小時前';
    }

    if (diff.inDays < 7) {
      return '${diff.inDays}天前';
    }

    String twoDigits(int number) {
      return number.toString().padLeft(2, '0');
    }

    return '${date.year}/${twoDigits(date.month)}/${twoDigits(date.day)}';
  }

  String _planLabel(String value) {
    switch (value) {
      case 'free':
        return '免費版';
      case 'basic':
        return '基本版';
      case 'pro':
        return '專業版';
      case 'premium':
        return '旗艦版';
      default:
        return '未設定';
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'active':
        return Colors.green;
      case 'suspended':
        return Colors.red;
      case 'pending':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'active':
        return '正常';
      case 'suspended':
        return '停權';
      case 'pending':
        return '待審核';
      default:
        return '未知';
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<bool>>(
      future: Future.wait<bool>([
        PlatformAdminService.instance.hasPermission(
          PlatformPermissionKeys.viewShops,
        ),
        PlatformAdminService.instance.hasPermission(
          PlatformPermissionKeys.manageShopStatus,
        ),
        PlatformAdminService.instance.hasPermission(
          PlatformPermissionKeys.manageShopSubscriptions,
        ),
      ]),
      builder: (context, permissionSnapshot) {
        if (permissionSnapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final permissions =
            permissionSnapshot.data ?? const <bool>[false, false, false];

        final canViewShops = permissions[0];
        final canManageShopStatus = permissions[1];
        final canManageShopSubscriptions = permissions[2];

        final canAccess =
            canViewShops || canManageShopStatus || canManageShopSubscriptions;

        if (!canAccess) {
          return const Scaffold(body: Center(child: Text('你沒有店家管理權限')));
        }

        return Scaffold(
          backgroundColor: _kPageBackground,
          appBar: AppBar(title: const Text('店家管理')),
          body: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('shops')
                .orderBy('createdAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              final docs = snapshot.data?.docs ?? [];

              final totalShops = docs.length;

              final activeShops = docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;
                return data['status'] == 'active';
              }).length;

              final suspendedShops = docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;
                return data['status'] == 'suspended';
              }).length;

              final trialShops = docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;

                final plan = data['plan']?.toString() ?? 'free';

                return plan == 'free';
              }).length;
              if (docs.isEmpty) {
                return const Center(child: Text('目前沒有店家'));
              }

              return LayoutBuilder(
                builder: (context, constraints) {
                  final width = constraints.maxWidth;
                  final desktop = width >= _kDesktopBreakpoint;
                  final phone = width < _kTabletBreakpoint;
                  final horizontal = desktop ? 32.0 : (phone ? 16.0 : 22.0);
                  final inset = MediaQuery.paddingOf(context);

                  return _shopManageCanvas(
                    viewportWidth: width,
                    padding: EdgeInsets.fromLTRB(
                      horizontal + inset.left,
                      12,
                      horizontal + inset.right,
                      28 + inset.bottom,
                    ),
                    totalShops: totalShops,
                    activeShops: activeShops,
                    trialShops: trialShops,
                    suspendedShops: suspendedShops,
                    shopCards: [
                      for (final doc in docs)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 18),
                          child: _ShopCard(
                            desktop: desktop,
                            shopId: doc.id,
                            data: doc.data() as Map<String, dynamic>,
                            canManageShopStatus: canManageShopStatus,
                            canManageShopSubscriptions:
                                canManageShopSubscriptions,
                            formatDate: _formatDate,
                            planLabel: _planLabel,
                            statusLabel: _statusLabel,
                            statusColor: _statusColor,
                          ),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        );
      },
    );
  }
}

class _ShopCard extends StatelessWidget {
  const _ShopCard({
    required this.desktop,
    required this.shopId,
    required this.data,
    required this.canManageShopStatus,
    required this.canManageShopSubscriptions,
    required this.formatDate,
    required this.planLabel,
    required this.statusLabel,
    required this.statusColor,
  });

  final bool desktop;
  final String shopId;
  final Map<String, dynamic> data;
  final bool canManageShopStatus;
  final bool canManageShopSubscriptions;
  final String Function(dynamic value) formatDate;
  final String Function(String value) planLabel;
  final String Function(String status) statusLabel;
  final Color Function(String status) statusColor;

  @override
  Widget build(BuildContext context) {
    final name = data['name']?.toString() ?? '未命名店家';
    final city = data['city']?.toString() ?? '';
    final district = data['district']?.toString() ?? '';
    final logoUrl = data['platformHomeLogoUrl']?.toString().isNotEmpty == true
        ? data['platformHomeLogoUrl'].toString()
        : data['logoUrl']?.toString() ?? '';
    final isPublic = data['isPublic'] == true;
    final licenseVerified = data['licenseVerified'] == true;
    final taxIdVerified = data['taxIdVerified'] == true;
    final externalLinksEnabled = data['externalLinksEnabled'] != false;
    final plan = data['plan']?.toString() ?? 'free';
    final status = data['status']?.toString() ?? 'active';
    final accountStatus = data['accountStatus']?.toString() ?? 'normal';
    final paidUntil = data['paidUntil'];

    DateTime? paidUntilDate;

    if (paidUntil is Timestamp) {
      paidUntilDate = paidUntil.toDate();
    } else if (paidUntil is DateTime) {
      paidUntilDate = paidUntil;
    }

    final isExpired =
        paidUntilDate != null && paidUntilDate.isBefore(DateTime.now());

    final createdAt = data['createdAt'];
    final ownerUid = data['ownerUid']?.toString() ?? '';
    final acceptedShopOwnerPolicyVersion =
        data['acceptedShopOwnerPolicyVersion'] ?? 0;
    final activationCode = data['activationCode']?.toString() ?? '';
    final planStatus = status == 'suspended'
        ? '已停權'
        : plan == 'free'
        ? '免費版'
        : isExpired
        ? '已到期，免費版權限'
        : '付費中';
    final planStatusColor = status == 'suspended'
        ? Colors.red
        : plan == 'free'
        ? Colors.orange
        : isExpired
        ? Colors.deepOrange
        : Colors.green;

    final shop = _ShopVisual(
      shopId: shopId,
      name: name,
      logoUrl: logoUrl,
      location: '$city $district',
      ownerUid: ownerUid,
      status: status,
      statusLabel: statusLabel(status),
      statusColor: statusColor(status),
      restricted: accountStatus == 'restricted',
      suspended: status == 'suspended',
      showTransfer: PlatformRootAdmin.isRoot(
        FirebaseAuth.instance.currentUser?.uid,
      ),
      onTransfer: () {
        showDialog<bool>(
          context: context,
          builder: (_) {
            return PlatformTransferShopOwnerDialog(
              shopId: shopId,
              shopName: name,
              currentOwnerUid: ownerUid,
              previousOwnerUid: (data['previousOwnerUid'] ?? '').toString(),
            );
          },
        );
      },
      isPublic: isPublic,
      licenseVerified: licenseVerified,
      taxIdVerified: taxIdVerified,
      planName: planLabel(plan),
      expireLabel: '到期：${formatDate(paidUntil)}',
      createdLabel: '建立：${formatDate(createdAt)}',
      policyLabel: acceptedShopOwnerPolicyVersion == 0
          ? '創店條款：未記錄'
          : '創店條款：v$acceptedShopOwnerPolicyVersion',
      activationLabel: activationCode.isEmpty ? null : '激活碼：$activationCode',
      planStatus: planStatus,
      planStatusColor: planStatusColor,
      onManagePlan: canManageShopSubscriptions
          ? () {
              showDialog(
                context: context,
                builder: (_) {
                  return ShopPlanManageDialog(
                    shopId: shopId,
                    shopName: name,
                    shop: data,
                  );
                },
              );
            }
          : null,
      onPublicChanged: canManageShopStatus
          ? (value) async {
              await FirebaseFirestore.instance
                  .collection('shops')
                  .doc(shopId)
                  .update({
                    'isPublic': value,
                    'updatedAt': FieldValue.serverTimestamp(),
                  });
            }
          : null,
      externalLinksEnabled: externalLinksEnabled,
      onExternalChanged: canManageShopStatus
          ? (value) async {
              await FirebaseFirestore.instance
                  .collection('shops')
                  .doc(shopId)
                  .update({
                    'externalLinksEnabled': value,
                    'updatedAt': FieldValue.serverTimestamp(),
                  });
            }
          : null,
      onManage: () {},
      onModules: () {},
      onDevices: canManageShopStatus
          ? () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PlatformShopDeviceManagePage(
                    shopId: shopId,
                    shopName: name,
                  ),
                ),
              );
            }
          : null,
      onPreview: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) =>
                ShopPublicPage(shopId: shopId, platformPreview: true),
          ),
        );
      },
      onNotify: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PlatformSendShopNotificationPage(
              shopId: shopId,
              shopName: name,
            ),
          ),
        );
      },
      onToggleSuspend: canManageShopStatus
          ? () async {
              final nextStatus = status == 'suspended' ? 'active' : 'suspended';

              await FirebaseFirestore.instance
                  .collection('shops')
                  .doc(shopId)
                  .update({
                    'status': nextStatus,
                    'updatedAt': FieldValue.serverTimestamp(),
                  });
            }
          : null,
    );

    if (desktop) {
      return _buildDesktopShopCard(shop, formatDate);
    }
    return _buildMobileShopCard(shop, formatDate);
  }
}

class _ShopVisual {
  const _ShopVisual({
    required this.shopId,
    required this.name,
    required this.logoUrl,
    required this.location,
    required this.ownerUid,
    required this.status,
    required this.statusLabel,
    required this.statusColor,
    required this.restricted,
    required this.suspended,
    required this.showTransfer,
    required this.onTransfer,
    required this.isPublic,
    required this.licenseVerified,
    required this.taxIdVerified,
    required this.planName,
    required this.expireLabel,
    required this.createdLabel,
    required this.policyLabel,
    required this.activationLabel,
    required this.planStatus,
    required this.planStatusColor,
    required this.onManagePlan,
    required this.onPublicChanged,
    required this.externalLinksEnabled,
    required this.onExternalChanged,
    required this.onManage,
    required this.onModules,
    required this.onDevices,
    required this.onPreview,
    required this.onNotify,
    required this.onToggleSuspend,
  });

  final String shopId;
  final String name;
  final String logoUrl;
  final String location;
  final String ownerUid;
  final String status;
  final String statusLabel;
  final Color statusColor;
  final bool restricted;
  final bool suspended;
  final bool showTransfer;
  final VoidCallback onTransfer;
  final bool isPublic;
  final bool licenseVerified;
  final bool taxIdVerified;
  final String planName;
  final String expireLabel;
  final String createdLabel;
  final String policyLabel;
  final String? activationLabel;
  final String planStatus;
  final Color planStatusColor;
  final VoidCallback? onManagePlan;
  final ValueChanged<bool>? onPublicChanged;
  final bool externalLinksEnabled;
  final ValueChanged<bool>? onExternalChanged;
  final VoidCallback onManage;
  final VoidCallback onModules;
  final VoidCallback? onDevices;
  final VoidCallback onPreview;
  final VoidCallback onNotify;
  final VoidCallback? onToggleSuspend;
}

Widget _shopManageCanvas({
  required double viewportWidth,
  required EdgeInsets padding,
  required int totalShops,
  required int activeShops,
  required int trialShops,
  required int suspendedShops,
  required List<Widget> shopCards,
}) {
  final desktop = viewportWidth >= _kDesktopBreakpoint;
  final phone = viewportWidth < _kTabletBreakpoint;
  final list = ListView(
    padding: padding,
    children: [
      _ShopPageHeader(compact: !desktop),
      const SizedBox(height: 12),
      _StatGrid(
        columns: desktop ? 4 : 2,
        tileHeight: desktop ? 116 : (phone ? 146 : 120),
        stacked: phone,
        total: totalShops,
        active: activeShops,
        trial: trialShops,
        suspended: suspendedShops,
      ),
      const SizedBox(height: 16),
      ...shopCards,
    ],
  );

  if (!desktop) {
    return list;
  }

  return Align(
    alignment: Alignment.topCenter,
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: _kContentMaxWidth),
      child: list,
    ),
  );
}

Widget _buildDesktopShopCard(
  _ShopVisual shop,
  String Function(dynamic value) formatDate,
) {
  return _desktopShopFrame(
    shop: shop,
    infoChips: _buildShopInfoChips(shop, formatDate),
    metrics: _buildMetricGrid(shop, tileHeight: 88),
  );
}

Widget _buildMobileShopCard(
  _ShopVisual shop,
  String Function(dynamic value) formatDate,
) {
  return _mobileShopFrame(
    shop: shop,
    infoChips: _buildShopInfoChips(shop, formatDate),
    metrics: _buildMetricGrid(shop, tileHeight: 98),
  );
}

Widget _desktopShopFrame({
  required _ShopVisual shop,
  required Widget infoChips,
  required Widget metrics,
}) {
  return _ShopSurface(
    suspended: shop.suspended,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(flex: 30, child: _buildShopIdentity(shop, logoSize: 52)),
          const SizedBox(width: 14),
          Expanded(
            flex: 42,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                infoChips,
                const SizedBox(height: 12),
                _PlanRow(shop: shop, compact: false),
                const SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: _publicToggle(shop)),
                    const SizedBox(width: 8),
                    Expanded(child: _externalToggle(shop)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            flex: 28,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                metrics,
                const SizedBox(height: 12),
                _buildShopActions(shop, wideSuspend: false),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _mobileShopFrame({
  required _ShopVisual shop,
  required Widget infoChips,
  required Widget metrics,
}) {
  return _ShopSurface(
    suspended: shop.suspended,
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildShopIdentity(shop, logoSize: 54),
          const SizedBox(height: 12),
          infoChips,
          const SizedBox(height: 12),
          _PlanRow(shop: shop, compact: true),
          const SizedBox(height: 12),
          _publicToggle(shop),
          const SizedBox(height: 10),
          _externalToggle(shop),
          const SizedBox(height: 12),
          metrics,
          const SizedBox(height: 12),
          _buildShopActions(shop, wideSuspend: true),
        ],
      ),
    ),
  );
}

Widget _buildShopIdentity(_ShopVisual shop, {required double logoSize}) {
  final ownerText = shop.ownerUid.isEmpty ? '未設定' : shop.ownerUid;

  return Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ShopLogo(name: shop.name, logoUrl: shop.logoUrl, size: logoSize),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        shop.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: _kInk,
                          height: 1.2,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    _StatusPill(
                      label: shop.statusLabel,
                      color: shop.statusColor,
                    ),
                  ],
                ),
                if (shop.restricted) ...[
                  const SizedBox(height: 4),
                  const _StatusPill(label: '限制模式', color: Colors.orange),
                ],
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.location_on_outlined,
                      size: 14,
                      color: Colors.grey.shade500,
                    ),
                    const SizedBox(width: 3),
                    Expanded(
                      child: Text(
                        shop.location,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      const SizedBox(height: 8),
      Text(
        'Shop ID：${shop.shopId}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 11.5, color: Color(0xFF9CA3AF)),
      ),
      const SizedBox(height: 2),
      Row(
        children: [
          Expanded(
            child: Text(
              'ownerUid：$ownerText',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, color: Color(0xFF9CA3AF)),
            ),
          ),
          if (shop.showTransfer)
            TextButton(
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                minimumSize: const Size(0, 24),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                visualDensity: VisualDensity.compact,
              ),
              onPressed: shop.onTransfer,
              child: const Text(
                '轉移店主',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
        ],
      ),
    ],
  );
}

Widget _buildShopInfoChips(
  _ShopVisual shop,
  String Function(dynamic value) formatDate,
) {
  return FutureBuilder<DocumentSnapshot>(
    future: shop.ownerUid.isEmpty
        ? null
        : FirebaseFirestore.instance
              .collection('users')
              .doc(shop.ownerUid)
              .get(),
    builder: (context, userSnapshot) {
      final userData = userSnapshot.data?.data() as Map<String, dynamic>?;
      final lastLoginAt = userData?['lastLoginAt'];
      final lastActiveAt = userData?['lastActiveAt'];
      final chips = <_ChipSpec>[
        _ChipSpec(Icons.visibility, shop.isPublic ? '前台公開' : '前台隱藏'),
        _ChipSpec(
          Icons.verified_outlined,
          shop.licenseVerified ? '特寵字號：已認證' : '特寵字號：未認證',
        ),
        _ChipSpec(
          Icons.receipt_long_outlined,
          shop.taxIdVerified ? '統編：已認證' : '統編：未認證',
        ),
        _ChipSpec(Icons.workspace_premium, shop.planName),
        _ChipSpec(Icons.event, shop.expireLabel),
        _ChipSpec(Icons.add_business, shop.createdLabel),
        _ChipSpec(Icons.login, '最後登入：${formatDate(lastLoginAt)}'),
        _ChipSpec(Icons.access_time, '最後活躍：${formatDate(lastActiveAt)}'),
        _ChipSpec(Icons.article_outlined, shop.policyLabel),
        if (shop.activationLabel != null)
          _ChipSpec(Icons.key_outlined, shop.activationLabel!),
      ];

      return LayoutBuilder(
        builder: (context, constraints) {
          final maxText = constraints.maxWidth - 40 < 48
              ? 48.0
              : constraints.maxWidth - 40;
          return Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final chip in chips)
                _InfoChip(
                  icon: chip.icon,
                  label: chip.label,
                  maxTextWidth: maxText,
                ),
            ],
          );
        },
      );
    },
  );
}

Widget _buildShopActions(_ShopVisual shop, {required bool wideSuspend}) {
  final suspendLabel = shop.status == 'suspended' ? '解除停權' : '停權店家';
  final suspendColor = shop.status == 'suspended' ? Colors.green : Colors.red;
  final suspendIcon = shop.status == 'suspended'
      ? Icons.check_circle_outline
      : Icons.block;
  final neutral = _ShopActionButton(
    icon: Icons.edit_outlined,
    label: '管理',
    onPressed: shop.onManage,
  );
  final buttons = [
    neutral,
    _ShopActionButton(
      icon: Icons.dashboard_customize_outlined,
      label: '模組設定',
      onPressed: shop.onModules,
    ),
    _ShopActionButton(
      icon: Icons.sensors,
      label: '設備管理',
      onPressed: shop.onDevices,
    ),
    _ShopActionButton(
      icon: Icons.visibility_outlined,
      label: '查看前台',
      onPressed: shop.onPreview,
    ),
    _ShopActionButton(
      icon: Icons.notifications_active_outlined,
      label: '通知店家',
      onPressed: shop.onNotify,
    ),
  ];
  final suspend = _ShopActionButton(
    icon: suspendIcon,
    label: suspendLabel,
    onPressed: shop.onToggleSuspend,
    foreground: suspendColor,
    border: suspendColor.withValues(alpha: 0.35),
  );

  if (!wideSuspend) {
    buttons.add(suspend);
  }

  return _ActionGrid(
    height: wideSuspend ? 46 : 44,
    buttons: buttons,
    fullWidth: wideSuspend ? suspend : null,
  );
}

Widget _buildMetricGrid(_ShopVisual shop, {required double tileHeight}) {
  return _metricGrid(
    tileHeight: tileHeight,
    orders: _OrdersMetric(shopId: shop.shopId),
    members: _MembersMetric(shopId: shop.shopId),
    media: const _MetricTile(
      icon: Icons.image_outlined,
      iconColor: Colors.purple,
      title: '媒體容量',
      value: '未統計',
      subtitle: '之後統計',
    ),
    visibility: _MetricTile(
      icon: Icons.public,
      iconColor: Colors.blue,
      title: '前台公開',
      value: shop.isPublic ? '已公開' : '已隱藏',
      subtitle: shop.isPublic ? '目前可被搜尋' : '目前不顯示',
      valueColor: shop.isPublic ? Colors.green : Colors.red,
    ),
  );
}

Widget _metricGrid({
  required double tileHeight,
  required Widget orders,
  required Widget members,
  required Widget media,
  required Widget visibility,
}) {
  return Column(
    children: [
      SizedBox(
        height: tileHeight,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(child: orders),
            const SizedBox(width: 8),
            Expanded(child: members),
          ],
        ),
      ),
      const SizedBox(height: 8),
      SizedBox(
        height: tileHeight,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(child: media),
            const SizedBox(width: 8),
            Expanded(child: visibility),
          ],
        ),
      ),
    ],
  );
}

Widget _publicToggle(_ShopVisual shop) {
  return _ToggleCard(
    icon: Icons.public,
    iconColor: shop.isPublic ? const Color(0xFF1565C0) : Colors.red,
    title: shop.isPublic ? '前台已公開' : '前台已隱藏',
    subtitle: shop.isPublic ? '此店家目前會顯示在平台找店' : '此店家目前不會顯示在平台找店',
    value: shop.isPublic,
    alert: !shop.isPublic,
    onChanged: shop.onPublicChanged,
  );
}

Widget _externalToggle(_ShopVisual shop) {
  return _ToggleCard(
    icon: shop.externalLinksEnabled ? Icons.link : Icons.link_off,
    iconColor: shop.externalLinksEnabled ? const Color(0xFF1565C0) : Colors.red,
    title: shop.externalLinksEnabled ? '外部連結已啟用' : '外部連結已關閉',
    subtitle: shop.externalLinksEnabled
        ? 'IG / FB / LINE 等外部連結目前可顯示'
        : '此店家的外部連結目前已被平台關閉',
    value: shop.externalLinksEnabled,
    alert: !shop.externalLinksEnabled,
    onChanged: shop.onExternalChanged,
  );
}

class _ShopPageHeader extends StatelessWidget {
  const _ShopPageHeader({required this.compact});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final title = Text(
      '店家總覽',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontSize: compact ? 17 : 20,
        fontWeight: FontWeight.w700,
        color: _kInk,
        height: 1.2,
      ),
    );
    final subtitle = const Text(
      '管理店家狀態、方案、公開資訊與平台權限',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(fontSize: 12.5, color: _kMuted, height: 1.3),
    );

    if (compact) {
      return SizedBox(
        height: 60,
        child: Align(
          alignment: Alignment.centerLeft,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [title, const SizedBox(height: 2), subtitle],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [title, const SizedBox(height: 4), subtitle],
    );
  }
}

class _StatGrid extends StatelessWidget {
  const _StatGrid({
    required this.columns,
    required this.tileHeight,
    required this.stacked,
    required this.total,
    required this.active,
    required this.trial,
    required this.suspended,
  });

  final int columns;
  final double tileHeight;
  final bool stacked;
  final int total;
  final int active;
  final int trial;
  final int suspended;

  @override
  Widget build(BuildContext context) {
    final tiles = [
      _StatTile(
        icon: Icons.storefront,
        title: '全部店家',
        value: total,
        subtitle: '所有已註冊店家',
        color: Colors.blue,
        stacked: stacked,
      ),
      _StatTile(
        icon: Icons.verified,
        title: '正常營運',
        value: active,
        subtitle: '公開中店家',
        color: Colors.green,
        stacked: stacked,
      ),
      _StatTile(
        icon: Icons.schedule,
        title: '試用中',
        value: trial,
        subtitle: '免費方案店家',
        color: Colors.orange,
        stacked: stacked,
      ),
      _StatTile(
        icon: Icons.block,
        title: '已停權',
        value: suspended,
        subtitle: '已停權店家',
        color: Colors.red,
        stacked: stacked,
      ),
    ];

    final rows = <Widget>[];
    for (var i = 0; i < tiles.length; i += columns) {
      final end = i + columns < tiles.length ? i + columns : tiles.length;
      final slice = tiles.sublist(i, end);
      if (rows.isNotEmpty) {
        rows.add(const SizedBox(height: 12));
      }
      rows.add(
        SizedBox(
          height: tileHeight,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (var c = 0; c < columns; c++) ...[
                if (c > 0) const SizedBox(width: 12),
                Expanded(child: c < slice.length ? slice[c] : const SizedBox()),
              ],
            ],
          ),
        ),
      );
    }

    return Column(children: rows);
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.subtitle,
    required this.color,
    required this.stacked,
  });

  final IconData icon;
  final String title;
  final int value;
  final String subtitle;
  final Color color;
  final bool stacked;

  @override
  Widget build(BuildContext context) {
    final iconBox = Container(
      width: stacked ? 32 : 36,
      height: stacked ? 32 : 36,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, color: color, size: stacked ? 18 : 20),
    );
    final texts = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: stacked
          ? MainAxisAlignment.end
          : MainAxisAlignment.center,
      children: [
        if (!stacked)
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF4B5563),
            ),
          ),
        Text(
          '$value',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: stacked ? 26 : 24,
            fontWeight: FontWeight.w800,
            color: _kInk,
            height: 1.05,
          ),
        ),
        if (stacked)
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: Color(0xFF4B5563),
            ),
          ),
        Text(
          subtitle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 11, color: _kMuted),
        ),
      ],
    );

    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kCardBorder),
      ),
      child: Padding(
        padding: EdgeInsets.all(stacked ? 12 : 14),
        child: stacked
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [iconBox, const Spacer(), texts],
              )
            : Row(
                children: [
                  iconBox,
                  const SizedBox(width: 10),
                  Expanded(child: texts),
                ],
              ),
      ),
    );
  }
}

class _ShopSurface extends StatelessWidget {
  const _ShopSurface({required this.suspended, required this.child});

  final bool suspended;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: suspended ? const Color(0xFFF3D0D0) : _kCardBorder,
        ),
      ),
      child: child,
    );
  }
}

class _ShopLogo extends StatelessWidget {
  const _ShopLogo({
    required this.name,
    required this.logoUrl,
    required this.size,
  });

  final String name;
  final String logoUrl;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFFEAF3FF),
        borderRadius: BorderRadius.circular(16),
        image: logoUrl.isNotEmpty
            ? DecorationImage(image: NetworkImage(logoUrl), fit: BoxFit.cover)
            : null,
      ),
      child: logoUrl.isNotEmpty
          ? null
          : Center(
              child: Text(
                name.isEmpty ? '?' : name.substring(0, 1),
                style: const TextStyle(
                  color: Color(0xFF1565C0),
                  fontWeight: FontWeight.w800,
                  fontSize: 20,
                ),
              ),
            ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        maxLines: 1,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          height: 1.2,
        ),
      ),
    );
  }
}

class _ChipSpec {
  const _ChipSpec(this.icon, this.label);

  final IconData icon;
  final String label;
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({
    required this.icon,
    required this.label,
    required this.maxTextWidth,
  });

  final IconData icon;
  final String label;
  final double maxTextWidth;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 30),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: _kMuted),
          const SizedBox(width: 4),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxTextWidth),
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
                color: Color(0xFF374151),
                height: 1.15,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PlanRow extends StatelessWidget {
  const _PlanRow({required this.shop, required this.compact});

  final _ShopVisual shop;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(minHeight: compact ? 86 : 64),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: compact ? 10 : 8),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FBFF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD6E4F0)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF3FF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.event_note,
              color: Color(0xFF1565C0),
              size: 18,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  shop.planName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: _kInk,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  shop.planStatus,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: shop.planStatusColor,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF1565C0),
              side: const BorderSide(color: Color(0xFFBFDBFE)),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              minimumSize: const Size(0, 36),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              visualDensity: VisualDensity.compact,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: shop.onManagePlan,
            child: Text(
              compact ? '管理方案' : '方案與權限管理',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

class _ToggleCard extends StatelessWidget {
  const _ToggleCard({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.alert,
    required this.onChanged,
  });

  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final bool value;
  final bool alert;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 72),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: alert ? const Color(0xFFF3D0D0) : _kCardBorder,
        ),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: iconColor),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: alert ? const Color(0xFFDC2626) : _kInk,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: _kMuted,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.value,
    required this.subtitle,
    this.valueColor,
  });

  final IconData icon;
  final Color iconColor;
  final String title;
  final String value;
  final String subtitle;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xFFFCFCFD),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _kCardBorder),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 7),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Icon(icon, size: 15, color: iconColor),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: _kMuted,
                    ),
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: valueColor ?? _kInk,
                    height: 1.1,
                  ),
                ),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF9CA3AF),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _OrdersMetric extends StatelessWidget {
  const _OrdersMetric({required this.shopId});

  final String shopId;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('bookings')
          .where('shopId', isEqualTo: shopId)
          .snapshots(),
      builder: (context, bookingSnapshot) {
        final bookingDocs = bookingSnapshot.data?.docs ?? [];

        final now = DateTime.now();
        final monthStart = DateTime(now.year, now.month, 1);

        final monthCount = bookingDocs.where((bookingDoc) {
          final bookingData = bookingDoc.data() as Map<String, dynamic>;
          final createdAt = bookingData['createdAt'];

          if (createdAt is! Timestamp) return false;

          return createdAt.toDate().isAfter(monthStart);
        }).length;

        return _MetricTile(
          icon: Icons.receipt_long,
          iconColor: Colors.green,
          title: '訂單總數',
          value: bookingDocs.length.toString(),
          subtitle: '本月 $monthCount 筆',
        );
      },
    );
  }
}

class _MembersMetric extends StatelessWidget {
  const _MembersMetric({required this.shopId});

  final String shopId;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('shops')
          .doc(shopId)
          .collection('members')
          .snapshots(),
      builder: (context, memberSnapshot) {
        final memberDocs = memberSnapshot.data?.docs ?? [];

        final now = DateTime.now();
        final monthStart = DateTime(now.year, now.month, 1);

        final monthCount = memberDocs.where((memberDoc) {
          final memberData = memberDoc.data() as Map<String, dynamic>;
          final createdAt = memberData['createdAt'];

          if (createdAt is! Timestamp) return false;

          return createdAt.toDate().isAfter(monthStart);
        }).length;

        return _MetricTile(
          icon: Icons.people_alt_outlined,
          iconColor: Colors.orange,
          title: '會員數',
          value: memberDocs.length.toString(),
          subtitle: '本月新增 $monthCount 人',
        );
      },
    );
  }
}

class _ShopActionButton extends StatelessWidget {
  const _ShopActionButton({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.foreground = const Color(0xFF374151),
    this.border = _kCardBorder,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final Color foreground;
  final Color border;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        foregroundColor: foreground,
        disabledForegroundColor: const Color(0xFF9CA3AF),
        side: BorderSide(
          color: onPressed == null ? const Color(0xFFE5E7EB) : border,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        minimumSize: const Size(0, 44),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionGrid extends StatelessWidget {
  const _ActionGrid({
    required this.height,
    required this.buttons,
    this.fullWidth,
  });

  final double height;
  final List<Widget> buttons;
  final Widget? fullWidth;

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < buttons.length; i += 2) {
      final right = i + 1 < buttons.length ? buttons[i + 1] : const SizedBox();
      if (rows.isNotEmpty) {
        rows.add(const SizedBox(height: 8));
      }
      rows.add(
        SizedBox(
          height: height,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(child: buttons[i]),
              const SizedBox(width: 8),
              Expanded(child: right),
            ],
          ),
        ),
      );
    }

    if (fullWidth != null) {
      rows.add(const SizedBox(height: 8));
      rows.add(
        SizedBox(height: height, width: double.infinity, child: fullWidth),
      );
    }

    return Column(children: rows);
  }
}
