// 檔案名稱：lib/main.dart
// 功能說明：Flutter 應用程式入口，初始化 Firebase、路由與全域錯誤處理

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:petnest_saas/core/theme/petnest_app_theme.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/services.dart';
import 'package:petnest_saas/features/auth/pages/home_page.dart';
import 'package:petnest_saas/features/platform/widgets/platform_policy_gate.dart';
import 'package:petnest_saas/core/services/auth_service.dart';
import 'package:petnest_saas/features/auth/pages/email_verification_page.dart';
import 'package:petnest_saas/features/auth/pages/login_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:petnest_saas/core/services/shop_service.dart';
import 'package:petnest_saas/features/shop/pages/shop_public_page.dart';
import 'package:petnest_saas/firebase_options.dart';
import 'package:petnest_saas/features/shop/pages/shop_code_redirect_page.dart';
import 'package:flutter/foundation.dart';
import 'package:petnest_saas/core/debug/chat_error_probe.dart';
import 'package:petnest_saas/core/services/fcm_token_service.dart';
import 'package:petnest_saas/core/services/fcm_message_service.dart';
import 'package:petnest_saas/core/navigation/app_navigator.dart';
import 'package:petnest_saas/core/web/web_update_controller.dart';
import 'package:petnest_saas/core/web/web_update_prompt.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (kDebugMode) {
    FlutterError.onError = (FlutterErrorDetails details) {
      try {
        FlutterError.presentError(details);
      } catch (_) {}
      try {
        print('[GLOBAL FlutterError]');
        print(ChatErrorProbe.describe(details.exception));
        print(details.exceptionAsString());
        print(details.stack);
        ChatErrorProbe.dump(
          'GLOBAL FlutterError',
          details.exception,
          details.stack ?? StackTrace.empty,
        );
      } catch (error, stack) {
        print('[GLOBAL FlutterError] probe failed');
        print(error);
        print(stack);
      }
    };
    WidgetsBinding.instance.platformDispatcher.onError =
        (Object error, StackTrace stack) {
          try {
            print('[GLOBAL PlatformError]');
            print('type=${error.runtimeType}');
            print(ChatErrorProbe.describe(error));
            print(error);
            print(stack);
            ChatErrorProbe.dump('GLOBAL PlatformError', error, stack);
          } catch (probeError, probeStack) {
            print('[GLOBAL PlatformError] probe failed');
            print(probeError);
            print(probeStack);
          }
          return false;
        };
  }

  // 📱 只在手機 App 鎖直向；Web 後台不鎖方向
  if (!kIsWeb) {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  }

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  FcmTokenService.instance.listenTokenRefresh();

  runApp(const PetNestApp());
}

class PetNestApp extends StatefulWidget {
  const PetNestApp({super.key});

  @override
  State<PetNestApp> createState() => _PetNestAppState();
}

class _PetNestAppState extends State<PetNestApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WebUpdateController.instance.start();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      WebUpdateController.instance.onResumed();
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      builder: (BuildContext context, Widget? child) {
        return WebUpdateOverlay(child: child ?? const SizedBox.shrink());
      },
      navigatorKey: AppNavigator.key,
      title: 'PetNest SaaS',
      debugShowCheckedModeBanner: false,
      locale: const Locale('zh', 'TW'),
      supportedLocales: const <Locale>[Locale('zh', 'TW'), Locale('en', 'US')],
      localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: PetNestAppTheme.build(),

      /// 🔥 一定要有這段
      routes: {
        '/member': (context) {
          throw UnimplementedError('MemberPage 必須傳入 shopId，請由 Drawer 或首頁進入。');
        },
        '/login': (context) => const LoginPage(),
        '/home': (context) =>
            const _VerifiedEntry(child: PlatformPolicyGate(child: HomePage())),
        '/entry': (context) => const AppEntryPage(),

        // 🖥️ 店家 Web 後台入口
        '/admin': (context) => const AppEntryPage(),
      },

      onGenerateRoute: (settings) {
        final uri = Uri.parse(settings.name ?? '');

        if (uri.pathSegments.length == 2 && uri.pathSegments.first == 's') {
          final shopCode = uri.pathSegments[1];

          return MaterialPageRoute(
            builder: (_) => ShopCodeRedirectPage(shopCode: shopCode),
          );
        }

        return null;
      },

      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  bool _showEntry = false;

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(seconds: 4), () {
      if (!mounted) return;
      setState(() {
        _showEntry = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_showEntry) {
      return const AppEntryPage();
    }

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/app_logo.png',
                width: 350,
                fit: BoxFit.contain,
              ),
              const SizedBox(height: 20),

              const Text(
                '全台寵物旅宿管理平台',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 32),

              const SizedBox(height: 32),

              const CircularProgressIndicator(),

              const SizedBox(height: 16),

              const Text(
                '載入中...',
                style: TextStyle(fontSize: 15, color: Colors.black54),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AppEntryPage extends StatelessWidget {
  const AppEntryPage({super.key});

  Future<Widget> _decideEntryPage() async {
    User? user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const LoginPage();
    }

    try {
      user = await AuthService.instance.reloadCurrentUser();
    } catch (error) {
      debugPrint('登入狀態重新讀取失敗');
    }
    user ??= FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const LoginPage();
    }
    if (AuthService.instance.mustVerifyEmail(user)) {
      return const EmailVerificationPage();
    }

    // 🔔 手機使用者登入後，自動同步 FCM Token
    // Web 會由 FcmTokenService 自動略過
    Future<void>.microtask(() async {
      try {
        print('[AppEntry] FCM microtask start');
        await FcmTokenService.instance.saveCurrentUserToken();
        await FcmMessageService.instance.initialize();
        print('[AppEntry] FCM microtask success');
      } catch (e, st) {
        print('[AppEntry] FCM microtask failed');
        ChatErrorProbe.dump('AppEntry FCM', e, st);
      }
    });

    // 有店家身分：店主 / 員工照原本進 HomePage
    final myShops = await ShopService.instance.getMyShops();
    if (myShops.isNotEmpty) {
      return const PlatformPolicyGate(child: HomePage());
    }

    // 一般客戶：回到最後掃過 / 逛過的店
    final prefs = await SharedPreferences.getInstance();
    final lastShopId = prefs.getString('last_customer_shop_id');

    if (lastShopId != null && lastShopId.isNotEmpty) {
      return PlatformPolicyGate(child: ShopPublicPage(shopId: lastShopId));
    }

    // 沒有最後店家，就照原本首頁
    return const PlatformPolicyGate(child: HomePage());
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, authSnapshot) {
        if (authSnapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        return FutureBuilder<Widget>(
          future: _decideEntryPage(),
          builder: (context, pageSnapshot) {
            if (pageSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            final page = pageSnapshot.data ?? const LoginPage();

            if (authSnapshot.data == null) {
              return page;
            }

            return page;
          },
        );
      },
    );
  }
}

class _VerifiedEntry extends StatefulWidget {
  const _VerifiedEntry({required this.child});

  final Widget child;

  @override
  State<_VerifiedEntry> createState() => _VerifiedEntryState();
}

class _VerifiedEntryState extends State<_VerifiedEntry> {
  late final Future<bool> _allowed = _check();

  Future<bool> _check() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return true;
    }
    try {
      final User? fresh = await AuthService.instance.reloadCurrentUser();
      if (fresh == null) {
        return true;
      }
      return !AuthService.instance.mustVerifyEmail(fresh);
    } catch (error) {
      debugPrint('首頁驗證狀態讀取失敗');
      return !AuthService.instance.mustVerifyEmail(user);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _allowed,
      builder: (BuildContext context, AsyncSnapshot<bool> snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data == false) {
          return const EmailVerificationPage();
        }
        return widget.child;
      },
    );
  }
}
